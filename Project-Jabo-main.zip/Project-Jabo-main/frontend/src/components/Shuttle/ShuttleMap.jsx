// ============================================
// FILE: components/ShuttleMap.jsx
// Real Leaflet.js Integration for Shuttle Service
// ============================================

import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons in Leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

const ShuttleMap = ({
  pickup,
  dropoff,
  onPickupChange,
  onDropoffChange,
  selectingLocation,
  onAddressChange
}) => {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const pickupMarkerRef = useRef(null);
  const dropoffMarkerRef = useRef(null);
  const routeLineRef = useRef(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    // Initialize map only once
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapRef.current).setView(
        [23.8103, 90.4125], // Dhaka, Bangladesh
        13
      );

      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(mapInstanceRef.current);

      // Custom pickup marker (green)
      const pickupIcon = L.divIcon({
        className: 'custom-marker',
        html: `<div style="background-color: #10B981; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">P</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      // Custom dropoff marker (red)
      const dropoffIcon = L.divIcon({
        className: 'custom-marker',
        html: `<div style="background-color: #EF4444; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">D</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      // Add pickup marker
      pickupMarkerRef.current = L.marker(pickup.coordinates.slice().reverse(), {
        icon: pickupIcon,
        draggable: true
      })
        .addTo(mapInstanceRef.current)
        .bindPopup('Pickup Location')
        .on('dragend', async (e) => {
          const latlng = e.target.getLatLng();
          const coords = [latlng.lng, latlng.lat];
          onPickupChange(coords);
          await handleMarkerMove(coords, 'pickup');
          updateRoute();
        });

      // Add dropoff marker
      dropoffMarkerRef.current = L.marker(dropoff.coordinates.slice().reverse(), {
        icon: dropoffIcon,
        draggable: true
      })
        .addTo(mapInstanceRef.current)
        .bindPopup('Drop-off Location')
        .on('dragend', async (e) => {
          const latlng = e.target.getLatLng();
          const coords = [latlng.lng, latlng.lat];
          onDropoffChange(coords);
          await handleMarkerMove(coords, 'dropoff');
          updateRoute();
        });

      // Draw route line
      updateRoute();

      // Handle map clicks for location selection
      mapInstanceRef.current.on('click', async (e) => {
        if (selectingLocation === 'pickup') {
          const coords = [e.latlng.lng, e.latlng.lat];
          pickupMarkerRef.current.setLatLng(e.latlng);
          onPickupChange(coords);
          await handleMarkerMove(coords, 'pickup');
          updateRoute();
        } else if (selectingLocation === 'dropoff') {
          const coords = [e.latlng.lng, e.latlng.lat];
          dropoffMarkerRef.current.setLatLng(e.latlng);
          onDropoffChange(coords);
          await handleMarkerMove(coords, 'dropoff');
          updateRoute();
        }
      });
    }

    // Update markers when coordinates change externally
    if (pickupMarkerRef.current && pickup.coordinates) {
      pickupMarkerRef.current.setLatLng(pickup.coordinates.slice().reverse());
    }
    if (dropoffMarkerRef.current && dropoff.coordinates) {
      dropoffMarkerRef.current.setLatLng(dropoff.coordinates.slice().reverse());
    }

    updateRoute();
  }, [pickup.coordinates, dropoff.coordinates, selectingLocation]);

  // Update route line between pickup and dropoff
  const updateRoute = () => {
    if (!mapInstanceRef.current || !pickupMarkerRef.current || !dropoffMarkerRef.current) return;

    // Remove existing route line
    if (routeLineRef.current) {
      mapInstanceRef.current.removeLayer(routeLineRef.current);
    }

    // Draw new route line
    const pickupLatLng = pickupMarkerRef.current.getLatLng();
    const dropoffLatLng = dropoffMarkerRef.current.getLatLng();

    routeLineRef.current = L.polyline([pickupLatLng, dropoffLatLng], {
      color: '#3B82F6',
      weight: 4,
      opacity: 0.7,
      dashArray: '10, 10'
    }).addTo(mapInstanceRef.current);

    // Fit map to show both markers
    const bounds = L.latLngBounds([pickupLatLng, dropoffLatLng]);
    mapInstanceRef.current.fitBounds(bounds, { padding: [50, 50] });
  };

  // Reverse geocoding to get address from coordinates
  const getAddressFromCoordinates = async (coords, type) => {
    try {
      const [lng, lat] = coords;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
        {
          headers: {
            'User-Agent': 'JaboBusService/1.0'
          }
        }
      );
      const data = await response.json();

      if (data && data.display_name) {
        const address = data.display_name;
        if (onAddressChange) {
          onAddressChange(type, address);
        }
        return address;
      }
    } catch (error) {
      console.error('Error getting address:', error);
    }
    return null;
  };

  // Search for locations using Nominatim
  const searchLocation = async (query) => {
    if (!query || query.length < 3) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=bd`,
        {
          headers: {
            'User-Agent': 'JaboBusService/1.0'
          }
        }
      );
      const data = await response.json();
      setSearchResults(data || []);
    } catch (error) {
      console.error('Error searching location:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle search result selection
  const handleSearchSelect = (result) => {
    const coords = [parseFloat(result.lon), parseFloat(result.lat)];
    const address = result.display_name;

    if (selectingLocation === 'pickup') {
      onPickupChange(coords);
      if (pickupMarkerRef.current) {
        pickupMarkerRef.current.setLatLng([result.lat, result.lon]);
      }
      if (onAddressChange) {
        onAddressChange('pickup', address);
      }
    } else if (selectingLocation === 'dropoff') {
      onDropoffChange(coords);
      if (dropoffMarkerRef.current) {
        dropoffMarkerRef.current.setLatLng([result.lat, result.lon]);
      }
      if (onAddressChange) {
        onAddressChange('dropoff', address);
      }
    }

    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([result.lat, result.lon], 15);
    }
    setSearchQuery('');
    setSearchResults([]);
    updateRoute();
  };

  // Update address when marker is moved
  const handleMarkerMove = async (coords, type) => {
    const address = await getAddressFromCoordinates(coords, type);
    return address;
  };

  // Add current location button
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const coords = [position.coords.longitude, position.coords.latitude];
          if (selectingLocation === 'pickup') {
            onPickupChange(coords);
            if (pickupMarkerRef.current) {
              pickupMarkerRef.current.setLatLng([position.coords.latitude, position.coords.longitude]);
            }
            await handleMarkerMove(coords, 'pickup');
          } else if (selectingLocation === 'dropoff') {
            onDropoffChange(coords);
            if (dropoffMarkerRef.current) {
              dropoffMarkerRef.current.setLatLng([position.coords.latitude, position.coords.longitude]);
            }
            await handleMarkerMove(coords, 'dropoff');
          }
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setView([position.coords.latitude, position.coords.longitude], 15);
          }
          updateRoute();
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please select on map or enter address manually.');
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
    }
  };

  // Debounce search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery) {
        searchLocation(searchQuery);
      } else {
        setSearchResults([]);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  return (
    <div className="relative h-full w-full">
      <div ref={mapRef} className="h-full w-full rounded-lg" style={{ minHeight: '400px' }} />

      {/* Search Box */}
      {selectingLocation && (
        <div className="absolute top-4 left-4 right-4 bg-white rounded-lg shadow-lg p-3 z-[1000]">
          <div className="relative">
            <input
              type="text"
              placeholder={`Search ${selectingLocation === 'pickup' ? 'pickup' : 'dropoff'} location...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {isSearching && (
              <div className="absolute right-3 top-2.5">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
              </div>
            )}
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto z-[1001]">
                {searchResults.map((result, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => handleSearchSelect(result)}
                    className="w-full text-left px-4 py-2 hover:bg-gray-100 border-b border-gray-100 last:border-b-0"
                  >
                    <p className="text-sm font-medium text-gray-800">{result.display_name}</p>
                    <p className="text-xs text-gray-500">{result.type}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Map Instructions */}
      <div className={`absolute ${selectingLocation ? 'top-24' : 'top-4'} left-4 bg-white rounded-lg shadow-lg p-3 max-w-xs z-[1000]`}>
        <p className="text-xs text-gray-700 mb-2">
          {selectingLocation === 'pickup' && '📍 Click on map to set pickup location'}
          {selectingLocation === 'dropoff' && '📍 Click on map to set drop-off location'}
          {!selectingLocation && '🗺️ Drag markers to adjust locations'}
        </p>
        {selectingLocation && (
          <button
            onClick={getCurrentLocation}
            className="w-full px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 flex items-center justify-center gap-1"
          >
            📍 Use My Current Location
          </button>
        )}
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-3 z-[1000]">
        <div className="flex items-center gap-2 mb-2 text-sm">
          <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
          <span className="text-xs">Pickup</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white"></div>
          <span className="text-xs">Drop-off</span>
        </div>
      </div>
    </div>
  );
};

export default ShuttleMap;
