// ============================================
// FILE: Alternative - Using react-leaflet (Recommended)
// components/ShuttleMapReactLeaflet.jsx
// ============================================

// Install: npm install react-leaflet leaflet

import React, { useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix marker icons
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom icons
const pickupIcon = L.divIcon({
  className: 'custom-marker',
  html: `<div style="background-color: #10B981; width: 32px; height: 32px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 14px;">P</div>`,
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

const dropoffIcon = L.divIcon({
  className: 'custom-marker',
  html: `<div style="background-color: #EF4444; width: 32px; height: 32px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 14px;">D</div>`,
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

// Component to handle map clicks
function MapClickHandler({ selectingLocation, onPickupChange, onDropoffChange }) {
  useMapEvents({
    click(e) {
      if (selectingLocation === 'pickup') {
        onPickupChange([e.latlng.lng, e.latlng.lat]);
      } else if (selectingLocation === 'dropoff') {
        onDropoffChange([e.latlng.lng, e.latlng.lat]);
      }
    },
  });
  return null;
}

const ShuttleMapReactLeaflet = ({
  pickup,
  dropoff,
  onPickupChange,
  onDropoffChange,
  selectingLocation
}) => {
  const mapRef = useRef();

  const handlePickupDrag = (e) => {
    const latlng = e.target.getLatLng();
    onPickupChange([latlng.lng, latlng.lat]);
  };

  const handleDropoffDrag = (e) => {
    const latlng = e.target.getLatLng();
    onDropoffChange([latlng.lng, latlng.lat]);
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = [position.coords.longitude, position.coords.latitude];
          if (selectingLocation === 'pickup') {
            onPickupChange(coords);
          } else if (selectingLocation === 'dropoff') {
            onDropoffChange(coords);
          }

          // Center map on current location
          if (mapRef.current) {
            mapRef.current.setView([position.coords.latitude, position.coords.longitude], 15);
          }
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location');
        }
      );
    }
  };

  // Calculate map center (midpoint between pickup and dropoff)
  const center = [
    (pickup.coordinates[1] + dropoff.coordinates[1]) / 2,
    (pickup.coordinates[0] + dropoff.coordinates[0]) / 2
  ];

  return (
    <div className="relative">
      <MapContainer
        center={center}
        zoom={13}
        style={{ height: '400px', width: '100%', borderRadius: '8px' }}
        ref={mapRef}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* Pickup Marker */}
        <Marker
          position={[pickup.coordinates[1], pickup.coordinates[0]]}
          icon={pickupIcon}
          draggable={true}
          eventHandlers={{
            dragend: handlePickupDrag,
          }}
        >
          <Popup>
            <strong>Pickup Location</strong><br />
            {pickup.address || 'Drag to adjust'}
          </Popup>
        </Marker>

        {/* Dropoff Marker */}
        <Marker
          position={[dropoff.coordinates[1], dropoff.coordinates[0]]}
          icon={dropoffIcon}
          draggable={true}
          eventHandlers={{
            dragend: handleDropoffDrag,
          }}
        >
          <Popup>
            <strong>Drop-off Location</strong><br />
            {dropoff.address || 'Drag to adjust'}
          </Popup>
        </Marker>

        {/* Route Line */}
        <Polyline
          positions={[
            [pickup.coordinates[1], pickup.coordinates[0]],
            [dropoff.coordinates[1], dropoff.coordinates[0]]
          ]}
          pathOptions={{
            color: '#3B82F6',
            weight: 4,
            opacity: 0.7,
            dashArray: '10, 10'
          }}
        />

        {/* Map Click Handler */}
        <MapClickHandler
          selectingLocation={selectingLocation}
          onPickupChange={onPickupChange}
          onDropoffChange={onDropoffChange}
        />
      </MapContainer>

      {/* Instructions Overlay */}
      <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg p-3 max-w-xs z-[1000]">
        <p className="text-xs text-gray-700 mb-2">
          {selectingLocation === 'pickup' && '📍 Click on map to set pickup location'}
          {selectingLocation === 'dropoff' && '📍 Click on map to set drop-off location'}
          {!selectingLocation && '🗺️ Drag markers to adjust locations'}
        </p>
        {selectingLocation && (
          <button
            onClick={getCurrentLocation}
            className="w-full px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 flex items-center justify-center gap-1"
          >
            📍 Use My Current Location
          </button>
        )}
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-3 z-[1000]">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
          <span className="text-xs font-medium">Pickup</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white"></div>
          <span className="text-xs font-medium">Drop-off</span>
        </div>
      </div>
    </div>
  );
};

export default ShuttleMapReactLeaflet;
