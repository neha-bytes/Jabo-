import React from 'react';

const Card = ({
  children,
  className = '',
  hover = false,
  padding = true,
  variant = 'default',
  onClick,
}) => {
  const baseStyles = 'bg-white rounded-2xl transition-all duration-500 border border-gray-100';

  const variants = {
    default: 'shadow-md',
    glass: 'bg-white/80 backdrop-blur-xl shadow-xl',
    gradient: 'bg-gradient-to-br from-white to-gray-50 shadow-lg',
  };

  const hoverStyles = hover
    ? 'hover:shadow-2xl hover:-translate-y-2 cursor-pointer'
    : '';

  const paddingStyles = padding ? 'p-6 md:p-8' : '';

  return (
    <div
      onClick={onClick}
      className={`
        ${baseStyles}
        ${variants[variant]}
        ${hoverStyles}
        ${paddingStyles}
        ${className}
      `}
    >
      {children}
    </div>
  );
};

export default Card;
