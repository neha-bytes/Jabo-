import React from 'react';

const Input = ({
  label,
  type = 'text',
  name,
  value,
  onChange,
  placeholder,
  error,
  required = false,
  disabled = false,
  icon: Icon,
  className = '',
  helperText,
  ...props
}) => {
  return (
    <div className={`space-y-2 ${className}`}>
      {label && (
        <label htmlFor={name} className="block text-sm font-semibold text-gray-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}

      <div className="group relative">
        {Icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-blue-50 rounded-lg group-focus-within:bg-blue-100 transition-all duration-300">
            <Icon className="h-5 w-5 text-gray-400 group-focus-within:text-blue-600 transition-all duration-300 group-focus-within:scale-110" />
          </div>
        )}

        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          className={`
            w-full py-3.5 border-2 rounded-xl
            focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500
            transition-all duration-300 text-gray-900
            bg-white/50 backdrop-blur-sm placeholder:text-gray-400
            disabled:bg-gray-100 disabled:cursor-not-allowed
            hover:border-gray-300
            ${Icon ? 'pl-16 pr-4' : 'px-4'}
            ${error ? 'border-red-500 focus:ring-red-500/50 focus:border-red-500' : 'border-gray-200'}
          `}
          {...props}
        />
      </div>

      {helperText && !error && (
        <p className="text-sm text-gray-500">{helperText}</p>
      )}

      {error && (
        <p className="text-sm text-red-500 font-medium flex items-center gap-1">
          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
          </svg>
          {error}
        </p>
      )}
    </div>
  );
};

export default Input;
