const Skeleton = ({ className = '' }) => {
  return (
    <div className={`animate-pulse rounded-md bg-gray-200 ${className}`}></div>
  );
};

export default Skeleton;






