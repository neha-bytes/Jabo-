// frontend/src/components/ProtectedRoutes.jsx

import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Loading component
const LoadingScreen = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent mx-auto mb-4"></div>
      <p className="text-gray-600">Loading...</p>
    </div>
  </div>
);

// Admin Route - Only admins can access
export const AdminRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (user.role !== 'admin') {
    // Non-admins trying to access admin routes get redirected to home
    return <Navigate to="/" replace />;
  }

  return children;
};

// Driver Route - Only drivers can access
export const DriverRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (user.role !== 'driver') {
    // Non-drivers trying to access driver routes get redirected
    if (user.role === 'admin') {
      return <Navigate to="/admin" replace />;
    }
    return <Navigate to="/" replace />;
  }

  return children;
};

// User Route - Only regular users can access (blocks admins and drivers)
export const UserRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Redirect admins to admin dashboard
  if (user.role === 'admin') {
    return <Navigate to="/admin" replace />;
  }

  // Redirect drivers to driver dashboard
  if (user.role === 'driver') {
    return <Navigate to="/driver-dashboard" replace />;
  }

  return children;
};

// Public Route - Redirects authenticated users based on their role
export const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  if (user) {
    // Redirect based on role
    if (user.role === 'admin') {
      return <Navigate to="/admin" replace />;
    }
    if (user.role === 'driver') {
      return <Navigate to="/driver-dashboard" replace />;
    }
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

// Protected Route - Requires authentication but allows all roles
export const ProtectedRoute = ({ children, allowPublic = false}) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingScreen />;
  }

  // If user is authenticated, redirect based on role
  if (user) {
    if (user.role === 'admin') {
      return <Navigate to="/admin" replace />;
    }
    if (user.role === 'driver') {
      return <Navigate to="/driver-dashboard" replace />;
    }
  }

  // If not authenticated and route doesn't allow public access
  if (!user && !allowPublic) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};
