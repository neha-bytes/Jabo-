import { useState } from 'react';
import { X, CreditCard, Phone, CheckCircle2, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

const PaymentModal = ({ isOpen, onClose, onSuccess, amount, currency = 'BDT', paymentMethod = 'bKash' }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate phone number
    const phoneRegex = /^[0-9]{10,11}$/;
    const cleanPhone = phoneNumber.replace(/[\s-]/g, '');
    
    if (!cleanPhone || !phoneRegex.test(cleanPhone)) {
      setError('Please enter a valid phone number (10-11 digits)');
      return;
    }

    setProcessing(true);
    setError('');

    // Simulate payment processing
    setTimeout(() => {
      setProcessing(false);
      toast.success('Payment processed successfully!');
      onSuccess?.({
        phoneNumber: cleanPhone,
        transactionId: `TXN${Date.now()}`,
        method: paymentMethod,
      });
      setPhoneNumber('');
      onClose();
    }, 2000);
  };

  const handleClose = () => {
    if (!processing) {
      setPhoneNumber('');
      setError('');
      onClose();
    }
  };

  if (!isOpen) return null;

  const paymentMethods = {
    bKash: { name: 'bKash', color: 'bg-red-50 border-red-200 text-red-700' },
    Nagad: { name: 'Nagad', color: 'bg-green-50 border-green-200 text-green-700' },
    Rocket: { name: 'Rocket', color: 'bg-blue-50 border-blue-200 text-blue-700' },
    Card: { name: 'Card', color: 'bg-purple-50 border-purple-200 text-purple-700' },
    Cash: { name: 'Cash', color: 'bg-gray-50 border-gray-200 text-gray-700' },
  };

  const methodInfo = paymentMethods[paymentMethod] || paymentMethods.bKash;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 relative">
        {/* Close Button */}
        {!processing && (
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        )}

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-block p-3 bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl mb-4">
            <CreditCard className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Complete Payment</h2>
          <p className="text-gray-600">Enter your payment details</p>
        </div>

        {/* Payment Method Badge */}
        <div className={`mb-6 p-4 rounded-xl border-2 ${methodInfo.color}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium opacity-75">Payment Method</p>
              <p className="text-lg font-bold">{methodInfo.name}</p>
            </div>
            <CreditCard className="h-8 w-8 opacity-75" />
          </div>
        </div>

        {/* Amount Display */}
        <div className="mb-6 p-4 bg-gray-50 rounded-xl">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">Total Amount</p>
            <p className="text-2xl font-bold text-gray-900">
              {currency} {amount}
            </p>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        {/* Payment Form */}
        {!processing ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {paymentMethod === 'Card' ? 'Card Number' : 'Phone Number'}
              </label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value);
                    setError('');
                  }}
                  placeholder={paymentMethod === 'Card' ? 'Enter card number' : 'Enter phone number'}
                  className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-gray-900"
                  required
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {paymentMethod === 'Card' 
                  ? 'This is a demo payment. Enter any card number to proceed.'
                  : 'Enter your mobile number to complete the payment.'}
              </p>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
            >
              <CreditCard className="h-5 w-5" />
              Process Payment
            </button>
          </form>
        ) : (
          <div className="text-center py-8">
            <Loader2 className="h-12 w-12 text-blue-600 animate-spin mx-auto mb-4" />
            <p className="text-lg font-semibold text-gray-800">Processing Payment...</p>
            <p className="text-sm text-gray-500 mt-2">Please wait while we process your payment</p>
          </div>
        )}

        {/* Demo Notice */}
        {!processing && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-xl">
            <p className="text-xs text-blue-800 text-center">
              <strong>Demo Mode:</strong> This is a simulated payment. No actual transaction will be processed.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentModal;








