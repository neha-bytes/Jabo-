// ==========================================
// FILE: frontend/src/components/layout/Layout.jsx
// ==========================================

import { Outlet, Navigate, useLocation } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import { useAuth } from '../../context/AuthContext';

const Layout = () => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (!loading && user?.role === 'driver') {
    if (location.pathname !== '/driver-dashboard') {
      return <Navigate to="/driver-dashboard" replace />;
    }
    return null;
  }

  // Hide footer on dashboard pages
  const hideFooter = location.pathname === '/dashboard' || location.pathname.startsWith('/booking-details');

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Outlet />
      </main>
      {!hideFooter && <Footer />}
    </div>
  );
};

export default Layout;

