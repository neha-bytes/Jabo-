import React from 'react';

const Section = ({
  children,
  className = '',
  background = 'white',
  padding = 'normal',
}) => {
  const backgrounds = {
    white: 'bg-white',
    gray: 'bg-gradient-to-b from-gray-50 to-white',
    gradient: 'bg-gradient-to-b from-blue-50 via-purple-50 to-blue-50',
  };

  const paddings = {
    sm: 'py-12',
    normal: 'py-24',
    lg: 'py-32',
  };

  return (
    <section className={`${backgrounds[background]} ${paddings[padding]} ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {children}
      </div>
    </section>
  );
};

export default Section;
