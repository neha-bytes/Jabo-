import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Bus, Menu, X, User, LogOut, LayoutDashboard, MessageSquare } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsOpen(false);
    setShowUserMenu(false);
  };

  return (
    <nav className="bg-white/80 backdrop-blur-lg shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="relative">
                {/* Outer glow ring */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl blur-md opacity-60 group-hover:opacity-100 transition-all duration-500 group-hover:blur-lg"></div>

                {/* Main logo container */}
                <div className="relative p-3 bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 rounded-2xl group-hover:scale-110 transition-all duration-500 shadow-xl">
                  {/* Animated shine effect */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 group-hover:animate-pulse"></div>

                  {/* Bus icon with motion trail effect */}
                  <div className="relative">
                    <Bus className="h-7 w-7 text-white relative z-10 group-hover:translate-x-0.5 transition-transform duration-500" />
                    {/* Motion trail */}
                    <Bus className="h-7 w-7 text-white/30 absolute top-0 left-0 -translate-x-1 opacity-0 group-hover:opacity-100 transition-all duration-500" />
                  </div>

                  {/* Corner accent */}
                  <div className="absolute top-1 right-1 w-2 h-2 bg-white/40 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
                </div>
              </div>

              {/* Brand name with enhanced gradient */}
              <div className="flex flex-col">
                <span className="text-2xl font-black bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 bg-clip-text text-transparent tracking-tight group-hover:tracking-wide transition-all duration-300">
                  JABO
                </span>
                <span className="text-[10px] font-semibold text-gray-400 tracking-widest uppercase -mt-1 opacity-0 group-hover:opacity-100 transition-all duration-300">
                  Bus Service
                </span>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            <Link
              to="/"
              className="px-4 py-2 text-gray-700 hover:text-blue-600 font-medium transition-all duration-200 rounded-lg hover:bg-blue-50/50 relative group"
            >
              Home
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-blue-600 group-hover:w-3/4 transition-all duration-300"></span>
            </Link>
            <Link
              to="/search"
              className="px-4 py-2 text-gray-700 hover:text-blue-600 font-medium transition-all duration-200 rounded-lg hover:bg-blue-50/50 relative group"
            >
              Find Buses
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-blue-600 group-hover:w-3/4 transition-all duration-300"></span>
            </Link>

            {user ? (
              <div className="relative ml-4">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 px-4 py-2.5 text-gray-700 hover:text-blue-600 font-medium transition-all duration-200 rounded-xl hover:bg-blue-50/50 border border-transparent hover:border-blue-100"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
                    <User className="h-4 w-4 text-white" />
                  </div>
                  <span className="max-w-32 truncate">{user.name}</span>
                </button>

                {showUserMenu && (
                  <>
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setShowUserMenu(false)}
                    ></div>
                    <div className="absolute right-0 mt-3 w-56 bg-white/95 backdrop-blur-xl rounded-2xl shadow-xl py-2 z-20 border border-gray-100 overflow-hidden">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="text-sm font-semibold text-gray-900 truncate">{user.name}</p>
                        <p className="text-xs text-gray-500 mt-0.5 capitalize">{user.role}</p>
                      </div>

                      {/* Dashboard Link - Different for each role */}
                      {user.role === 'admin' ? (
                        <Link
                          to="/admin"
                          onClick={() => setShowUserMenu(false)}
                          className="flex items-center px-4 py-2.5 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 group"
                        >
                          <LayoutDashboard className="h-4 w-4 mr-3 group-hover:scale-110 transition-transform" />
                          <span className="font-medium">Dashboard</span>
                        </Link>
                      ) : user.role === 'driver' ? (
                        <Link
                          to="/driver-dashboard"
                          onClick={() => setShowUserMenu(false)}
                          className="flex items-center px-4 py-2.5 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 group"
                        >
                          <LayoutDashboard className="h-4 w-4 mr-3 group-hover:scale-110 transition-transform" />
                          <span className="font-medium">Dashboard</span>
                        </Link>
                      ) : (
                        <Link
                          to="/dashboard"
                          onClick={() => setShowUserMenu(false)}
                          className="flex items-center px-4 py-2.5 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 group"
                        >
                          <LayoutDashboard className="h-4 w-4 mr-3 group-hover:scale-110 transition-transform" />
                          <span className="font-medium">Dashboard</span>
                        </Link>
                      )}

                      {/* Help / Complaints */}
                      <Link
                        to="/complaints"
                        onClick={() => setShowUserMenu(false)}
                        className="flex items-center px-4 py-2.5 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200 group"
                      >
                        <MessageSquare className="h-4 w-4 mr-3 group-hover:scale-110 transition-transform" />
                        <span className="font-medium">Help / Complaints</span>
                      </Link>

                      {/* Logout */}
                      <div className="border-t border-gray-100 mt-2 pt-2">
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center px-4 py-2.5 text-red-600 hover:bg-red-50 transition-all duration-200 group"
                        >
                          <LogOut className="h-4 w-4 mr-3 group-hover:scale-110 transition-transform" />
                          <span className="font-medium">Logout</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-3 ml-4">
                <Link
                  to="/login"
                  className="px-5 py-2.5 text-gray-700 hover:text-blue-600 font-medium transition-all duration-200 rounded-xl hover:bg-blue-50/50"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="relative px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 hover:scale-105 overflow-hidden group"
                >
                  <span className="relative z-10">Sign Up</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-gray-700 hover:text-blue-600 transition-all duration-200 rounded-xl hover:bg-blue-50/50"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-1 animate-in slide-in-from-top duration-300">
            <Link
              to="/"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
            >
              Home
            </Link>
            <Link
              to="/search"
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
            >
              Find Buses
            </Link>

            {user ? (
              <>
                <div className="pt-2 mt-2 border-t border-gray-100">
                  <div className="px-4 py-3 bg-blue-50/30 rounded-xl mb-2">
                    <p className="text-sm font-semibold text-gray-900 truncate">{user.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5 capitalize">{user.role}</p>
                  </div>

                  {/* Dashboard Link - Different for each role */}
                  {user.role === 'admin' ? (
                    <Link
                      to="/admin"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
                    >
                      <LayoutDashboard className="h-5 w-5 mr-3" />
                      Dashboard
                    </Link>
                  ) : user.role === 'driver' ? (
                    <Link
                      to="/driver-dashboard"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
                    >
                      <LayoutDashboard className="h-5 w-5 mr-3" />
                      Dashboard
                    </Link>
                  ) : (
                    <Link
                      to="/dashboard"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
                    >
                      <LayoutDashboard className="h-5 w-5 mr-3" />
                      Dashboard
                    </Link>
                  )}

                  {/* Help / Complaints */}
                  <Link
                    to="/complaints"
                    onClick={() => setIsOpen(false)}
                    className="flex items-center px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl"
                  >
                    <MessageSquare className="h-5 w-5 mr-3" />
                    Help / Complaints
                  </Link>

                  {/* Logout */}
                  <button
                    onClick={handleLogout}
                    className="flex items-center w-full px-4 py-3 text-red-600 hover:bg-red-50 font-medium transition-all duration-200 rounded-xl mt-2"
                  >
                    <LogOut className="h-5 w-5 mr-3" />
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col space-y-2 pt-4 mt-2 border-t border-gray-100">
                <Link
                  to="/login"
                  onClick={() => setIsOpen(false)}
                  className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50/50 font-medium transition-all duration-200 rounded-xl text-center"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  onClick={() => setIsOpen(false)}
                  className="block bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-300 text-center font-medium shadow-lg shadow-blue-500/30"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
