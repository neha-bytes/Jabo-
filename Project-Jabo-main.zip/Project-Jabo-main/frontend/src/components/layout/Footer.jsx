// frontend/src/components/layout/Footer.jsx

import { Link } from 'react-router-dom';
import { Bus, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, ArrowRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#0b1120] text-gray-300 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">

          {/* Brand Section */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Bus className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white tracking-wide">JABO</span>
            </div>
            <p className="text-gray-400 leading-relaxed text-sm">
              Your trusted partner for safe and comfortable bus journeys across Bangladesh. Experience premium travel with just a few clicks.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="bg-gray-800 hover:bg-blue-600 text-white p-2 rounded-full transition-all duration-300">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-400 text-white p-2 rounded-full transition-all duration-300">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-pink-600 text-white p-2 rounded-full transition-all duration-300">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-700 text-white p-2 rounded-full transition-all duration-300">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold text-white mb-6">Quick Links</h3>
            <ul className="space-y-3 font-medium">
              <li>
                <Link to="/" className="group flex items-center gap-2 hover:text-blue-400 transition-colors">
                  <ArrowRight className="h-4 w-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="group-hover:translate-x-1 transition-transform">Home</span>
                </Link>
              </li>
              <li>
                <Link to="/buses" className="group flex items-center gap-2 hover:text-blue-400 transition-colors">
                  <ArrowRight className="h-4 w-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="group-hover:translate-x-1 transition-transform">Find Buses</span>
                </Link>
              </li>
              <li>
                <Link to="/about" className="group flex items-center gap-2 hover:text-blue-400 transition-colors">
                  <ArrowRight className="h-4 w-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="group-hover:translate-x-1 transition-transform">About Us</span>
                </Link>
              </li>
              <li>
                <Link to="/contact" className="group flex items-center gap-2 hover:text-blue-400 transition-colors">
                  <ArrowRight className="h-4 w-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="group-hover:translate-x-1 transition-transform">Contact</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-bold text-white mb-6">Support</h3>
            <ul className="space-y-3 font-medium">
              <li>
                <Link to="/faq" className="hover:text-blue-400 transition-colors">FAQ</Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-blue-400 transition-colors">Terms & Conditions</Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-blue-400 transition-colors">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cancellation" className="hover:text-blue-400 transition-colors">Cancellation Policy</Link>
              </li>
              <li>
                <Link to="/complaints" className="hover:text-blue-400 transition-colors">Report Issue</Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold text-white mb-6">Get in Touch</h3>
            <ul className="space-y-4 text-sm font-medium">
              <li className="flex items-start gap-4">
                <div className="bg-gray-800 p-2 rounded-lg shrink-0">
                  <MapPin className="h-5 w-5 text-blue-400" />
                </div>
                <span>
                  Level 4, JABO Tower,<br />
                  Banani, Dhaka-1213,<br />
                  Bangladesh
                </span>
              </li>
              <li className="flex items-center gap-4">
                <div className="bg-gray-800 p-2 rounded-lg shrink-0">
                  <Phone className="h-5 w-5 text-blue-400" />
                </div>
                <span>+880 1712-345678</span>
              </li>
              <li className="flex items-center gap-4">
                <div className="bg-gray-800 p-2 rounded-lg shrink-0">
                  <Mail className="h-5 w-5 text-blue-400" />
                </div>
                <span>support@jabo.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500 text-center md:text-left">
            &copy; {new Date().getFullYear()} JABO Technologies. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms</Link>
            <Link to="/sitemap" className="hover:text-white transition-colors">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
