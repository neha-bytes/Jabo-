import React from 'react';

const PageContainer = ({ children, variant = 'default', className = '' }) => {
  const variants = {
    default: 'bg-white',
    gradient: 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50',
    dark: 'bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900',
  };

  return (
    <div className={`min-h-screen ${variants[variant]} ${className}`}>
      {children}
    </div>
  );
};

export default PageContainer;
