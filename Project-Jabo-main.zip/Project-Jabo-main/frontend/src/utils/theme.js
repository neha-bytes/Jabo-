// frontend/src/utils/theme.js

export const theme = {
  // Color palette
  colors: {
    primary: {
      50: "#eff6ff",
      100: "#dbeafe",
      200: "#bfdbfe",
      300: "#93c5fd",
      400: "#60a5fa",
      500: "#3b82f6",
      600: "#2563eb",
      700: "#1d4ed8",
      800: "#1e40af",
      900: "#1e3a8a",
    },
    secondary: {
      purple: {
        50: "#faf5ff",
        500: "#a855f7",
        600: "#9333ea",
      },
      indigo: {
        50: "#eef2ff",
        500: "#6366f1",
      },
      orange: {
        50: "#fff7ed",
        500: "#f59e0b",
        600: "#ea580c",
      },
    },
    neutral: {
      50: "#f9fafb",
      100: "#f3f4f6",
      200: "#e5e7eb",
      300: "#d1d5db",
      700: "#374151",
      900: "#111827",
    },
  },

  // Gradient presets
  gradients: {
    primary: "from-blue-600 via-blue-700 to-blue-800",
    hero: "from-slate-900 via-blue-900 to-slate-900",
    card: "from-white to-gray-50",
    glass: "from-blue-50 via-indigo-50 to-purple-50",
  },

  // Border radius
  radius: {
    sm: "rounded-lg",
    md: "rounded-xl",
    lg: "rounded-2xl",
    xl: "rounded-3xl",
  },

  // Shadows
  shadows: {
    sm: "shadow-md",
    md: "shadow-lg",
    lg: "shadow-xl",
    xl: "shadow-2xl",
  },

  // Animations
  animations: {
    hover: "transition-all duration-300",
    hoverLift: "transition-all duration-500 transform hover:-translate-y-2",
    hoverScale: "transition-all duration-300 transform hover:scale-105",
  },
};
