// frontend/src/App.jsx

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import DriverSignup from './pages/DriverSignup';
import UserDashboard from './pages/UserDashboard';
import DriverDashboard from './pages/DriverDashboard';
import AdminDashboard from './pages/AdminDashboard';
import SearchResult from './pages/SearchResult';
import Booking from './pages/Booking';
import ShuttleBooking from './pages/ShuttleBooking';
import ShuttleStatus from './pages/ShuttleStatus';
import BookingDetails from './pages/BookingDetails';
import Complaints from './pages/Complaints';
import {
  AdminRoute,
  DriverRoute,
  UserRoute,
  PublicRoute,
  ProtectedRoute
} from './components/ProtectedRoutes';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <Toaster
          position="top-center"
          gutter={8}
          toastOptions={{
            duration: 3000,
            className: 'bg-white text-gray-900 rounded-lg shadow-lg border border-gray-200',
            style: { padding: '12px 16px' },
            success: {
              iconTheme: {
                primary: '#10B981',
                secondary: '#ffffff',
              },
            },
          }}
        />
        <Router>
          <Routes>
            {/* Public Routes - Redirect if already logged in */}
            <Route
              path="/login"
              element={
                <PublicRoute>
                  <Login />
                </PublicRoute>
              }
            />
            <Route
              path="/signup"
              element={
                <PublicRoute>
                  <Signup />
                </PublicRoute>
              }
            />
            <Route
              path="/driver-signup"
              element={
                <PublicRoute>
                  <DriverSignup />
                </PublicRoute>
              }
            />

            {/* Admin Routes - Only accessible by admins */}
            <Route
              path="/admin"
              element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              }
            />

            {/* Driver Routes - Only accessible by drivers */}
            <Route
              path="/driver-dashboard"
              element={
                <DriverRoute>
                  <DriverDashboard />
                </DriverRoute>
              }
            />

            {/* User Routes with Layout - Admins redirected to /admin */}
            <Route path="/" element={<Layout />}>
              <Route
                index
                element={
                  <ProtectedRoute allowPublic={true}>
                    <Home />
                  </ProtectedRoute>
                }
              />
              <Route
                path="dashboard"
                element={
                  <UserRoute>
                    <UserDashboard />
                  </UserRoute>
                }
              />
              <Route
                path="search"
                element={
                  <ProtectedRoute allowPublic={true}>
                    <SearchResult />
                  </ProtectedRoute>
                }
              />
              <Route
                path="booking"
                element={
                  <ProtectedRoute allowPublic={true}>
                    <Booking />
                  </ProtectedRoute>
                }
              />
              <Route
                path="shuttle-booking"
                element={
                  <ProtectedRoute allowPublic={true}>
                    <ShuttleBooking />
                  </ProtectedRoute>
                }
              />
              <Route
                path="booking-details/:bookingId"
                element={
                  <UserRoute>
                    <BookingDetails />
                  </UserRoute>
                }
              />
              <Route
                path="complaints"
                element={
                  <UserRoute>
                    <Complaints />
                  </UserRoute>
                }
              />
            </Route>

            {/* Shuttle Status - Can be accessed by anyone authenticated */}
            <Route
              path="/shuttle/status/:requestId"
              element={
                <ProtectedRoute>
                  <ShuttleStatus />
                </ProtectedRoute>
              }
            />

            {/* 404 - Catch all unmatched routes */}
            <Route
              path="*"
              element={
                <div className="min-h-screen flex items-center justify-center bg-gray-50">
                  <div className="text-center">
                    <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
                    <p className="text-xl text-gray-600 mb-8">Page not found</p>
                    <a
                      href="/"
                      className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Go Home
                    </a>
                  </div>
                </div>
              }
            />
          </Routes>
        </Router>
      </SocketProvider>
    </AuthProvider>
  );
}

export default App;
