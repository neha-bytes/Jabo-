import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {
  LayoutDashboard,
  Bus,
  Car,
  MessageCircle,
  UserRound,
  LogOut,
  Bell,
  Navigation,
  SendHorizontal,
  Loader2,
  Phone,
  Clock,
  Compass,
  Wifi,
  WifiOff,
  Circle,
  Menu,
  X,
  CreditCard,
  CalendarDays,
  Map,
  ShieldCheck,
  Zap,
  CheckCircle2,
  AlertCircle,
  Star,
  MoreVertical,
} from 'lucide-react';
import { MapContainer, Marker, Polyline, TileLayer } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import Skeleton from '../components/common/Skeleton';
import { getMyBookings } from '../services/bookingService';
import {
  fetchUserShuttles,
  fetchShuttleById,
  fetchShuttleMessages,
} from '../services/shuttleService';
import { authService } from '../services/authService';
import { createReview, checkCanReview } from '../services/reviewService';
import RatingModal from '../components/RatingModal';

const ACTIVE_RIDE_STATUSES = ['pending', 'accepted', 'on_the_way', 'arrived', 'started'];
const DEFAULT_STATS = { total: 0, upcoming: 0, completed: 0, cancelled: 0 };
const DEFAULT_CENTER = [23.8103, 90.4125];

const STATUS_CONFIG = {
  pending: { label: 'Pending', color: 'bg-amber-100 text-amber-800' },
  accepted: { label: 'Driver Assigned', color: 'bg-blue-100 text-blue-800' },
  on_the_way: { label: 'Driver On The Way', color: 'bg-indigo-100 text-indigo-800' },
  arrived: { label: 'Driver Arrived', color: 'bg-purple-100 text-purple-800' },
  started: { label: 'Ride In Progress', color: 'bg-slate-100 text-slate-800' },
  completed: { label: 'Completed', color: 'bg-emerald-100 text-emerald-800' },
  cancelled: { label: 'Cancelled', color: 'bg-rose-100 text-rose-800' },
};

const TIMELINE_STEPS = [
  { key: 'pending', label: 'Request Sent' },
  { key: 'accepted', label: 'Driver Accepted' },
  { key: 'on_the_way', label: 'Driver On The Way' },
  { key: 'arrived', label: 'Reached Pickup' },
  { key: 'started', label: 'Trip Started' },
  { key: 'completed', label: 'Completed' },
];

const buildMarkerIcon = (label, color) =>
  L.divIcon({
    html: `<div style="background:${color};color:#fff;font-weight:700;border-radius:9999px;padding:6px 10px;font-size:12px;border:2px solid #fff;box-shadow:0 8px 16px rgba(15,23,42,0.25);display:flex;align-items:center;justify-content:center;min-width:32px;">${label}</div>`,
    className: '',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
  });

const pickupIcon = buildMarkerIcon('P', '#16a34a');
const dropoffIcon = buildMarkerIcon('D', '#dc2626');
const driverIcon = buildMarkerIcon('🚗', '#2563eb');

// Helper function to parse 12-hour time format (e.g., "06:00 AM", "10:00 PM")
const parseTime12Hour = (timeStr) => {
  if (!timeStr) return null;

  const trimmed = timeStr.trim().toUpperCase();
  const match = trimmed.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/);

  if (!match) {
    // Try 24-hour format as fallback
    const parts = trimmed.split(':');
    if (parts.length >= 2) {
      const hours = parseInt(parts[0], 10);
      const minutes = parseInt(parts[1], 10);
      if (!isNaN(hours) && !isNaN(minutes)) {
        return { hours, minutes };
      }
    }
    return null;
  }

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3];

  if (isNaN(hours) || isNaN(minutes)) return null;

  // Convert to 24-hour format
  if (period === 'PM' && hours !== 12) {
    hours += 12;
  } else if (period === 'AM' && hours === 12) {
    hours = 0;
  }

  return { hours, minutes };
};

// Helper to format journey date with actual departure time
const formatJourneyDateTime = (journeyDate, bus) => {
  if (!journeyDate) return 'N/A';

  const date = new Date(journeyDate);
  let dateStr = date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  // If bus schedule is available, add the actual departure time
  if (bus?.schedule?.departureTime) {
    return `${dateStr} at ${bus.schedule.departureTime}`;
  }

  return dateStr;
};

// Helper to check if bus has already departed
const hasBusDeparted = (journeyDate, bus) => {
  if (!journeyDate || !bus?.schedule?.departureTime) return false;

  try {
    const departureDateTime = getBusDepartureDateTime(journeyDate, bus);
    if (!departureDateTime) return false;

    return new Date() > departureDateTime;
  } catch (error) {
    return false;
  }
};

// Helper function to get bus departure datetime (reuse from ShuttleBooking logic)
const getBusDepartureDateTime = (journeyDate, bus) => {
  if (!journeyDate || !bus?.schedule?.departureTime) return null;

  try {
    const date = new Date(journeyDate);
    const timeParts = parseTime12Hour(bus.schedule.departureTime);

    if (!timeParts) {
      return null;
    }

    date.setHours(timeParts.hours, timeParts.minutes, 0, 0);
    return date;
  } catch (error) {
    return null;
  }
};

const formatDateTime = (value) => {
  if (!value) return 'Not available';
  const date = new Date(value);
  return date.toLocaleString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const formatStatus = (status) => STATUS_CONFIG[status]?.label || status;

const toLatLng = (coords) =>
  Array.isArray(coords) && coords.length === 2 ? [coords[1], coords[0]] : null;

const StatusBadge = ({ status }) => {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.pending;
  return (
    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${config.color}`}>
      {config.label}
    </span>
  );
};

const EmptyState = ({ title, description, action }) => (
  <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-10 text-center">
    <p className="text-lg font-semibold text-slate-800">{title}</p>
    <p className="mt-2 text-sm text-slate-500">{description}</p>
    {action}
  </div>
);

const LiveTrackMap = ({ pickup, dropoff, driverLocation }) => {
  const pickupLatLng = toLatLng(pickup?.coordinates);
  const dropoffLatLng = toLatLng(dropoff?.coordinates);
  const driverLatLng = toLatLng(driverLocation?.coordinates);
  const center = driverLatLng || pickupLatLng || dropoffLatLng || DEFAULT_CENTER;

  return (
    <div className="h-80 overflow-hidden rounded-2xl border border-slate-200">
      <MapContainer center={center} zoom={13} className="h-full w-full">
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {pickupLatLng && <Marker position={pickupLatLng} icon={pickupIcon} />}
        {dropoffLatLng && <Marker position={dropoffLatLng} icon={dropoffIcon} />}
        {driverLatLng && <Marker position={driverLatLng} icon={driverIcon} />}
        {pickupLatLng && dropoffLatLng && (
          <Polyline
            positions={[pickupLatLng, dropoffLatLng]}
            pathOptions={{ color: '#2563eb', weight: 4, dashArray: '8 8' }}
          />
        )}
      </MapContainer>
    </div>
  );
};

const UserDashboard = () => {
  const { user, logout, checkAuth } = useAuth();
  const { socket, isConnected } = useSocket();
  const navigate = useNavigate();

  const [activeNav, setActiveNav] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [bookings, setBookings] = useState([]);
  const [bookingStats, setBookingStats] = useState(DEFAULT_STATS);
  const [activeBooking, setActiveBooking] = useState(null);
  const [shuttles, setShuttles] = useState([]);
  const [activeShuttle, setActiveShuttle] = useState(null);
  const [driverLocation, setDriverLocation] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [typingPeers, setTypingPeers] = useState({});
  const [profileForm, setProfileForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    studentId: user?.studentId || '',
    preferredPickup: user?.address?.street || '',
  });
  const [profileSaving, setProfileSaving] = useState(false);
  const [isFetchingMessages, setIsFetchingMessages] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [ratingModalOpen, setRatingModalOpen] = useState(false);
  const [selectedShuttleForRating, setSelectedShuttleForRating] = useState(null);
  const [submittingRating, setSubmittingRating] = useState(false);

  const typingTimeoutRef = useRef(null);
  const chatEndRef = useRef(null);

  const navItems = useMemo(
    () => [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'bookings', label: 'My Bus Bookings', icon: Bus },
      { id: 'shuttles', label: 'My Shuttle Requests', icon: Car },
      {
        id: 'live',
        label: 'Live Track',
        icon: Navigation,
        disabled: !activeShuttle,
      },
      {
        id: 'chat',
        label: 'Chat',
        icon: MessageCircle,
        disabled: !activeShuttle,
      },
      { id: 'profile', label: 'Profile', icon: UserRound },
    ],
    [activeShuttle]
  );

  const pushNotification = useCallback((title, detail, type = 'info') => {
    const entry = {
      id: `${Date.now()}-${Math.random()}`,
      title,
      detail,
      type,
      timestamp: new Date().toISOString(),
    };
    setNotifications((prev) => [entry, ...prev].slice(0, 5));
  }, []);

  const deriveActiveShuttle = useCallback((list) => {
    return list.find((ride) => ACTIVE_RIDE_STATUSES.includes(ride.status)) || null;
  }, []);

  const refreshShuttleById = useCallback(
    async (shuttleId) => {
      if (!shuttleId) return;
      try {
        const response = await fetchShuttleById(shuttleId);
        if (!response?.success) return;
        const shuttle = response.data;
        setShuttles((prev) => {
          const idx = prev.findIndex((item) => item._id === shuttle._id);
          if (idx === -1) {
            return [shuttle, ...prev].slice(0, 25);
          }
          const copy = [...prev];
          copy[idx] = shuttle;
          return copy;
        });
        if (ACTIVE_RIDE_STATUSES.includes(shuttle.status)) {
          setActiveShuttle(shuttle);
          setDriverLocation(shuttle.driverLocation || null);
        } else if (activeShuttle?._id === shuttle._id) {
          setActiveShuttle(shuttle);
        }
      } catch (error) {
        console.error('Failed to refresh shuttle', error);
      }
    },
    [activeShuttle]
  );

  const loadInitialData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [bookingRes, shuttleRes] = await Promise.all([
        getMyBookings({ limit: 25 }),
        fetchUserShuttles({ limit: 25 }),
      ]);

      if (bookingRes?.success) {
        setBookings(bookingRes.data?.bookings || []);
        setActiveBooking(bookingRes.data?.activeBooking || null);
        setBookingStats(bookingRes.data?.stats || DEFAULT_STATS);
      }

      if (shuttleRes?.success) {
        const list = shuttleRes.data || [];
        setShuttles(list);
        const current = deriveActiveShuttle(list);
        setActiveShuttle(current);
        setDriverLocation(current?.driverLocation || null);
        if (current?.timeline?.length) {
          const latest = current.timeline
            .slice(-3)
            .reverse()
            .map((entry) => ({
              id: `${entry.status}-${entry.at}`,
              title: formatStatus(entry.status),
              detail: entry.label,
              type: 'status',
              timestamp: entry.at,
            }));
          setNotifications((prev) => [...latest, ...prev].slice(0, 5));
        }
      }
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to load dashboard data';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, [deriveActiveShuttle, user]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (!activeShuttle?._id) {
      setChatMessages([]);
      return;
    }
    const fetchMessages = async () => {
      try {
        setIsFetchingMessages(true);
        const response = await fetchShuttleMessages(activeShuttle._id, { limit: 100 });
        if (response && response.success) {
          setChatMessages(response.data || []);
        }
      } catch (error) {
        // Only log non-403 errors (403 means not authorized, which is expected in some cases)
        if (error.response?.status !== 403) {
          console.error('Unable to load chat history', error);
        }
        // Don't set error state for 403 - user might not be authorized yet (e.g., no driver assigned)
        setChatMessages([]);
      } finally {
        setIsFetchingMessages(false);
      }
    };
    fetchMessages();
  }, [activeShuttle?._id]);

  useEffect(() => {
    if (!socket || !activeShuttle?._id) return;
    socket.emit('shuttle:join', activeShuttle._id);
    return () => {
      socket.emit('shuttle:leave', activeShuttle._id);
    };
  }, [socket, activeShuttle?._id]);

  useEffect(() => {
    if (!socket) return;

    const handleShuttleCreated = ({ shuttleId }) => {
      pushNotification('Shuttle request submitted', 'We are finding a driver for you.');
      refreshShuttleById(shuttleId);
    };

    const handleShuttleAssigned = ({ shuttleId, driver }) => {
      pushNotification(
        'Driver accepted your request',
        driver?.name ? `${driver.name} is heading to you` : 'Driver is on the way',
        'status'
      );
      refreshShuttleById(shuttleId);
    };

    const handleDriverLocation = (location) => {
      setDriverLocation(location);
      setActiveShuttle((prev) =>
        prev
          ? {
            ...prev,
            driverLocation: location,
            activeRideMetrics: {
              ...prev.activeRideMetrics,
              lastUpdated: new Date().toISOString(),
            },
          }
          : prev
      );
    };

    const handleRideStatus = ({ shuttleId, status }) => {
      pushNotification('Ride status updated', formatStatus(status), 'status');
      refreshShuttleById(shuttleId);
    };

    const handleChatMessage = (message) => {
      // Only add message if it's for the active shuttle
      if (activeShuttle && message.shuttleId === activeShuttle._id) {
        setChatMessages((prev) => {
          // Check if message already exists to prevent duplicates
          const exists = prev.some(m => m._id === message._id);
          if (exists) return prev;
          return [...prev, message];
        });
        if (message.senderType === 'driver') {
          pushNotification('Driver messaged you', message.content, 'chat');
        }
      }
    };

    const handleTyping = ({ shuttleId, userId, isTyping }) => {
      if (!activeShuttle || shuttleId !== activeShuttle._id || userId === user?.id) return;
      setTypingPeers((prev) => ({ ...prev, [userId]: isTyping }));
    };

    const handleSocketError = (error) => {
      console.error('Socket error:', error);
      if (error.message) {
        toast.error(error.message);
      }
    };

    socket.on('shuttle-created', handleShuttleCreated);
    socket.on('shuttle-assigned', handleShuttleAssigned);
    socket.on('driver-location', handleDriverLocation);
    socket.on('ride-status-changed', handleRideStatus);
    socket.on('chat:message', handleChatMessage);
    socket.on('chat:typing', handleTyping);
    socket.on('error', handleSocketError);

    return () => {
      socket.off('shuttle-created', handleShuttleCreated);
      socket.off('shuttle-assigned', handleShuttleAssigned);
      socket.off('driver-location', handleDriverLocation);
      socket.off('ride-status-changed', handleRideStatus);
      socket.off('chat:message', handleChatMessage);
      socket.off('chat:typing', handleTyping);
      socket.off('error', handleSocketError);
    };
  }, [socket, pushNotification, refreshShuttleById, activeShuttle, user?.id]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  useEffect(() => {
    setProfileForm({
      name: user?.name || '',
      phone: user?.phone || '',
      studentId: user?.studentId || '',
      preferredPickup: user?.address?.street || '',
    });
  }, [user]);

  useEffect(() => {
    if (!activeShuttle && (activeNav === 'live' || activeNav === 'chat')) {
      setActiveNav('dashboard');
    }
  }, [activeShuttle, activeNav]);

  useEffect(
    () => () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    },
    []
  );

  const handleSendMessage = () => {
    if (!chatInput.trim() || !socket || !activeShuttle) return;

    const messageContent = chatInput.trim();
    setChatInput(''); // Clear input immediately for better UX

    try {
      socket.emit('chat:message', {
        shuttleId: activeShuttle._id,
        content: messageContent,
      });
      socket.emit('chat:typing', { shuttleId: activeShuttle._id, isTyping: false });
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message. Please try again.');
      setChatInput(messageContent); // Restore input on error
    }
  };

  const handleChatInputChange = (value) => {
    setChatInput(value);
    if (!socket || !activeShuttle) return;
    socket.emit('chat:typing', { shuttleId: activeShuttle._id, isTyping: !!value.trim() });
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit('chat:typing', { shuttleId: activeShuttle._id, isTyping: false });
    }, 1200);
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      setProfileSaving(true);
      await authService.updateProfile({
        name: profileForm.name,
        phone: profileForm.phone,
        studentId: profileForm.studentId,
        address: { street: profileForm.preferredPickup },
      });
      toast.success('Profile updated');
      await checkAuth();
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to update profile';
      toast.error(message);
    } finally {
      setProfileSaving(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const activeTyping = Object.entries(typingPeers).some(([, isTyping]) => isTyping);

  const renderLoadingState = () => (
    <div className="space-y-6 animate-pulse">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-24 bg-gray-200 rounded-2xl"></div>
        ))}
      </div>
      <div className="h-64 bg-gray-200 rounded-3xl"></div>
      <div className="h-40 bg-gray-200 rounded-3xl"></div>
    </div>
  );

  const renderNotifications = () => (
    <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-white/20 shadow-lg shadow-gray-200/50 p-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-amber-100/50 to-orange-100/50 rounded-full blur-2xl -mr-10 -mt-10"></div>

      <div className="relative z-10 flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
          <div className="p-2 bg-amber-100 text-amber-600 rounded-xl">
            <Bell className="h-5 w-5" />
          </div>
          Notifications
        </h3>
        <span className="text-xs font-semibold bg-gray-100 text-gray-500 px-2 py-1 rounded-full">Recent</span>
      </div>

      <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar relative z-10">
        {notifications.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <Bell className="h-8 w-8 mx-auto mb-2 opacity-20" />
            <p className="text-sm">No new notifications</p>
          </div>
        )}
        {notifications.map((item) => (
          <div key={item.id} className="group p-3 rounded-2xl bg-gray-50 hover:bg-white border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all duration-300">
            <div className="flex justify-between items-start gap-2">
              <p className="text-sm font-semibold text-gray-800 leading-tight">{item.title}</p>
              <span className="text-[10px] whitespace-nowrap text-gray-400 font-medium bg-white px-1.5 py-0.5 rounded-full border border-gray-100">
                {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1 line-clamp-2">{item.detail}</p>
          </div>
        ))}
      </div>
    </div>
  );

  const renderActiveShuttleCard = () => {
    if (!activeShuttle) {
      return (
        <div className="rounded-3xl border-2 border-dashed border-gray-200 bg-gray-50/50 p-8 text-center hover:bg-white hover:border-blue-200 transition-all duration-300">
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-500">
            <Car className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">No Active Shuttle</h3>
          <p className="text-sm text-gray-500 max-w-sm mx-auto mb-6">
            Book a shuttle to get seamless last-mile connectivity from your bus stop.
          </p>
          <button
            onClick={() => navigate('/shuttle-booking')}
            className="inline-flex items-center gap-2 bg-gray-900 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-600 transition-colors shadow-lg hover:shadow-blue-200"
          >
            <Car className="h-4 w-4" /> Request Shuttle
          </button>
        </div>
      );
    }

    return (
      <div className="group rounded-3xl border border-white/20 bg-white/60 backdrop-blur-xl shadow-xl shadow-blue-900/5 overflow-hidden transition-all hover:shadow-2xl hover:shadow-blue-900/10 hover:bg-white/80">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
          <Zap className="w-32 h-32 text-blue-600 rotate-12" />
        </div>

        <div className="p-6 relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-600/30">
                <Car className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-0.5">Active Trip</p>
                <h3 className="text-lg font-bold text-gray-900">Shuttle #{activeShuttle.shuttleReference}</h3>
              </div>
            </div>
            <StatusBadge status={activeShuttle.status} />
          </div>

          <div className="flex flex-col md:flex-row gap-6 mb-6">
            <div className="flex-1 space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  <div className="w-2 h-2 rounded-full bg-green-500 mb-1"></div>
                  <div className="w-0.5 h-8 bg-gray-200 mx-auto"></div>
                  <div className="w-2 h-2 rounded-full bg-red-500 mt-1"></div>
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-semibold">Pickup</p>
                    <p className="font-medium text-gray-900">{activeShuttle.pickup?.address}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-semibold">Drop-off</p>
                    <p className="font-medium text-gray-900">{activeShuttle.dropoff?.address}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                <p className="text-xs text-gray-400 uppercase font-semibold mb-1">Vehicle</p>
                <p className="font-bold text-gray-900 flex items-center gap-2">
                  {activeShuttle.vehicleType}
                </p>
              </div>
              <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                <p className="text-xs text-gray-400 uppercase font-semibold mb-1">Fare</p>
                <p className="font-bold text-gray-900">BDT {activeShuttle.fare?.total}</p>
              </div>
              <div className="col-span-2 bg-blue-50/50 rounded-2xl p-3 border border-blue-100">
                <p className="text-xs text-blue-400 uppercase font-semibold mb-1">Scheduled Time</p>
                <p className="font-bold text-blue-900 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  {formatDateTime(activeShuttle.scheduledTime)}
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setActiveNav('live')}
              className="flex-1 bg-blue-600 text-white h-12 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 hover:shadow-blue-300 flex items-center justify-center gap-2"
            >
              <Map className="w-4 h-4" /> Track Live
            </button>
            <button
              onClick={() => setActiveNav('chat')}
              className="flex-1 bg-white text-gray-700 border border-gray-200 h-12 rounded-xl font-bold hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> Message Driver
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderTimeline = () => {
    if (!activeShuttle) return null;
    const currentIndex = TIMELINE_STEPS.findIndex((step) => step.key === activeShuttle.status);
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-700">
          <Compass className="h-5 w-5 text-indigo-500" />
          <h3 className="text-base font-semibold">Live Shuttle Timeline</h3>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-6">
          {TIMELINE_STEPS.map((step, idx) => {
            const completed = currentIndex >= idx;
            return (
              <div key={step.key} className="text-center">
                <div
                  className={`mx-auto flex h-10 w-10 items-center justify-center rounded-full border-2 text-sm font-semibold ${completed
                    ? 'border-indigo-600 bg-indigo-600 text-white'
                    : 'border-slate-200 text-slate-400'
                    }`}
                >
                  {completed ? '✔' : idx + 1}
                </div>
                <p className={`mt-2 text-xs font-semibold ${completed ? 'text-slate-900' : 'text-slate-400'}`}>
                  {step.label}
                </p>
              </div>
            );
          })}
        </div>
        {activeShuttle.timeline?.length > 0 && (
          <div className="mt-6 space-y-3 text-sm">
            {activeShuttle.timeline
              .slice(-4)
              .reverse()
              .map((entry, index) => (
                <div key={`${entry.status}-${entry.at}-${index}-${entry.meta?.driver || entry.meta?.cancelledBy || ''}`} className="rounded-xl border border-slate-100 px-4 py-3">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-slate-800">{entry.label}</p>
                    <span className="text-xs text-slate-400">{formatDateTime(entry.at)}</span>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    );
  };

  // Replace the renderChatPanel function in UserDashboard.jsx (around line 691-760)

  // ==========================================
  // FRONTEND FIX: UserDashboard.jsx
  // Replace renderChatPanel function (around line 691)
  // ==========================================

  const renderChatPanel = (compact = false) => {
    if (!activeShuttle) {
      return (
        <EmptyState
          title="No active shuttle chat"
          description="Once a driver accepts your shuttle request, you can chat with them in real-time."
        />
      );
    }

    return (
      <div className={`rounded-2xl border border-slate-200 bg-white ${compact ? 'p-4' : 'p-6'}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-wide text-slate-400">Chatting about</p>
            <h3 className="text-lg font-semibold text-slate-900">
              {activeShuttle.pickup?.address} → {activeShuttle.dropoff?.address}
            </h3>
          </div>
          <StatusBadge status={activeShuttle.status} />
        </div>
        <div className={`mt-4 flex flex-col ${compact ? 'h-72' : 'h-[480px]'}`}>
          <div className="flex-1 space-y-3 overflow-y-auto pr-2">
            {isFetchingMessages && chatMessages.length === 0 && (
              <p className="text-center text-sm text-slate-500">Loading conversation…</p>
            )}
            {chatMessages.length === 0 && !isFetchingMessages && (
              <p className="text-center text-sm text-slate-500">No messages yet. Start the conversation!</p>
            )}
            {chatMessages.map((message) => {
              // *** CRITICAL FIX: Check if the senderId matches current user's ID ***
              // user.id is the logged-in user's ID (the passenger)
              // message.senderId is who actually sent this message
              const isMyMessage = message.senderId === user?.id;

              console.log('👤 User rendering message:', {
                messageId: message._id,
                senderType: message.senderType,
                senderId: message.senderId,
                myId: user?.id,
                isMyMessage,
                side: isMyMessage ? 'RIGHT' : 'LEFT'
              });

              return (
                <div
                  key={`${message._id}-${message.createdAt}`}
                  className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${isMyMessage
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-800'
                      }`}
                  >
                    <p>{message.content}</p>
                    <p className="mt-1 text-[11px] uppercase tracking-wide opacity-60">
                      {new Date(message.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>
          {activeTyping && (
            <p className="mt-2 text-xs text-slate-500">Driver is typing…</p>
          )}
          <div className="mt-4 flex items-center gap-3">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => handleChatInputChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Type your message…"
              className="flex-1 rounded-full border border-slate-200 px-4 py-2 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
            <button
              onClick={handleSendMessage}
              disabled={!chatInput.trim()}
              className="rounded-full bg-indigo-600 p-3 text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SendHorizontal className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    );
  };
  const renderDashboard = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-gray-900 to-slate-800 p-8 text-white shadow-xl shadow-slate-900/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
        <div className="relative z-10">
          <p className="text-indigo-200 font-medium mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
            User Dashboard
          </p>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Hello, {user?.name?.split(' ')[0]}! 👋</h2>
          <p className="text-slate-300 max-w-lg mb-8 text-lg">
            Manage your journeys, track shuttles, and explore new destinations all in one place.
          </p>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => navigate('/booking')}
              className="bg-white text-gray-900 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-all flex items-center gap-2"
            >
              <Bus className="h-5 w-5 text-indigo-600" /> Book Bus
            </button>
            <button
              onClick={() => navigate('/shuttle-booking')}
              className="bg-white/10 backdrop-blur-md text-white border border-white/20 px-6 py-3 rounded-xl font-bold hover:bg-white/20 transition-all flex items-center gap-2"
            >
              <Car className="h-5 w-5" /> Request Shuttle
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Total Bookings', value: bookingStats.total, icon: CalendarDays, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Upcoming Trips', value: bookingStats.upcoming, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Completed', value: bookingStats.completed, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Cancelled', value: bookingStats.cancelled, icon: AlertCircle, color: 'text-rose-600', bg: 'bg-rose-50' },
        ].map((item) => (
          <div key={item.label} className="group bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl ${item.bg} ${item.color} group-hover:scale-110 transition-transform`}>
                <item.icon className="h-6 w-6" />
              </div>
              <span className="text-2xl font-bold text-gray-900">{item.value}</span>
            </div>
            <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">{item.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-8 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-8">
          {/* Recent Booking Card */}
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Bus className="h-5 w-5 text-gray-400" />
                Current Bus Booking
              </h3>
              {activeBooking && <StatusBadge status={activeBooking.status} />}
            </div>

            {activeBooking ? (
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 border border-gray-200">
                <div className="flex flex-col sm:flex-row justify-between gap-6">
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-gray-400 uppercase font-bold mb-1">Bus Operator</p>
                      <h4 className="text-xl font-bold text-gray-900">{activeBooking.bus?.busName || 'Pending'}</h4>
                      <p className="text-gray-500 font-medium">
                        {activeBooking.bus?.route?.origin}
                        <span className="mx-2 text-gray-300">→</span>
                        {activeBooking.bus?.route?.destination}
                      </p>
                    </div>
                    <div className="flex gap-6">
                      <div>
                        <p className="text-xs text-gray-400 uppercase font-bold mb-1">Date & Time</p>
                        <p className="font-semibold text-gray-700">
                          {formatJourneyDateTime(activeBooking.journeyDate, activeBooking.bus)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase font-bold mb-1">Seats</p>
                        <p className="font-semibold text-gray-700">{activeBooking.seats?.join(', ') || 'N/A'}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-center items-end gap-3">
                    <div className="text-right">
                      <p className="text-xs text-gray-400 uppercase font-bold mb-1">Total Fare</p>
                      <p className="text-2xl font-bold text-blue-600">BDT {activeBooking.totalFare}</p>
                    </div>
                    <button
                      onClick={() => navigate(`/booking-details/${activeBooking._id}`)}
                      className="px-5 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-xl font-semibold text-sm hover:bg-gray-50 transition-colors shadow-sm"
                    >
                      View Ticket
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                <Bus className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">No active bus journey.</p>
                <button onClick={() => navigate('/booking')} className="mt-3 text-blue-600 font-bold text-sm hover:underline">
                  Book a new trip
                </button>
              </div>
            )}
          </div>

          {/* Active Shuttle Card */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-900 px-1">Live Shuttle Status</h3>
            {renderActiveShuttleCard()}
          </div>
        </div>
        <div className="space-y-8">
          {renderNotifications()}

          <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
            <h3 className="text-base font-bold text-gray-900 mb-4 flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-gray-400" />
              System Status
            </h3>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100 mb-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${isConnected ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                  <Wifi className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-900">Realtime Feed</p>
                  <p className={`text-xs font-semibold ${isConnected ? 'text-green-600' : 'text-red-500'}`}>
                    {isConnected ? 'Connected' : 'Disconnected'}
                  </p>
                </div>
              </div>
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
            </div>

            {activeShuttle && (
              <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                <p className="text-xs font-bold text-blue-800 uppercase mb-1">Active Tracker</p>
                <p className="text-sm text-blue-600 leading-relaxed">
                  You are currently tracking shuttle <span className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200">{activeShuttle.shuttleReference}</span>.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      {activeShuttle && (
        <div className="grid gap-6 lg:grid-cols-2">
          {renderTimeline()}
          {renderChatPanel(true)}
        </div>
      )}
    </div>
  );

  const renderBookings = () => {
    if (bookings.length === 0) {
      return (
        <EmptyState
          title="No bookings yet"
          description="Start by reserving a seat on your preferred bus route."
          action={
            <button
              onClick={() => navigate('/booking')}
              className="mt-4 rounded-full bg-indigo-600 px-6 py-3 text-sm font-bold text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
            >
              Find a bus
            </button>
          }
        />
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">My Bookings</h2>
          <div className="flex gap-2">
            <select className="bg-white border border-gray-200 text-gray-600 text-sm rounded-lg px-3 py-2 outline-none focus:border-indigo-500">
              <option>All Bookings</option>
              <option>Upcoming</option>
              <option>Completed</option>
              <option>Cancelled</option>
            </select>
          </div>
        </div>

        <div className="grid gap-6">
          {bookings.map((booking) => (
            <div
              key={booking._id}
              className="group bg-white rounded-3xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300"
            >
              {/* Ticket Header */}
              <div className="bg-slate-50 border-b border-gray-100 p-6 flex flex-wrap justify-between items-center gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white border border-gray-100 flex items-center justify-center text-indigo-600 shadow-sm">
                    <Bus className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">{booking.bus?.busName || 'Bus Service'}</h3>
                    <p className="text-sm text-gray-500 font-medium">Order #{booking._id.slice(-6).toUpperCase()}</p>
                  </div>
                </div>
                <StatusBadge status={booking.status} />
              </div>

              {/* Ticket Body */}
              <div className="p-6">
                <div className="flex flex-col lg:flex-row gap-8">
                  {/* Route Timeline */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-bold text-gray-400 uppercase tracking-wider">Origin</span>
                      <span className="text-sm font-bold text-gray-400 uppercase tracking-wider text-right">Destination</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-2xl font-bold text-gray-900">{booking.bus?.route?.origin}</span>
                      <div className="flex-1 mx-6 flex items-center">
                        <div className="h-[2px] w-full bg-gray-200 relative">
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-indigo-600 border-2 border-white shadow-sm"></div>
                          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-indigo-600 border-2 border-white shadow-sm"></div>
                          <div className="absolute left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-gray-50 px-2 text-xs font-medium text-gray-400">
                            To
                          </div>
                        </div>
                      </div>
                      <span className="text-2xl font-bold text-gray-900 text-right">{booking.bus?.route?.destination}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-6">
                      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <p className="text-xs text-gray-400 font-bold uppercase mb-1">Departure</p>
                        <p className="font-semibold text-gray-900 flex items-center gap-2">
                          <CalendarDays className="h-4 w-4 text-indigo-500" />
                          {formatJourneyDateTime(booking.journeyDate, booking.bus)}
                        </p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <p className="text-xs text-gray-400 font-bold uppercase mb-1">Seats</p>
                        <p className="font-semibold text-gray-900 flex items-center gap-2">
                          <div className="w-4 h-4 bg-indigo-100 rounded flex items-center justify-center">
                            <div className="w-2 h-2 bg-indigo-500 rounded-sm"></div>
                          </div>
                          {booking.seats?.join(', ')}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Ticket Details & Actions */}
                  <div className="lg:w-72 lg:border-l lg:border-gray-100 lg:pl-8 flex flex-col justify-between">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-500">Total Fare</span>
                        <span className="text-xl font-bold text-indigo-600">BDT {booking.totalFare}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-500">Payment</span>
                        <span className={`text-sm font-bold px-2 py-0.5 rounded ${booking.payment?.status === 'paid' ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'
                          }`}>
                          {booking.payment?.status?.toUpperCase() || 'PENDING'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-500">Shuttle</span>
                        <span className={`text-sm font-bold ${booking.shuttleService?.requested ? 'text-green-600' : 'text-gray-400'}`}>
                          {booking.shuttleService?.requested ? 'Booked' : 'Not Booked'}
                        </span>
                      </div>
                    </div>

                    <div className="mt-8 flex flex-col gap-3">
                      <button
                        onClick={() => navigate(`/booking-details/${booking._id}`)}
                        className="w-full py-2.5 rounded-xl border border-gray-200 text-gray-700 font-bold text-sm hover:bg-gray-50 transition-colors"
                      >
                        View E-Ticket
                      </button>

                      {!booking.shuttleService?.requested && booking.status === 'confirmed' && !hasBusDeparted(booking.journeyDate, booking.bus) ? (
                        <button
                          onClick={() => navigate(`/shuttle-booking?bookingId=${booking._id}`, { state: { booking } })}
                          className="w-full py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
                        >
                          Book Shuttle
                        </button>
                      ) : hasBusDeparted(booking.journeyDate, booking.bus) ? (
                        <div className="text-center">
                          <span className="text-xs text-amber-600 font-medium bg-amber-50 px-3 py-1 rounded-full">Trip Completed / Departed</span>
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderShuttles = () => {
    if (shuttles.length === 0) {
      return (
        <EmptyState
          title="No shuttle history"
          description="Request a shuttle to enjoy last-mile connectivity to and from the bus station."
        />
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Shuttle Requests</h2>
        </div>

        <div className="grid gap-4">
          {shuttles.map((shuttle) => (
            <div key={shuttle._id} className="relative bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition-all">
              {/* Reference Badge */}
              <div className="absolute top-0 right-0 p-4">
                <span className="text-[10px] font-bold text-gray-400 bg-gray-50 px-2 py-1 rounded border border-gray-100">
                  #{shuttle.shuttleReference}
                </span>
              </div>

              <div className="flex flex-col md:flex-row gap-6">
                {/* Vehicle Info (Left) */}
                <div className="w-full md:w-48 flex-shrink-0 flex flex-col items-center justify-center bg-blue-50/50 rounded-xl p-4 border border-blue-100/50">
                  <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-blue-600 shadow-sm mb-3">
                    <Car className="h-7 w-7" />
                  </div>
                  <p className="font-bold text-gray-900">{shuttle.vehicleType}</p>
                  <p className="text-xs text-gray-500 font-medium">BDT {shuttle.fare?.total}</p>
                  <div className="mt-3">
                    <StatusBadge status={shuttle.status} />
                  </div>
                </div>

                {/* Trip Details (Right) */}
                <div className="flex-1 space-y-4">
                  {/* Driver Info */}
                  {shuttle.driver && (
                    <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                        <UserRound className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900">{shuttle.driver?.user?.name || shuttle.driver?.name}</p>
                        <p className="text-xs text-gray-500">{shuttle.driver.vehicleModel}</p>
                      </div>
                      <div className="ml-auto">
                        {shuttle.status === 'completed' && (
                          <button
                            onClick={async () => {
                              try {
                                const checkResponse = await checkCanReview(shuttle._id);
                                if (checkResponse.canReview) {
                                  setSelectedShuttleForRating(shuttle);
                                  setRatingModalOpen(true);
                                }
                              } catch (err) {
                                setSelectedShuttleForRating(shuttle);
                                setRatingModalOpen(true);
                              }
                            }}
                            className="text-xs font-bold text-indigo-600 hover:bg-indigo-50 px-3 py-1.5 rounded-full transition-colors border border-indigo-100"
                          >
                            Rate Driver
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Locations */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-400 font-bold uppercase mb-1">Pickup</p>
                      <p className="text-sm font-semibold text-gray-900">{shuttle.pickup?.address}</p>
                      <p className="text-xs text-blue-500 mt-1 font-medium">{formatDateTime(shuttle.scheduledTime)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 font-bold uppercase mb-1">Drop-off</p>
                      <p className="text-sm font-semibold text-gray-900">{shuttle.dropoff?.address}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Footer for Active Rides */}
              {ACTIVE_RIDE_STATUSES.includes(shuttle.status) && (
                <div className="mt-4 pt-4 border-t border-gray-100 flex gap-3">
                  <button
                    onClick={() => { setActiveNav('live'); setActiveShuttle(shuttle); }}
                    className="flex-1 py-2 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-700 transition"
                  >
                    Track Live
                  </button>
                  <button
                    onClick={() => { setActiveNav('chat'); setActiveShuttle(shuttle); }}
                    className="flex-1 py-2 rounded-xl border border-gray-200 text-gray-700 text-sm font-bold hover:bg-gray-50 transition"
                  >
                    Message Driver
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderLiveTrack = () => {
    if (!activeShuttle) {
      return (
        <EmptyState
          title="No active shuttle to track"
          description="Once a driver accepts your request, live tracking will appear here."
        />
      );
    }

    return (
      <div className="space-y-6">
        <div className="grid gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
              <div className="p-4 bg-white border-b border-gray-50 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-50 rounded-xl text-green-600">
                    <Navigation className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Live Journey</h3>
                    <p className="text-xs text-slate-500">Updates every few seconds</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                  <span className="text-xs font-bold text-red-500 uppercase tracking-widest">Live</span>
                </div>
              </div>

              {/* Map Container - Taller and better styled */}
              <div className="h-[500px] w-full relative bg-gray-100">
                <LiveTrackMap
                  pickup={activeShuttle.pickup}
                  dropoff={activeShuttle.dropoff}
                  driverLocation={driverLocation}
                />
                {/* Floating ETA Card */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-white/20 z-[1000] max-w-[200px]">
                  <p className="text-xs text-gray-500 font-bold uppercase mb-1">Estimated Arrival</p>
                  <p className="text-2xl font-bold text-gray-900">12 min</p>
                  <p className="text-xs text-gray-400 mt-1">~3.5 km away</p>
                </div>
              </div>

              <div className="p-6 bg-white border-t border-gray-50">
                <div className="flex flex-col sm:flex-row gap-8">
                  <div className="flex-1">
                    <div className="flex items-start gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-4 h-4 rounded-full bg-indigo-600 border-4 border-indigo-100"></div>
                        <div className="w-0.5 h-12 bg-gray-100"></div>
                        <div className="w-4 h-4 rounded-full bg-green-500 border-4 border-green-100"></div>
                      </div>
                      <div className="space-y-8 pt-0.5">
                        <div>
                          <p className="text-xs font-bold text-gray-400 uppercase mb-1">Pickup Information</p>
                          <p className="font-semibold text-gray-900">{activeShuttle.pickup?.address}</p>
                        </div>
                        <div>
                          <p className="text-xs font-bold text-gray-400 uppercase mb-1">Drop-Off Location</p>
                          <p className="font-semibold text-gray-900">{activeShuttle.dropoff?.address}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Driver Profile Card */}
            <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-br from-indigo-600 to-purple-600"></div>
              <div className="relative pt-12 text-center">
                <div className="w-24 h-24 mx-auto bg-white p-1 rounded-full shadow-lg mb-3">
                  <div className="w-full h-full rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                    {/* Placeholder for driver image or icon */}
                    <UserRound className="h-10 w-10 text-gray-400" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900">{activeShuttle.driver?.user?.name || 'Assigned Driver'}</h3>
                <div className="flex items-center justify-center gap-1 mt-1 mb-4">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  <span className="font-bold text-gray-700">4.9</span>
                  <span className="text-xs text-gray-400">(120+ Rides)</span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <p className="text-xs text-gray-400 font-bold uppercase">Phone</p>
                    <p className="font-semibold text-gray-900 text-sm mt-1">{activeShuttle.driver?.user?.phone || 'Hidden'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <p className="text-xs text-gray-400 font-bold uppercase">Model</p>
                    <p className="font-semibold text-gray-900 text-sm mt-1">{activeShuttle.driver?.vehicleModel || 'Sedan'}</p>
                  </div>
                  <div className="col-span-2 bg-gray-50 p-3 rounded-xl border border-gray-100">
                    <p className="text-xs text-gray-400 font-bold uppercase">License Plate</p>
                    <p className="font-mono font-bold text-gray-900 mt-1 uppercase text-lg tracking-wider">
                      {activeShuttle.driver?.vehiclePlateNumber || 'T-2910'}
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition shadow-lg shadow-indigo-200">
                    Call Driver
                  </button>
                  <button
                    onClick={() => setActiveNav('chat')}
                    className="flex-1 py-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold text-sm hover:bg-gray-50 transition"
                  >
                    Message
                  </button>
                </div>
              </div>
            </div>
            {renderNotifications()}
          </div>
        </div>
      </div>
    );
  };

  const renderChat = () => (
    <div className="grid gap-6 lg:grid-cols-4 h-[calc(100vh-140px)]">
      {/* Sidebar List */}
      <div className="bg-white rounded-3xl border border-gray-100 flex flex-col h-full overflow-hidden">
        <div className="p-5 border-b border-gray-50">
          <h3 className="font-bold text-gray-900 text-lg">Messages</h3>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
          {activeShuttle ? (
            <button
              onClick={() => setActiveShuttle(activeShuttle)}
              className="w-full text-left p-3 rounded-2xl bg-indigo-50 border border-indigo-100 relative group transition-all"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-gray-900 text-sm">Shuttle #{activeShuttle.shuttleReference}</span>
                <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              </div>
              <p className="text-xs text-gray-500 truncate font-medium">Click to view conversation</p>
            </button>
          ) : (
            <div className="text-center py-10 px-4">
              <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-300">
                <MessageCircle className="h-6 w-6" />
              </div>
              <p className="text-xs text-gray-400 font-medium leading-relaxed">Active shuttle conversations will appear here.</p>
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="lg:col-span-3 h-full">
        <div className="bg-white rounded-3xl border border-gray-100 h-full overflow-hidden flex flex-col shadow-sm">
          {renderChatPanel()}
        </div>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm">
        <div className="flex items-center gap-6 mb-8 border-b border-gray-100 pb-8">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold shadow-xl shadow-indigo-200">
            {userInitials}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{user?.name}</h2>
            <p className="text-gray-500">{user?.email}</p>
            <span className="inline-flex items-center px-3 py-1 rounded-full bg-green-50 text-green-700 text-xs font-bold mt-2 border border-green-100">
              Verified Account
            </span>
          </div>
        </div>

        <form className="grid gap-6 md:grid-cols-2" onSubmit={handleProfileSubmit}>
          <div className="md:col-span-2">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Personal Information</h3>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Full Name</label>
            <input
              value={profileForm.name}
              onChange={(e) => setProfileForm((prev) => ({ ...prev, name: e.target.value }))}
              className="w-full h-12 rounded-xl border border-gray-200 px-4 text-sm font-medium focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
              placeholder="Enter your full name"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Student ID</label>
            <input
              value={profileForm.studentId}
              onChange={(e) => setProfileForm((prev) => ({ ...prev, studentId: e.target.value }))}
              className="w-full h-12 rounded-xl border border-gray-200 px-4 text-sm font-medium focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
              placeholder="e.g. 21101134"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Phone Number</label>
            <input
              value={profileForm.phone}
              onChange={(e) => setProfileForm((prev) => ({ ...prev, phone: e.target.value }))}
              className="w-full h-12 rounded-xl border border-gray-200 px-4 text-sm font-medium focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
              placeholder="e.g. 01700000000"
            />
          </div>

          <div className="md:col-span-2 pt-4">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Preferences</h3>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Default Pickup Location</label>
            <textarea
              value={profileForm.preferredPickup}
              onChange={(e) => setProfileForm((prev) => ({ ...prev, preferredPickup: e.target.value }))}
              rows={3}
              className="w-full rounded-xl border border-gray-200 p-4 text-sm font-medium focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all resize-none"
              placeholder="Enter common pickup addresses to speed up booking..."
            />
          </div>

          <div className="md:col-span-2 flex justify-end pt-4">
            <button
              type="submit"
              disabled={profileSaving}
              className="h-12 px-8 rounded-xl bg-gray-900 text-white font-bold hover:bg-indigo-600 transition-all shadow-lg hover:shadow-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {profileSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Saving Changes...
                </>
              ) : (
                'Save Profile'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const renderContent = () => {
    if (loading) return renderLoadingState();
    switch (activeNav) {
      case 'dashboard':
        return renderDashboard();
      case 'bookings':
        return renderBookings();
      case 'shuttles':
        return renderShuttles();
      case 'live':
        return renderLiveTrack();
      case 'chat':
        return renderChat();
      case 'profile':
        return renderProfile();
      default:
        return renderDashboard();
    }
  };

  const userInitials = useMemo(() => {
    if (!user?.name) return 'U';
    return user.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }, [user?.name]);

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-900 selection:bg-indigo-500/30">
      <div className="lg:flex">
        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Sidebar Navigation */}
        <aside className={`fixed top-0 bottom-0 left-0 z-50 w-80 bg-slate-900 border-r border-white/5 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:block ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          {/* Subtle Gradient Background Overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/20 via-slate-900/50 to-slate-950 pointer-events-none" />

          <div className="relative h-full flex flex-col overflow-y-auto custom-scrollbar">
            {/* User Profile Section */}
            <div className="px-6 pt-10 pb-8">
              <div className="flex flex-col items-center text-center mb-8">
                <div className="relative group cursor-pointer">
                  <div className="bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 p-0.5 rounded-[2rem] shadow-2xl shadow-indigo-500/20 transition-all duration-300 group-hover:shadow-indigo-500/40 group-hover:scale-105">
                    <div className="bg-slate-900 h-20 w-20 rounded-[1.9rem] flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-50" />
                      <span className="text-2xl font-bold text-white relative z-10">{userInitials}</span>
                    </div>
                  </div>
                  <div className="absolute -bottom-1 -right-1">
                    {isConnected ? (
                      <div className="w-5 h-5 bg-emerald-500 rounded-full border-4 border-slate-900 flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                      </div>
                    ) : (
                      <div className="w-5 h-5 bg-slate-500 rounded-full border-4 border-slate-900" />
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="text-lg font-bold text-white tracking-tight">{user?.name || 'Guest User'}</h3>
                  <p className="text-sm font-medium text-slate-400 mt-0.5">{user?.email}</p>
                </div>
              </div>

              {/* Quick Stats Cards */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/5 hover:bg-white/10 transition-colors group">
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 group-hover:text-indigo-300 transition-colors">Total Trips</p>
                  <p className="text-xl font-bold text-white">{bookingStats.total}</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/5 hover:bg-white/10 transition-colors group">
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 group-hover:text-indigo-300 transition-colors">Upcoming</p>
                  <p className="text-xl font-bold text-indigo-400">{bookingStats.upcoming}</p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex-1 px-4 pb-6">
              <p className="px-4 text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Main Menu</p>
              <nav className="space-y-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeNav === item.id;
                  return (
                    <button
                      key={item.id}
                      disabled={item.disabled}
                      onClick={() => {
                        setActiveNav(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`group relative flex w-full items-center gap-3.5 rounded-2xl px-4 py-3.5 text-left text-sm font-semibold transition-all duration-300 ease-out border ${isActive
                          ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 border-indigo-500/50 text-white shadow-lg shadow-indigo-900/20'
                          : 'bg-transparent border-transparent text-slate-400 hover:bg-white/5 hover:text-white'
                        } ${item.disabled ? 'cursor-not-allowed opacity-40 grayscale' : ''}`}
                    >
                      <Icon className={`h-5 w-5 flex-shrink-0 transition-all duration-300 ${isActive ? 'scale-110 text-white' : 'text-slate-500 group-hover:text-white group-hover:scale-110'
                        }`} />
                      <span className="flex-1 tracking-wide">{item.label}</span>
                      {isActive && (
                        <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)] animate-pulse" />
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Footer Actions */}
            <div className="px-6 pb-8 pt-4">
              <div className="pt-6 border-t border-white/5">
                <button
                  onClick={handleLogout}
                  className="flex w-full items-center justify-between rounded-2xl px-4 py-3.5 text-sm font-semibold text-rose-400 bg-rose-500/5 border border-rose-500/10 hover:bg-rose-500/10 hover:border-rose-500/20 hover:text-rose-300 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <LogOut className="h-5 w-5 transition-transform group-hover:-translate-x-1" />
                    <span>Sign Out</span>
                  </div>
                  <span className="text-[10px] font-bold bg-rose-500/10 px-2 py-0.5 rounded text-rose-400/70 group-hover:text-rose-400 transition-colors">v1.0</span>
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 bg-slate-50 min-h-screen w-full">
          {/* Header */}
          <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/60">
            <div className="flex items-center justify-between px-4 sm:px-6 py-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsMobileMenuOpen(true)}
                  className="p-2 -ml-2 rounded-xl text-slate-600 hover:bg-slate-100 lg:hidden focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <Menu className="h-6 w-6" />
                </button>
                <div>
                  <h1 className="text-xl font-bold text-slate-900 leading-tight">Dashboard</h1>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200">
                  <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                  <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                    {isConnected ? 'System Online' : 'Offline'}
                  </span>
                </div>
              </div>
            </div>
          </header>

          <div className="p-4 sm:p-6 lg:p-8 max-w-[1600px] mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Rating Modal */}
      <RatingModal
        isOpen={ratingModalOpen}
        onClose={() => {
          setRatingModalOpen(false);
          setSelectedShuttleForRating(null);
        }}
        shuttle={selectedShuttleForRating}
        onSubmit={async (ratingData) => {
          try {
            setSubmittingRating(true);
            await createReview({
              shuttleId: ratingData.shuttleId,
              rating: ratingData.rating,
              comment: ratingData.comment,
            });
            toast.success('Thank you for your rating!');
            setRatingModalOpen(false);
            setSelectedShuttleForRating(null);
            // Refresh shuttles to update UI
            await loadInitialData();
          } catch (error) {
            const message = error.response?.data?.message || 'Failed to submit rating. Please try again.';
            toast.error(message);
            throw error;
          } finally {
            setSubmittingRating(false);
          }
        }}
      />
    </div>
  );
};

export default UserDashboard;

