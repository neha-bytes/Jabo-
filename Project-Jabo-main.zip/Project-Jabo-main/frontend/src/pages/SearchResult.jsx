import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { searchBuses, getAllBuses } from '../services/busService';
import { Calendar, MapPin, ArrowRight, Clock, Wind, Users, Bus, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const SearchResult = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchParams, setSearchParams] = useState({ origin: '', destination: '', date: '' });
  const toastShownRef = useRef(false);

  const [filters, setFilters] = useState({
    busType: [],
    departureTime: { start: '00:00', end: '23:59' },
  });

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const origin = params.get('origin') || '';
    const destination = params.get('destination') || '';
    const date = params.get('date') || '';

    setSearchParams({ origin, destination, date });

    const fetchBuses = async () => {
      try {
        setLoading(true);
        setError(null);

        // If search params exist, search buses; otherwise load all buses
        if (origin && destination && date) {
          const response = await searchBuses({ origin, destination, date });
          if (response.success) {
            setBuses(response.data);
          } else {
            setError('No buses found for this route.');
            setBuses([]);
          }
        } else {
          // Load all buses by default
          const response = await getAllBuses();
          if (response.success) {
            setBuses(response.data);
          } else {
            setError('Failed to load buses.');
            setBuses([]);
          }
        }
      } catch (err) {
        setError('Failed to fetch bus data. Please try again later.');
        setBuses([]);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBuses();
  }, [location.search]);

  // Show toast once if user is not logged in
  useEffect(() => {
    if (!user && !toastShownRef.current) {
      toast.error('Please login to book tickets', { id: 'login-required' });
      toastShownRef.current = true;
    }
  }, [user]);

  const filteredBuses = useMemo(() => {
    return buses.filter(bus => {
      // Bus Type Filter
      if (filters.busType.length > 0 && !filters.busType.includes(bus.busType)) {
        return false;
      }
      // Departure Time Filter
      const departureTime = bus.schedule.departureTime;
      if (departureTime < filters.departureTime.start || departureTime > filters.departureTime.end) {
        return false;
      }
      return true;
    });
  }, [buses, filters]);

  const handleNewSearch = (e) => {
    e.preventDefault();
    const queryParams = new URLSearchParams(searchParams).toString();
    navigate(`/search?${queryParams}`);
  };

  const BusCard = ({ bus }) => (
    <div className="group bg-white rounded-3xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-blue-100 relative overflow-hidden">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Left Info */}
        <div className="flex-1 space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{bus.busName}</h3>
              <p className="text-sm text-gray-500 font-medium mt-1">{bus.operatorName} • Coach #{bus.coachNumber}</p>
            </div>
            <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider ${bus.busType === 'AC' ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-600'
              }`}>
              {bus.busType}
            </span>
          </div>

          <div className="flex items-center gap-6 py-4 border-y border-dashed border-gray-100">
            <div className="text-center min-w-[80px]">
              <p className="text-2xl font-bold text-gray-900">{bus.schedule.departureTime}</p>
              <div className="flex items-center justify-center gap-1 mt-1 text-gray-500 text-sm font-medium">
                <MapPin className="h-3 w-3" />
                {bus.route.origin}
              </div>
            </div>

            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex items-center gap-2">
                <div className="h-[2px] w-full bg-gray-100 group-hover:bg-blue-100 transition-colors"></div>
                <Bus className="h-5 w-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                <div className="h-[2px] w-full bg-gray-100 group-hover:bg-blue-100 transition-colors"></div>
              </div>
              <p className="text-xs text-gray-400 font-medium">Duration: Approx. 6h</p>
            </div>

            <div className="text-center min-w-[80px]">
              <p className="text-2xl font-bold text-gray-900">{bus.schedule.arrivalTime}</p>
              <div className="flex items-center justify-center gap-1 mt-1 text-gray-500 text-sm font-medium">
                <MapPin className="h-3 w-3" />
                {bus.route.destination}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 bg-gray-50 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-600">
              <Users className="h-3.5 w-3.5 text-blue-500" />
              <span>
                {bus.availableSeatsForDate !== undefined
                  ? `${bus.availableSeatsForDate} seats left`
                  : `${bus.seats.availableSeats} seats left`}
              </span>
            </div>
            <div className="flex items-center gap-1.5 bg-gray-50 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-600">
              <Wind className="h-3.5 w-3.5 text-blue-500" />
              <span>{bus.seats.seatLayout || '2x2'} Layout</span>
            </div>
            {bus.amenities?.slice(0, 2).map((amenity) => (
              <span key={amenity} className="px-3 py-1.5 bg-gray-50 rounded-lg text-xs font-medium text-gray-600">
                {amenity}
              </span>
            ))}
            {bus.amenities?.length > 2 && (
              <span className="px-3 py-1.5 bg-gray-50 rounded-lg text-xs font-medium text-gray-500">
                +{bus.amenities.length - 2} more
              </span>
            )}
          </div>
        </div>

        {/* Right Action */}
        <div className="md:w-48 flex flex-col justify-between border-l border-gray-100 pl-6 gap-4">
          <div className="text-right">
            <p className="text-xs text-gray-500 font-medium uppercase mb-1">Starting from</p>
            <p className="text-3xl font-bold text-gray-900">
              <span className="text-lg text-gray-500 font-normal mr-1">{bus.fare.currency}</span>
              {bus.fare.baseFare}
            </p>
          </div>

          <button
            onClick={() => {
              navigate(`/booking?busId=${bus._id}&date=${searchParams.date}`);
            }}
            className="w-full mt-auto bg-gray-900 text-white font-bold py-3.5 px-4 rounded-xl hover:bg-blue-600 transition-all duration-300 shadow-lg shadow-gray-200 hover:shadow-blue-200 flex items-center justify-center gap-2 group-hover:scale-[1.02]"
          >
            <span>Book Seats</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Search Header */}
      <div className="bg-white shadow-sm sticky top-0 z-30 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <form onSubmit={handleNewSearch} className="flex flex-col md:flex-row gap-3 items-center">
            <div className="flex-1 w-full bg-gray-50 p-1.5 rounded-xl border border-gray-200 flex items-center gap-2 focus-within:ring-2 focus-within:ring-blue-100 focus-within:border-blue-300 transition-all">
              <div className="p-2 bg-white rounded-lg shadow-sm">
                <MapPin className="h-4 w-4 text-blue-500" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">From</p>
                <input
                  type="text"
                  value={searchParams.origin}
                  onChange={(e) => setSearchParams({ ...searchParams, origin: e.target.value })}
                  className="w-full bg-transparent text-sm font-semibold text-gray-900 placeholder-gray-400 focus:outline-none"
                  placeholder="Origin"
                />
              </div>
            </div>

            <div className="hidden md:block text-gray-300">
              <ArrowRight className="h-5 w-5" />
            </div>

            <div className="flex-1 w-full bg-gray-50 p-1.5 rounded-xl border border-gray-200 flex items-center gap-2 focus-within:ring-2 focus-within:ring-blue-100 focus-within:border-blue-300 transition-all">
              <div className="p-2 bg-white rounded-lg shadow-sm">
                <MapPin className="h-4 w-4 text-purple-500" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">To</p>
                <input
                  type="text"
                  value={searchParams.destination}
                  onChange={(e) => setSearchParams({ ...searchParams, destination: e.target.value })}
                  className="w-full bg-transparent text-sm font-semibold text-gray-900 placeholder-gray-400 focus:outline-none"
                  placeholder="Destination"
                />
              </div>
            </div>

            <div className="flex-1 w-full bg-gray-50 p-1.5 rounded-xl border border-gray-200 flex items-center gap-2 focus-within:ring-2 focus-within:ring-blue-100 focus-within:border-blue-300 transition-all">
              <div className="p-2 bg-white rounded-lg shadow-sm">
                <Calendar className="h-4 w-4 text-green-500" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Journey Date</p>
                <input
                  type="date"
                  value={searchParams.date}
                  onChange={(e) => setSearchParams({ ...searchParams, date: e.target.value })}
                  className="w-full bg-transparent text-sm font-semibold text-gray-900 placeholder-gray-400 focus:outline-none"
                />
              </div>
            </div>

            <button type="submit" className="w-full md:w-auto bg-blue-600 text-white font-bold p-4 rounded-xl hover:bg-blue-700 transition-colors shadow-lg hover:shadow-blue-200">
              <ArrowRight className="h-5 w-5" />
            </button>
          </form>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Column */}
          <aside className="lg:col-span-1">
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 sticky top-28">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-gray-900">Filters</h3>
                <button
                  onClick={() => setFilters({ busType: [], departureTime: { start: '00:00', end: '23:59' } })}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-700"
                >
                  Reset All
                </button>
              </div>

              {/* Bus Type Filter */}
              <div className="mb-8">
                <h4 className="text-sm font-bold text-gray-900 mb-4 uppercase tracking-wide">Bus Class</h4>
                <div className="space-y-3">
                  {['AC', 'Non-AC', 'Sleeper'].map(type => (
                    <label key={type} className="flex items-center gap-3 cursor-pointer group">
                      <div className="relative flex items-center">
                        <input
                          type="checkbox"
                          value={type}
                          checked={filters.busType.includes(type)}
                          onChange={(e) => {
                            const { value, checked } = e.target;
                            setFilters(prev => ({
                              ...prev,
                              busType: checked
                                ? [...prev.busType, value]
                                : prev.busType.filter(t => t !== value)
                            }));
                          }}
                          className="peer h-5 w-5 rounded-md border-2 border-gray-200 text-blue-600 focus:ring-blue-500 transition-all checked:border-blue-600"
                        />
                      </div>
                      <span className="text-sm font-medium text-gray-600 group-hover:text-gray-900 transition-colors">{type}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Departure Time Filter */}
              <div>
                <h4 className="text-sm font-bold text-gray-900 mb-4 uppercase tracking-wide">Departure Time</h4>
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                  <div className="flex items-center justify-between text-xs font-bold text-gray-500 mb-2">
                    <span>From {filters.departureTime.start}</span>
                    <span>23:59</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="23"
                    defaultValue="0"
                    onChange={(e) => {
                      const startHour = parseInt(e.target.value);
                      setFilters(prev => ({
                        ...prev,
                        departureTime: { ...prev.departureTime, start: `${startHour.toString().padStart(2, '0')}:00` }
                      }));
                    }}
                    className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600 hover:accent-blue-700"
                  />
                </div>
              </div>
            </div>
          </aside>

          {/* Results Column */}
          <div className="lg:col-span-3">
            {loading && (
              <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-gray-100">
                <Loader2 className="h-10 w-10 text-blue-600 animate-spin mb-4" />
                <p className="text-gray-900 font-bold text-lg">Finding the best trips...</p>
                <p className="text-gray-500 text-sm">Searching for available buses</p>
              </div>
            )}

            {error && !loading && (
              <div className="bg-red-50 border border-red-100 rounded-3xl p-8 text-center">
                <p className="text-red-600 font-bold mb-1">Oops! Something went wrong</p>
                <p className="text-red-500 text-sm">{error}</p>
              </div>
            )}

            {!loading && !error && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900">
                    {searchParams.origin && searchParams.destination
                      ? `${filteredBuses.length} Buses Found`
                      : `All Available Buses (${filteredBuses.length})`}
                  </h2>
                  <div className="text-sm text-gray-500 font-medium">
                    Sorted by <span className="text-blue-600 font-bold cursor-pointer">Best Match</span>
                  </div>
                </div>

                {filteredBuses.length === 0 ? (
                  <div className="bg-white border border-gray-100 rounded-3xl p-12 text-center shadow-sm">
                    <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Bus className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">No buses found</h3>
                    <p className="text-gray-500">Try adjusting your filters or changing the journey date.</p>
                    <button onClick={() => setFilters({ busType: [], departureTime: { start: '00:00', end: '23:59' } })} className="mt-6 text-blue-600 font-bold hover:underline">
                      Clear all filters
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredBuses.map(bus => (
                      <BusCard key={bus._id} bus={bus} />
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default SearchResult;
