import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { MapPin, Navigation, Clock, Car, CheckCircle2, Maximize2, Minimize2, Calendar, AlertCircle, Bike, Bus, Phone, Mail, User, ArrowRight, ShieldCheck } from 'lucide-react';
import ShuttleMap from '../components/Shuttle/ShuttleMap';
import { getPublicBooking } from '../services/bookingService';
import { createShuttleRequest } from '../services/shuttleService';
import { useAuth } from '../context/AuthContext';
import LoginModal from '../components/LoginModal';

const defaultCoords = [90.4125, 23.8103];

const vehicleOptions = [
  { label: 'Car', value: 'Car', capacity: 'Up to 3 people' },
  { label: 'Microbus', value: 'Microbus', capacity: 'Up to 7 people' },
  { label: 'Bike', value: 'Bike', capacity: 'Single rider' },
];

//============================================
// FIXED HELPER FUNCTIONS
//============================================

/**
 * Convert a Date object to datetime-local input format (YYYY-MM-DDTHH:mm)
 * This preserves the LOCAL time components without timezone conversion
 */
const formatDateTimeLocal = (date) => {
  if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
    return '';
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');

  return `${year}-${month}-${day}T${hours}:${minutes}`;
};

/**
 * Convert datetime-local string to UTC ISO string
 * Treats the input as local time and converts to UTC
 */
/**
 * Convert datetime-local string to UTC ISO string
 * Treats the input as Bangladesh local time (UTC+6) and converts to UTC
 */
const datetimeLocalToUTC = (datetimeLocalStr) => {
  if (!datetimeLocalStr) return null;

  const [datePart, timePart] = datetimeLocalStr.split('T');
  if (!datePart || !timePart) return null;

  const [year, month, day] = datePart.split('-').map(Number);
  const [hour, minute] = timePart.split(':').map(Number);

  // Create UTC date by treating the input as Bangladesh time (UTC+6)
  // So 15:05 Bangladesh = 09:05 UTC (subtract 6 hours)
  const utcDate = new Date(Date.UTC(
    year,
    month - 1,
    day,
    hour - 6,  // Subtract 6 hours to convert Bangladesh to UTC
    minute,
    0,
    0
  ));

  return utcDate.toISOString();
};
/**
 * Convert datetime-local string to Date object (interprets as local time)
 */

const datetimeLocalToDate = (datetimeLocalStr) => {
  if (!datetimeLocalStr) return null;

  const [datePart, timePart] = datetimeLocalStr.split('T');
  const [year, month, day] = datePart.split('-').map(Number);
  const [hour, minute] = (timePart || '00:00').split(':').map(Number);

  return new Date(year, month - 1, day, hour, minute, 0, 0);
};

// Helper function to parse 12-hour time format (e.g., "06:00 AM", "10:00 PM")
const parseTime12Hour = (timeStr) => {
  if (!timeStr) return null;

  const trimmed = timeStr.trim().toUpperCase();
  const match = trimmed.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/);

  if (!match) {
    const parts = trimmed.split(':');
    if (parts.length >= 2) {
      const hours = parseInt(parts[0], 10);
      const minutes = parseInt(parts[1], 10);
      if (!isNaN(hours) && !isNaN(minutes)) {
        return { hours, minutes };
      }
    }
    return null;
  }

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3];

  if (isNaN(hours) || isNaN(minutes)) return null;

  if (period === 'PM' && hours !== 12) {
    hours += 12;
  } else if (period === 'AM' && hours === 12) {
    hours = 0;
  }

  return { hours, minutes };
};

//============================================
// SHUTTLEBOOKING COMPONENT
//============================================

const ShuttleBooking = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const searchParams = new URLSearchParams(location.search);
  const bookingIdParam = searchParams.get('bookingId');

  const [showLoginModal, setShowLoginModal] = useState(false);

  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(!!bookingIdParam);
  const [error, setError] = useState(null);
  const [vehicleType, setVehicleType] = useState('Car');
  const [specialRequests, setSpecialRequests] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [selectingLocation, setSelectingLocation] = useState(null);
  const [isMapFullscreen, setIsMapFullscreen] = useState(false);

  const passengerCount = useMemo(() => {
    return booking?.seats?.length || 1;
  }, [booking]);

  const [pickup, setPickup] = useState({
    address: '',
    coordinates: defaultCoords,
  });

  const [dropoff, setDropoff] = useState({
    address: '',
    coordinates: defaultCoords,
  });

  const [scheduledTime, setScheduledTime] = useState('');

  // Debug effect to monitor booking structure
  useEffect(() => {
    if (booking) {
      console.log('🔍 ========== BOOKING STRUCTURE ==========');
      console.log('Booking ID:', booking._id);
      console.log('Journey Date:', booking.journeyDate);
      console.log('Has Bus?', !!booking.bus);
      console.log('Bus type:', typeof booking.bus);
      console.log('Bus Name:', booking.bus?.busName);
      console.log('Has Schedule?', !!booking.bus?.schedule);
      console.log('Departure Time:', booking.bus?.schedule?.departureTime);
      console.log('Full bus object:', booking.bus);
      console.log('🔍 =====================================');
    }
  }, [booking]);

  useEffect(() => {
    const fetchAndSetup = async () => {
      if (!bookingIdParam) {
        setError('No booking ID provided');
        setLoading(false);
        return;
      }

      try {
        console.log('📥 Fetching booking:', bookingIdParam);
        setLoading(true);

        const response = await getPublicBooking(bookingIdParam);
        console.log('📦 Booking response:', response);

        if (!response.success || !response.data) {
          throw new Error('Invalid booking response');
        }

        const bookingData = response.data;
        console.log('✅ Booking data received:', bookingData);
        setBooking(bookingData);

        // =============================================
        // Calculate scheduled time (45 min before bus departure)
        // =============================================
        console.log('⏰ Calculating scheduled time...');

        if (bookingData.journeyDate && bookingData.bus?.schedule?.departureTime) {
          const journeyDateUTC = new Date(bookingData.journeyDate);
          const departureTimeStr = bookingData.bus.schedule.departureTime;

          console.log('🚌 Journey date (UTC):', journeyDateUTC.toISOString());
          console.log('🚌 Departure time string:', departureTimeStr);

          const timeParts = parseTime12Hour(departureTimeStr);
          console.log('⏰ Parsed time:', timeParts);

          if (timeParts) {
            // Bangladesh timezone offset (UTC+6)
            const localOffset = 6 * 60 * 60 * 1000;

            // Shift journeyDate to local time to extract correct date
            const localDate = new Date(journeyDateUTC.getTime() + localOffset);

            // Create departure time using local date components
            const departureLocal = new Date(
              localDate.getUTCFullYear(),
              localDate.getUTCMonth(),
              localDate.getUTCDate(),
              timeParts.hours,
              timeParts.minutes,
              0,
              0
            );

            // Convert back to UTC
            const departureUTC = new Date(departureLocal.getTime() - localOffset);

            console.log('📅 Departure (UTC):', departureUTC.toISOString());
            console.log('📅 Departure (Local Bangladesh):', departureUTC.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }));

            // Calculate pickup time (45 minutes before departure)
            const pickupUTC = new Date(departureUTC.getTime() - 45 * 60000);
            console.log('🚕 Pickup (UTC):', pickupUTC.toISOString());
            console.log('🚕 Pickup (Local Bangladesh):', pickupUTC.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }));

            // Convert pickup UTC to local for datetime-local input
            const pickupLocal = new Date(pickupUTC.getTime() + localOffset);
            const timeString = formatDateTimeLocal(pickupLocal);
            console.log('✅ Setting scheduledTime to:', timeString);
            setScheduledTime(timeString);
          } else {
            console.log('⚠️ Could not parse departure time, using 1 hour before journey date');
            const journeyDate = new Date(bookingData.journeyDate);
            const localOffset = 6 * 60 * 60 * 1000;
            const localDate = new Date(journeyDate.getTime() + localOffset);
            const fallback = new Date(localDate.getTime() - 60 * 60000);
            setScheduledTime(formatDateTimeLocal(fallback));
          }
        } else {
          console.log('⚠️ Missing journey date or departure time');
          const journeyDate = new Date(bookingData.journeyDate);
          const localOffset = 6 * 60 * 60 * 1000;
          const localDate = new Date(journeyDate.getTime() + localOffset);
          setScheduledTime(formatDateTimeLocal(localDate));
        }
      } catch (err) {
        console.error('❌ Error fetching booking:', err);
        setError('Unable to load booking details. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchAndSetup();
  }, [bookingIdParam]);

  // Monitor scheduledTime changes
  useEffect(() => {
    if (scheduledTime) {
      console.log('⏰ scheduledTime (local format):', scheduledTime);
      const asUTC = datetimeLocalToUTC(scheduledTime);
      console.log('⏰ scheduledTime (as UTC):', asUTC);
    }
  }, [scheduledTime]);

  const distance = useMemo(() => {
    if (!pickup.coordinates || !dropoff.coordinates) return 5;
    return calculateDistance(pickup.coordinates, dropoff.coordinates);
  }, [pickup.coordinates, dropoff.coordinates]);

  const fare = useMemo(() => calculateFare(vehicleType, distance), [vehicleType, distance]);

  const departureTime = useMemo(() => {
    if (!booking?.journeyDate || !booking?.bus?.schedule?.departureTime) return null;

    const journeyDate = new Date(booking.journeyDate);
    const timeParts = parseTime12Hour(booking.bus.schedule.departureTime);

    if (timeParts) {
      journeyDate.setHours(timeParts.hours, timeParts.minutes, 0, 0);
      return journeyDate;
    }

    return new Date(booking.journeyDate);
  }, [booking]);

  const recommendedPickupTime = useMemo(() => {
    if (!departureTime) return null;
    const minutesNeeded = fare.estimatedDuration || Math.max(distance * 3, 30);
    const leaveTime = new Date(departureTime.getTime() - minutesNeeded * 60000);
    return leaveTime;
  }, [departureTime, fare, distance]);

  const busDeparted = useMemo(() => {
    if (!departureTime) return false;
    return new Date() > departureTime;
  }, [departureTime]);

  // Time validation
  const timeValidation = useMemo(() => {
    if (!scheduledTime || !departureTime) {
      return { valid: true, message: null };
    }

    const pickupDate = datetimeLocalToDate(scheduledTime);
    if (!pickupDate) {
      return { valid: false, message: 'Invalid pickup time format' };
    }

    const now = new Date();

    // Check if pickup is in the past
    if (pickupDate <= now) {
      return {
        valid: false,
        type: 'error',
        message: 'Pickup time must be in the future'
      };
    }

    // Check if pickup is after bus departure
    if (pickupDate >= departureTime) {
      return {
        valid: false,
        type: 'error',
        message: `Pickup must be before bus departure (${departureTime.toLocaleString([], {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        })})`
      };
    }

    // Calculate time differences
    const minutesToDeparture = Math.floor((departureTime - pickupDate) / 60000);

    // Warning: Too close to departure (less than 30 minutes)
    if (minutesToDeparture < 30) {
      return {
        valid: true,
        type: 'warning',
        message: `Only ${minutesToDeparture} minutes before departure. Consider earlier pickup.`
      };
    }

    // Warning: Too far from departure (more than 2 hours)
    if (minutesToDeparture > 120) {
      return {
        valid: true,
        type: 'warning',
        message: `Pickup is ${Math.floor(minutesToDeparture / 60)}h ${minutesToDeparture % 60}m before departure.`
      };
    }

    // Success: Good timing
    return {
      valid: true,
      type: 'success',
      message: `Perfect timing! ${minutesToDeparture} minutes before departure.`
    };
  }, [scheduledTime, departureTime]);

  // Handle form submission
  const validateForm = () => {
    if (!pickup.address) {
      toast.error('Please select a pickup location');
      return false;
    }
    if (!dropoff.address) {
      toast.error('Please select a dropoff location');
      return false;
    }
    if (!scheduledTime) {
      toast.error('Please select a pickup time');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log('📤 ========== SUBMITTING SHUTTLE REQUEST ==========');
    console.log('📤 scheduledTime (local):', scheduledTime);

    if (!booking) {
      toast.error('Missing booking information.');
      return;
    }

    if (busDeparted) {
      toast.error('Cannot book shuttle - bus has already departed.');
      return;
    }

    if (!scheduledTime) {
      toast.error('Please select a pickup time');
      return;
    }

    // Block submission if validation fails
    if (!timeValidation.valid) {
      toast.error(timeValidation.message || 'Please fix the pickup time');
      return;
    }

    if (!validateForm()) return;

    if (!user) {
      setShowLoginModal(true);
      return;
    }

    // Convert local datetime string to UTC ISO string
    const scheduledTimeUTC = datetimeLocalToUTC(scheduledTime);
    console.log('📤 scheduledTime (UTC):', scheduledTimeUTC);

    if (!scheduledTimeUTC) {
      toast.error('Invalid pickup time selected');
      return;
    }

    const scheduledDate = new Date(scheduledTimeUTC);
    if (isNaN(scheduledDate.getTime())) {
      toast.error('Invalid pickup time format');
      return;
    }

    console.log('📤 Scheduled date object:', scheduledDate);
    console.log('📤 Scheduled ISO string:', scheduledDate.toISOString());

    try {
      setSubmitting(true);

      const payload = {
        bookingId: booking._id,
        vehicleType,
        pickup,
        dropoff,
        scheduledTime: scheduledDate.toISOString(), // Send UTC ISO string
        specialRequests,
      };

      console.log('📦 Final payload:', payload);

      const response = await createShuttleRequest(payload);
      console.log('✅ Response:', response);

      if (response && response.success) {
        const shuttleId = response.data?._id || response._id || response.data?.id;

        if (shuttleId) {
          toast.success('Shuttle requested successfully!');
          navigate(`/shuttle/status/${shuttleId}`, { replace: true });
        } else {
          toast.error('Shuttle created but ID not found. Redirecting to dashboard...');
          navigate('/dashboard', { replace: true });
        }
      } else {
        toast.error('Unexpected response. Please check your dashboard.');
        navigate('/dashboard', { replace: true });
      }
    } catch (err) {
      console.error('❌ Error creating shuttle request:', err);
      const message =
        err.response?.data?.message ||
        err.message ||
        'Failed to request shuttle. Please ensure you are logged in.';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto py-16 px-4 text-center text-gray-500">
        Loading booking details...
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto py-16 px-4 text-center">
        <p className="text-red-500 mb-4">{error}</p>
        <button
          onClick={() => navigate('/')}
          className="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold"
        >
          Back to Home
        </button>
      </div>
    );
  }


  return (
    <>
      <div className="bg-gray-50 min-h-screen py-8 md:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">

            {/* Header / Trip Info */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-green-50/50 rounded-full translate-x-1/3 -translate-y-1/3"></div>
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 bg-green-50 text-green-600 text-xs font-bold uppercase rounded-full tracking-wider">
                      Shuttle Request
                    </span>
                    <span className="text-gray-400 text-xs font-medium">•</span>
                    <span className="text-gray-500 text-xs font-medium">Synced with Bus Trip</span>
                  </div>
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">
                    {booking?.bus?.busName || 'Your Bus Trip'}
                  </h1>
                  <div className="flex items-center gap-2 text-gray-500 text-sm">
                    <span className="font-medium text-gray-700">{booking?.bus?.route?.origin}</span>
                    <ArrowRight className="h-4 w-4" />
                    <span className="font-medium text-gray-700">{booking?.bus?.route?.destination}</span>
                  </div>
                </div>

                {departureTime && (
                  <div className="text-right">
                    <p className="text-xs text-gray-500 font-medium uppercase mb-1">Bus Departure</p>
                    <p className="text-xl font-bold text-gray-900 flex items-center justify-end gap-2">
                      <Clock className="h-5 w-5 text-green-600" />
                      {new Date(departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-sm text-gray-500">
                      {new Date(departureTime).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
                    </p>
                    {busDeparted && (
                      <span className="mt-1 inline-block px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-md font-medium">
                        Bus has departed
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Map & Location Selection */}
            {!isMapFullscreen && (
              <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 space-y-4">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    Pickup & Drop-off
                  </h2>
                  <button
                    type="button"
                    className="text-sm font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 transition-colors"
                    onClick={() => setIsMapFullscreen(true)}
                  >
                    <Maximize2 className="h-4 w-4" />
                    Fullscreen Map
                  </button>
                </div>

                <div className="bg-gray-100 rounded-2xl overflow-hidden border border-gray-200 h-64 relative group">
                  <ShuttleMap
                    pickup={{ ...pickup, coordinates: pickup.coordinates || defaultCoords }}
                    dropoff={{ ...dropoff, coordinates: dropoff.coordinates || defaultCoords }}
                    onPickupChange={(coords) => setPickup((prev) => ({ ...prev, coordinates: coords }))}
                    onDropoffChange={(coords) => setDropoff((prev) => ({ ...prev, coordinates: coords }))}
                    selectingLocation={selectingLocation}
                    onAddressChange={(type, address) => {
                      if (type === 'pickup') setPickup((prev) => ({ ...prev, address }));
                      else if (type === 'dropoff') setDropoff((prev) => ({ ...prev, address }));
                    }}
                  />
                  {/* Map Controls Overlay */}
                  <div className="absolute top-4 right-4 flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectingLocation(selectingLocation === 'pickup' ? null : 'pickup')}
                      className={`p-2 rounded-xl shadow-lg transition-all ${selectingLocation === 'pickup' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                        }`}
                      title="Set Pickup Location"
                    >
                      <MapPin className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectingLocation(selectingLocation === 'dropoff' ? null : 'dropoff')}
                      className={`p-2 rounded-xl shadow-lg transition-all ${selectingLocation === 'dropoff' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                        }`}
                      title="Set Drop-off Location"
                    >
                      <Navigation className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-gray-700 ml-1">Pickup Address</label>
                    <div className="relative">
                      <MapPin className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all font-medium text-gray-700"
                        value={pickup.address}
                        onChange={(e) => setPickup((prev) => ({ ...prev, address: e.target.value }))}
                        placeholder="Enter pickup location"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-gray-700 ml-1">Drop-off Address</label>
                    <div className="relative">
                      <Navigation className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all font-medium text-gray-700"
                        value={dropoff.address}
                        onChange={(e) => setDropoff((prev) => ({ ...prev, address: e.target.value }))}
                        placeholder="Enter drop-off location"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">

              {/* Vehicle Selection */}
              <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Car className="h-5 w-5 text-blue-600" /> Select Vehicle
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {vehicleOptions.map((option) => {
                    const Icon = option.value === 'Bike' ? Bike : option.value === 'Microbus' ? Bus : Car;
                    return (
                      <label
                        key={option.value}
                        className={`relative p-4 rounded-2xl border-2 cursor-pointer transition-all duration-300 hover:shadow-md ${vehicleType === option.value
                          ? 'border-blue-600 bg-blue-50/50'
                          : 'border-gray-100 hover:border-blue-100 bg-white'
                          }`}
                      >
                        <input
                          type="radio"
                          name="vehicleType"
                          value={option.value}
                          checked={vehicleType === option.value}
                          onChange={(e) => setVehicleType(e.target.value)}
                          className="hidden"
                        />
                        <div className="flex flex-col items-center text-center gap-3">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${vehicleType === option.value ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'
                            }`}>
                            <Icon className="h-6 w-6" />
                          </div>
                          <div>
                            <p className="font-bold text-gray-900">{option.label}</p>
                            <p className="text-xs text-gray-500 mt-1">{option.capacity}</p>
                          </div>
                        </div>
                        {vehicleType === option.value && (
                          <div className="absolute top-3 right-3 text-blue-600">
                            <CheckCircle2 className="h-5 w-5 fill-blue-100" />
                          </div>
                        )}
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Schedule & Pax */}
              <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-600" /> Schedule
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-semibold text-gray-700 ml-1 mb-2 block">Pickup Time</label>
                    <input
                      type="datetime-local"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      min={formatDateTimeLocal(new Date())}
                      max={departureTime ? formatDateTimeLocal(new Date(departureTime.getTime() - 15 * 60000)) : undefined}
                      required
                      disabled={busDeparted}
                      className={`w-full px-4 py-3 rounded-xl border transition-all ${timeValidation.type === 'error'
                        ? 'border-red-300 focus:ring-red-200'
                        : timeValidation.type === 'warning'
                          ? 'border-yellow-300 focus:ring-yellow-200'
                          : 'border-gray-200 focus:ring-blue-200 focus:border-blue-500'
                        } focus:outline-none focus:ring-2`}
                    />
                    {/* Validation Messages - kept similar but styled */}
                    {departureTime && scheduledTime && !busDeparted && timeValidation.message && (
                      <div className={`mt-3 p-3 rounded-xl text-sm flex items-start gap-2 ${timeValidation.type === 'error' ? 'bg-red-50 text-red-700' :
                        timeValidation.type === 'warning' ? 'bg-yellow-50 text-yellow-700' :
                          'bg-green-50 text-green-700'
                        }`}>
                        <AlertCircle className="h-5 w-5 flex-shrink-0" />
                        <span>{timeValidation.message}</span>
                      </div>
                    )}
                    {busDeparted && (
                      <div className="mt-3 p-3 bg-red-50 text-red-700 rounded-xl text-sm flex items-center gap-2">
                        <AlertCircle className="h-5 w-5" />
                        Bus has departed. Shuttle unavailable.
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700 ml-1 mb-2 block">Passengers</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
                      <input
                        type="number"
                        value={passengerCount}
                        disabled
                        className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-500 font-medium"
                      />
                    </div>
                    <p className="text-xs text-gray-400 mt-2 ml-1">Auto-set based on your bus booking</p>
                  </div>
                </div>

                <div className="mt-6">
                  <label className="text-sm font-semibold text-gray-700 ml-1 mb-2 block">Notes to Driver (Optional)</label>
                  <textarea
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all"
                    rows="3"
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="E.g., I have 2 large luggage bags..."
                  />
                </div>
              </div>

              {/* Action Bar */}
              <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <p className="text-sm text-gray-500 font-medium">Estimated Fare</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-gray-900">BDT {fare.total}</span>
                    <span className="text-sm text-gray-400">({vehicleType})</span>
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={submitting || busDeparted || !timeValidation.valid}
                  className="w-full md:w-auto px-8 py-4 rounded-xl bg-gray-900 text-white font-bold hover:bg-blue-600 transition-all shadow-lg hover:shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-5 w-5" />
                      <span>Confirm Shuttle Request</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          <aside className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-green-600" /> Trip Summary
              </h3>

              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-2xl space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-blue-600">
                      <Navigation className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-semibold uppercase">Total Distance</p>
                      <p className="font-bold text-gray-900">{distance.toFixed(1)} km</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-blue-600">
                      <Clock className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-semibold uppercase">Est. Duration</p>
                      <p className="font-bold text-gray-900">{fare.estimatedDuration} mins</p>
                    </div>
                  </div>
                </div>

                {recommendedPickupTime && (
                  <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl">
                    <p className="text-xs text-blue-600 font-bold uppercase mb-1">Recommended Departure</p>
                    <p className="text-lg font-bold text-blue-900">
                      {recommendedPickupTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-blue-700 mt-1">
                      To reach bus stand 15 mins early
                    </p>
                  </div>
                )}

                {booking?.contactInfo && (
                  <div className="border-t border-gray-100 pt-4">
                    <p className="text-xs text-gray-400 font-bold uppercase mb-3">Passenger</p>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600">
                        <User className="h-4 w-4" />
                      </div>
                      <div className="text-sm overflow-hidden">
                        <p className="font-semibold text-gray-900 truncate">{booking.contactInfo.fullName}</p>
                        <p className="text-gray-500 truncate">{booking.contactInfo.phone}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* Fullscreen Map Modal */}
      {isMapFullscreen && (
        <div className="fixed inset-0 z-[9999] bg-white flex flex-col">
          <div className="bg-white shadow-sm px-6 py-4 flex items-center justify-between flex-shrink-0">
            <div>
              <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
                <MapPin className="h-5 w-5 text-blue-600" />
                Select Locations
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                {selectingLocation === 'pickup'
                  ? 'Click on the map to set your pickup location'
                  : selectingLocation === 'dropoff'
                    ? 'Click on the map to set your drop-off location'
                    : 'Select a location type below to place markers on the map'}
              </p>
            </div>
            <button
              onClick={() => setIsMapFullscreen(false)}
              className="px-4 py-2 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all flex items-center gap-2"
            >
              <Minimize2 className="h-4 w-4" />
              Minimize
            </button>
          </div>

          <div className="bg-gray-50 px-6 py-3 shadow-sm flex items-center gap-3 flex-shrink-0">
            <span className="text-sm text-gray-600 font-medium">Select:</span>
            <button
              type="button"
              className={`px-4 py-2 rounded-xl border transition-all ${selectingLocation === 'pickup'
                ? 'border-blue-600 bg-blue-600 text-white shadow-md'
                : 'border-gray-300 bg-white text-gray-700 hover:border-blue-400'
                }`}
              onClick={() =>
                setSelectingLocation(
                  selectingLocation === 'pickup' ? null : 'pickup'
                )
              }
            >
              📍 Pickup Location
            </button>
            <button
              type="button"
              className={`px-4 py-2 rounded-xl border transition-all ${selectingLocation === 'dropoff'
                ? 'border-blue-600 bg-blue-600 text-white shadow-md'
                : 'border-gray-300 bg-white text-gray-700 hover:border-blue-400'
                }`}
              onClick={() =>
                setSelectingLocation(
                  selectingLocation === 'dropoff' ? null : 'dropoff'
                )
              }
            >
              🎯 Drop-off Location
            </button>

            <div className="ml-auto flex items-center gap-4 text-sm">
              {pickup.address && (
                <div className="flex items-center gap-2 px-3 py-1 bg-green-50 border border-green-200 rounded-lg">
                  <span className="text-green-700 font-medium">Pickup:</span>
                  <span className="text-green-600 max-w-xs truncate">{pickup.address}</span>
                </div>
              )}
              {dropoff.address && (
                <div className="flex items-center gap-2 px-3 py-1 bg-purple-50 border border-purple-200 rounded-lg">
                  <span className="text-purple-700 font-medium">Drop-off:</span>
                  <span className="text-purple-600 max-w-xs truncate">{dropoff.address}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <div className="h-full w-full">
              <ShuttleMap
                pickup={{ ...pickup, coordinates: pickup.coordinates || defaultCoords }}
                dropoff={{ ...dropoff, coordinates: dropoff.coordinates || defaultCoords }}
                onPickupChange={(coords) =>
                  setPickup((prev) => ({ ...prev, coordinates: coords }))
                }
                onDropoffChange={(coords) =>
                  setDropoff((prev) => ({ ...prev, coordinates: coords }))
                }
                selectingLocation={selectingLocation}
                onAddressChange={(type, address) => {
                  if (type === 'pickup') {
                    setPickup((prev) => ({ ...prev, address }));
                  } else if (type === 'dropoff') {
                    setDropoff((prev) => ({ ...prev, address }));
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSuccess={() => {
          setShowLoginModal(false);
          // Auto-submit after login could be added here, but for safety lets just let them click again
          toast.success('Logged in! You can now request the shuttle.');
        }}
      />
    </>
  );
};

function calculateDistance(coords1 = [], coords2 = []) {
  if (coords1.length < 2 || coords2.length < 2) return 5;
  const [lon1, lat1] = coords1;
  const [lon2, lat2] = coords2;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
    Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.max(1, Math.round(R * c * 10) / 10);
}

function toRad(degrees) {
  return degrees * (Math.PI / 180);
}

function calculateFare(vehicleType, distance) {
  const rates = {
    Car: { base: 80, perKm: 25 },
    Bike: { base: 40, perKm: 15 },
    Microbus: { base: 120, perKm: 40 },
  };
  const rate = rates[vehicleType] || rates.Car;
  const baseFare = rate.base;
  const distanceFare = Math.round(distance * rate.perKm);
  return {
    baseFare,
    distanceFare,
    total: baseFare + distanceFare,
    estimatedDuration: Math.round(distance * 3),
  };
}

export default ShuttleBooking;
