import { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Car,
  Bus,
  Calendar,
  Star,
  MessageSquare,
  LogOut,
  Menu,
  X,
  CheckCircle,
  XCircle,
  Clock,
  ChevronDown,
  ChevronUp,
  MapPin,
  User,
  CreditCard,
  Edit,
  Trash2,
  Navigation,
  Wifi,
  Zap,
  Droplet,
  Coffee,
  Monitor,
  Wind,
  Lightbulb,
  Save,
  Plus,
  Minus,
  Search,
  Filter,
  MoreVertical,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  DollarSign
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { adminService } from "../services/adminService";
import { toast } from 'react-hot-toast';

// --- Helper Functions ---
const convertTo24Hour = (time12h) => {
  if (!time12h || !time12h.includes(':')) return '';
  if (!time12h.includes('AM') && !time12h.includes('PM')) return time12h;
  const [time, period] = time12h.trim().split(' ');
  let [hours, minutes] = time.split(':');
  hours = parseInt(hours);
  if (period === 'PM' && hours !== 12) hours += 12;
  else if (period === 'AM' && hours === 12) hours = 0;
  return `${hours.toString().padStart(2, '0')}:${minutes}`;
};

const convertTo12Hour = (time24h) => {
  if (!time24h) return '';
  const [hours, minutes] = time24h.split(':');
  const hour = parseInt(hours);
  const period = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  return `${displayHour.toString().padStart(2, '0')}:${minutes} ${period}`;
};

// --- Reusable Components ---

const StatusBadge = ({ status, type = 'default' }) => {
  const styles = {
    active: "bg-emerald-100 text-emerald-700 border-emerald-200",
    inactive: "bg-slate-100 text-slate-600 border-slate-200",
    pending: "bg-amber-100 text-amber-700 border-amber-200",
    confirmed: "bg-blue-100 text-blue-700 border-blue-200",
    cancelled: "bg-rose-100 text-rose-700 border-rose-200",
    completed: "bg-purple-100 text-purple-700 border-purple-200",
    maintenance: "bg-orange-100 text-orange-700 border-orange-200",
    verified: "bg-teal-100 text-teal-700 border-teal-200",
    unverified: "bg-gray-100 text-gray-600 border-gray-200",
  };

  const safeStatus = typeof status === 'string' ? status : String(status || '');
  let styleKey = safeStatus.toLowerCase() || 'inactive';

  if (type === 'verification') {
    styleKey = status ? 'verified' : 'unverified';
    status = status ? 'Verified' : 'Unverified';
  }

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${styles[styleKey] || styles.inactive} capitalize`}>
      {status}
    </span>
  );
};

// --- Bus Edit Modal ---
const BusEditModal = ({ bus, onClose, onSave }) => {
  const isEditMode = !!bus;
  const [formData, setFormData] = useState({
    busName: bus?.busName || '',
    operatorName: bus?.operatorName || '',
    coachNumber: bus?.coachNumber || '',
    busType: bus?.busType || 'AC',
    route: { origin: bus?.route?.origin || '', destination: bus?.route?.destination || '' },
    schedule: {
      departureTime: convertTo24Hour(bus?.schedule?.departureTime || ''),
      arrivalTime: convertTo24Hour(bus?.schedule?.arrivalTime || ''),
      daysOfOperation: bus?.schedule?.daysOfOperation || []
    },
    fare: { baseFare: bus?.fare?.baseFare || 0, currency: bus?.fare?.currency || 'BDT' },
    seats: { totalSeats: bus?.seats?.totalSeats || 40, seatLayout: bus?.seats?.seatLayout || '2x2' },
    amenities: bus?.amenities || [],
    status: bus?.status || 'Active',
    gpsEnabled: bus?.gpsEnabled || false,
    stoppages: (bus?.stoppages || []).map(stop => ({ ...stop, arrivalTime: convertTo24Hour(stop.arrivalTime || '') }))
  });
  const [newStoppage, setNewStoppage] = useState({ name: '', arrivalTime: '', fare: 0 });

  const busTypes = ['AC', 'Non-AC', 'Sleeper', 'Semi-Sleeper', 'Luxury'];
  const allAmenities = ['WiFi', 'Charging Port', 'Water', 'Snacks', 'TV', 'Blanket', 'Reading Light'];
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const dataToSave = {
        ...formData,
        schedule: {
          ...formData.schedule,
          departureTime: convertTo12Hour(formData.schedule.departureTime),
          arrivalTime: convertTo12Hour(formData.schedule.arrivalTime),
        },
        stoppages: formData.stoppages.map(stop => ({
          ...stop,
          arrivalTime: convertTo12Hour(stop.arrivalTime)
        }))
      };
      await onSave(dataToSave, bus?._id);
      onClose();
    } catch (error) {
      toast.error('Failed to save bus');
    }
  };

  const toggleDay = (day) => {
    setFormData(prev => ({
      ...prev,
      schedule: {
        ...prev.schedule,
        daysOfOperation: prev.schedule.daysOfOperation.includes(day)
          ? prev.schedule.daysOfOperation.filter(d => d !== day)
          : [...prev.schedule.daysOfOperation, day]
      }
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
        <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-white">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              {isEditMode ? <Edit size={20} /> : <Bus size={20} />}
            </div>
            {isEditMode ? 'Edit Bus Details' : 'Add New Bus'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8">
          <form id="busForm" onSubmit={handleSubmit} className="space-y-8">
            {/* Section: Basic Info */}
            <section className="space-y-4">
              <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-2">
                <Bus size={16} /> Basic Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Bus Name</label>
                  <input required type="text" value={formData.busName} onChange={e => setFormData({ ...formData, busName: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all" placeholder="e.g. Green Line Express" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Operator Name</label>
                  <input required type="text" value={formData.operatorName} onChange={e => setFormData({ ...formData, operatorName: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all" placeholder="e.g. Hanif Enterprise" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Coach Number</label>
                  <input type="text" value={formData.coachNumber} onChange={e => setFormData({ ...formData, coachNumber: e.target.value })} disabled={isEditMode} className={`w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none ${isEditMode ? 'bg-gray-50 text-gray-500' : 'focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100'}`} />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Bus Type</label>
                  <select value={formData.busType} onChange={e => setFormData({ ...formData, busType: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none bg-white">
                    {busTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
            </section>

            <hr className="border-gray-100" />

            {/* Section: Route & Schedule */}
            <section className="space-y-4">
              <h3 className="text-sm font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-2">
                <MapPin size={16} /> Route & Schedule
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Origin</label>
                  <input required type="text" value={formData.route.origin} onChange={e => setFormData({ ...formData, route: { ...formData.route, origin: e.target.value } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Destination</label>
                  <input required type="text" value={formData.route.destination} onChange={e => setFormData({ ...formData, route: { ...formData.route, destination: e.target.value } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-none" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Departure Time</label>
                  <input required type="time" value={formData.schedule.departureTime} onChange={e => setFormData({ ...formData, schedule: { ...formData.schedule, departureTime: e.target.value } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Arrival Time</label>
                  <input required type="time" value={formData.schedule.arrivalTime} onChange={e => setFormData({ ...formData, schedule: { ...formData.schedule, arrivalTime: e.target.value } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-2">Days of Operation</label>
                <div className="flex flex-wrap gap-2">
                  {daysOfWeek.map(day => (
                    <button key={day} type="button" onClick={() => toggleDay(day)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${formData.schedule.daysOfOperation.includes(day) ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                      {day.substring(0, 3)}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            <hr className="border-gray-100" />

            {/* Section: Fare & Amenities */}
            <section className="space-y-4">
              <h3 className="text-sm font-bold text-orange-600 uppercase tracking-wider flex items-center gap-2">
                <DollarSign size={16} /> Fare & Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Base Fare (BDT)</label>
                  <input required type="number" min="0" value={formData.fare.baseFare} onChange={e => setFormData({ ...formData, fare: { ...formData.fare, baseFare: parseInt(e.target.value) } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Total Seats</label>
                  <input required type="number" value={formData.seats.totalSeats} onChange={e => setFormData({ ...formData, seats: { ...formData.seats, totalSeats: parseInt(e.target.value) } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1.5">Layout</label>
                  <select value={formData.seats.seatLayout} onChange={e => setFormData({ ...formData, seats: { ...formData.seats, seatLayout: e.target.value } })} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none bg-white">
                    {['2x2', '2x3', '1x2'].map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-2">Amenities</label>
                <div className="flex flex-wrap gap-2">
                  {allAmenities.map(amenity => (
                    <button key={amenity} type="button" onClick={() => setFormData(prev => ({ ...prev, amenities: prev.amenities.includes(amenity) ? prev.amenities.filter(a => a !== amenity) : [...prev.amenities, amenity] }))}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${formData.amenities.includes(amenity) ? 'bg-orange-500 text-white shadow-md shadow-orange-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                      {amenity}
                    </button>
                  ))}
                </div>
              </div>
            </section>
          </form>
        </div>

        <div className="px-8 py-6 border-t border-gray-100 bg-gray-50 flex gap-4">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl border border-gray-200 text-gray-700 font-bold hover:bg-gray-100 transition-colors">Cancel</button>
          <button form="busForm" type="submit" className="flex-1 py-3 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
            {isEditMode ? 'Save Changes' : 'Create Bus'}
          </button>
        </div>
      </div>
    </div>
  );
};

// --- Tab Components ---

const ModernOverviewTab = ({ users, drivers, buses, bookings, complaints, onNavigate }) => {
  const stats = [
    { label: 'Total Users', value: users.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', nav: 'users' },
    { label: 'Active Drivers', value: drivers.filter(d => d.isVerified).length, icon: Car, color: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-100', nav: 'driver-users' },
    { label: 'Fleet Size', value: buses.length, icon: Bus, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', nav: 'buses' },
    { label: 'Total Bookings', value: bookings.length, icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100', nav: 'bookings' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} onClick={() => onNavigate(stat.nav)} className={`bg-white p-6 rounded-2xl border ${stat.border} shadow-sm hover:shadow-lg transition-all cursor-pointer group`}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500 mb-1">{stat.label}</p>
                <h3 className="text-3xl font-bold text-gray-900 group-hover:scale-105 transition-transform origin-left">{stat.value}</h3>
              </div>
              <div className={`w-12 h-12 rounded-xl ${stat.bg} ${stat.color} flex items-center justify-center`}>
                <stat.icon size={24} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm">
          <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <Clock className="text-indigo-500" /> Recent Bookings
          </h3>
          {bookings.slice(0, 5).map(bk => (
            <div key={bk._id} className="flex items-center justify-between py-4 border-b border-gray-50 last:border-0 hover:bg-gray-50 px-4 -mx-4 rounded-xl transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
                  {bk.user?.name?.charAt(0) || 'U'}
                </div>
                <div>
                  <p className="font-bold text-gray-900">{bk.user?.name || 'Guest'}</p>
                  <p className="text-sm text-gray-500">{bk.bus?.busName} • {new Date(bk.journeyDate).toLocaleDateString()}</p>
                </div>
              </div>
              <StatusBadge status={bk.status} />
            </div>
          ))}
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              <AlertTriangle className="text-orange-500" /> Action Items
            </h3>
            <div className="space-y-4">
              {complaints.length > 0 && (
                <div onClick={() => onNavigate('complaints')} className="p-4 bg-red-50 text-red-700 rounded-xl border border-red-100 flex items-center justify-between cursor-pointer hover:bg-red-100 transition-colors">
                  <span className="font-medium flex items-center gap-2"><MessageSquare size={18} /> {complaints.length} Unresolved Complaints</span>
                  <ArrowRight size={18} />
                </div>
              )}
              {drivers.filter(d => !d.isVerified).length > 0 && (
                <div onClick={() => onNavigate('driver-requests')} className="p-4 bg-amber-50 text-amber-700 rounded-xl border border-amber-100 flex items-center justify-between cursor-pointer hover:bg-amber-100 transition-colors">
                  <span className="font-medium flex items-center gap-2"><Car size={18} /> {drivers.filter(d => !d.isVerified).length} Driver Requests</span>
                  <ArrowRight size={18} />
                </div>
              )}
              <div className="p-4 bg-gray-50 rounded-xl text-center text-gray-500 text-sm">
                System Health: <span className="text-emerald-600 font-bold">Good</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const BookingsTab = ({ bookings }) => (
  <div className="space-y-6 animate-in fade-in">
    <div className="flex justify-between items-center">
      <h2 className="text-xl font-bold text-gray-900">All Bookings</h2>
      <div className="flex gap-2">
        <select className="bg-white border rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500">
          <option>All Status</option>
          <option>Confirmed</option>
          <option>Pending</option>
        </select>
      </div>
    </div>
    <div className="grid gap-6">
      {bookings.map(bk => (
        <div key={bk._id} className="bg-white rounded-3xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all group">
          <div className="bg-slate-50 p-6 flex justify-between items-center border-b border-gray-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-indigo-600 border border-gray-200 shadow-sm">
                <Bus className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-900">{bk.bus?.busName || 'Bus Service'}</h3>
                <p className="text-sm font-medium text-gray-500">ID: {bk._id.slice(-6).toUpperCase()}</p>
              </div>
            </div>
            <StatusBadge status={bk.status} />
          </div>
          <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="col-span-2 space-y-6">
              <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl border border-gray-100">
                <div className="text-center">
                  <p className="text-xs font-bold text-gray-400 uppercase">From</p>
                  <p className="text-lg font-bold text-gray-900">{bk.bus?.route?.origin}</p>
                </div>
                <div className="flex-1 px-6 flex flex-col items-center">
                  <div className="h-[2px] w-full bg-gray-200 relative my-2">
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-indigo-600" />
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-indigo-600" />
                  </div>
                  <p className="text-xs text-gray-500 font-medium">{bk.bus?.schedule?.departureTime}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs font-bold text-gray-400 uppercase">To</p>
                  <p className="text-lg font-bold text-gray-900">{bk.bus?.route?.destination}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-1 bg-white border border-gray-100 p-4 rounded-2xl">
                  <p className="text-xs text-gray-500 mb-1">Passsenger</p>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"><User size={16} /></div>
                    <div>
                      <p className="font-bold text-sm text-gray-900">{bk.user?.name || 'Guest'}</p>
                      <p className="text-xs text-gray-500">{bk.contactInfo?.phone}</p>
                    </div>
                  </div>
                </div>
                <div className="flex-1 bg-white border border-gray-100 p-4 rounded-2xl">
                  <p className="text-xs text-gray-500 mb-1">Seat Info</p>
                  <p className="font-bold text-gray-900 text-lg flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-indigo-500" /> {bk.seats?.join(', ')}</p>
                </div>
              </div>
            </div>
            <div className="space-y-4 border-l border-gray-100 pl-8">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Amount</span>
                <span className="text-xl font-bold text-indigo-600">BDT {bk.totalFare}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Payment</span>
                <span className={`text-xs font-bold uppercase px-2 py-1 rounded ${bk.payment?.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{bk.payment?.status || 'Pending'}</span>
              </div>
              {bk.shuttleService?.requested && (
                <div className="bg-blue-50 p-3 rounded-lg text-xs text-blue-700 flex items-center gap-2">
                  <Car size={14} /> Shuttle Requested
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const UsersTab = ({ users, onDelete, title = "Users", type = "user" }) => {
  const [expandedUser, setExpandedUser] = useState(null);

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
          {type === 'driver' ? <Car size={20} className="text-indigo-600" /> : <Users size={20} className="text-blue-600" />}
          {title} ({users.length})
        </h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input type="text" placeholder="Search..." className="pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500 w-64 transition-all" />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {users.map(u => (
          <div key={u._id} className={`bg-white rounded-3xl border border-gray-200 transition-all group relative overflow-hidden ${expandedUser === u._id ? 'ring-2 ring-indigo-500 shadow-xl row-span-2' : 'hover:shadow-lg'}`}>
            <div className={`p-6 ${expandedUser === u._id ? 'bg-indigo-50/50' : ''}`}>
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-gray-50 to-transparent rounded-bl-full -mr-4 -mt-4 z-0 group-hover:from-indigo-50 transition-all" />
              <div className="relative z-10 flex items-start gap-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold shadow-sm flex-shrink-0 ${type === 'driver' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'}`}>
                  {u.profileImage ? <img src={u.profileImage} className="w-full h-full object-cover rounded-2xl" /> : u.name?.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-900 truncate text-lg">{u.name}</h3>
                  <p className="text-sm text-gray-500 truncate">{u.email}</p>
                  <p className="text-xs font-medium text-gray-400 mt-1">{u.phone}</p>
                </div>
              </div>

              {expandedUser === u._id && (
                <div className="mt-6 space-y-4 relative z-10 animate-in slide-in-from-top-4 fade-in duration-300">
                  <div className="p-4 bg-white rounded-xl border border-gray-100 shadow-sm text-sm">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-gray-400 uppercase font-bold mb-1">Role</p>
                        <p className="font-semibold text-gray-900 capitalize">{u.role}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase font-bold mb-1">User ID</p>
                        <p className="font-mono text-xs text-gray-600">{u._id.slice(-6).toUpperCase()}</p>
                      </div>
                      {u.address && (
                        <div className="col-span-2">
                          <p className="text-xs text-gray-400 uppercase font-bold mb-1">Address</p>
                          <p className="text-gray-700">{u.address}</p>
                        </div>
                      )}
                      {u.preferences && (
                        <div className="col-span-2">
                          <p className="text-xs text-gray-400 uppercase font-bold mb-1">Preferences</p>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(u.preferences).map(([key, val]) => (
                              val && <span key={key} className="px-2 py-1 bg-gray-100 rounded text-xs text-gray-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="relative z-10 mt-6 pt-6 border-t border-gray-100 flex justify-between items-center">
                <div className="flex gap-2">
                  <StatusBadge status={u.isActive ? "Active" : "Inactive"} />
                  {u.role === 'driver' && <StatusBadge status={u.isVerified} type="verification" />}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setExpandedUser(expandedUser === u._id ? null : u._id)}
                    className={`p-2 rounded-lg transition-colors ${expandedUser === u._id ? 'bg-indigo-100 text-indigo-600' : 'hover:bg-gray-100 text-gray-500'}`}
                  >
                    {expandedUser === u._id ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </button>
                  <button onClick={() => onDelete(u._id)} className="p-2 hover:bg-red-50 text-gray-400 hover:text-red-600 rounded-lg transition-colors" title="Delete User">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const DriverRequestsTab = ({ drivers, onApprove, onReject }) => {
  const pending = drivers.filter(d => !d.isVerified);
  return (
    <div className="space-y-6 animate-in fade-in">
      <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Clock className="text-orange-500" /> Pending Approvals ({pending.length})</h2>
      {pending.length === 0 ? (
        <div className="bg-white rounded-3xl border border-dashed border-gray-300 p-12 text-center">
          <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400"><CheckCircle size={32} /></div>
          <p className="text-gray-500 font-medium">No pending driver requests</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {pending.map(d => (
            <div key={d._id} className="bg-white rounded-3xl border border-orange-100 shadow-sm overflow-hidden">
              <div className="bg-orange-50/50 p-6 flex items-start gap-4 border-b border-orange-100">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm text-orange-600">
                  <Car size={32} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{d.user?.name}</h3>
                  <p className="text-gray-600 text-sm">License: {d.licenseNumber}</p>
                  <div className="flex gap-2 mt-2">
                    <span className="text-xs font-bold bg-white px-2 py-1 rounded border border-orange-200 text-orange-700">{d.vehicleBrand} {d.vehicleModel}</span>
                    <span className="text-xs font-bold bg-white px-2 py-1 rounded border border-orange-200 text-orange-700">{d.vehicleRegistrationNumber}</span>
                  </div>
                </div>
              </div>
              <div className="p-6 flex gap-4">
                <button onClick={() => onApprove(d._id)} className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-lg shadow-emerald-200 transition-all flex items-center justify-center gap-2">
                  <CheckCircle size={18} /> Approve Driver
                </button>
                <button onClick={() => onReject(d._id)} className="flex-1 py-2.5 bg-white border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                  <XCircle size={18} /> Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const BusesTab = ({ buses, onEdit, onDelete, onCreate }) => (
  <div className="space-y-6 animate-in fade-in">
    <div className="flex justify-between items-center">
      <h2 className="text-xl font-bold text-gray-900">Fleet Management</h2>
      <button onClick={onCreate} className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 transition-all flex items-center gap-2">
        <Plus size={20} /> Add Bus
      </button>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {buses.map(bus => (
        <div key={bus._id} className="bg-white rounded-3xl border border-gray-200 overflow-hidden hover:shadow-xl transition-all group">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-lg text-gray-900">{bus.busName}</h3>
                <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{bus.busType} • {bus.coachNumber}</p>
              </div>
              <StatusBadge status={bus.status} />
            </div>
            <div className="flex items-center gap-3 mb-6 bg-gray-50 p-3 rounded-xl">
              <div className="flex-1">
                <p className="text-xs text-gray-400 font-bold uppercase">Route</p>
                <div className="flex items-center gap-2 font-semibold text-gray-800 text-sm">
                  {bus.route?.origin} <ArrowRight size={14} className="text-gray-400" /> {bus.route?.destination}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-400 text-xs font-bold uppercase">Departs</p>
                <p className="font-semibold text-gray-900">{bus.schedule?.departureTime}</p>
              </div>
              <div>
                <p className="text-gray-400 text-xs font-bold uppercase">Seats</p>
                <p className="font-semibold text-gray-900">{bus.seats?.availableSeats}/{bus.seats?.totalSeats}</p>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-6 py-4 border-t border-gray-100 flex gap-3">
            <button onClick={() => onEdit(bus)} className="flex-1 py-2 text-sm font-bold text-indigo-600 bg-white border border-indigo-100 rounded-lg hover:bg-indigo-50 transition-colors">Edit</button>
            <button onClick={() => onDelete(bus._id)} className="p-2 text-rose-600 bg-white border border-rose-100 rounded-lg hover:bg-rose-50 transition-colors"><Trash2 size={18} /></button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

// --- Main Admin Dashboard Component ---

const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState("overview");
  const [data, setData] = useState({ users: [], drivers: [], buses: [], bookings: [], reviews: [], complaints: [] });
  const [loading, setLoading] = useState(true);
  const [editingBus, setEditingBus] = useState(null);
  const [creatingBus, setCreatingBus] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [u, d, b, bk, r, c] = await Promise.all([
        adminService.getUsers(),
        adminService.getDrivers(),
        adminService.getBuses(),
        adminService.getBookings(),
        adminService.getReviews(),
        adminService.getComplaints(),
      ]);
      setData({ users: u || [], drivers: d || [], buses: b || [], bookings: bk || [], reviews: r || [], complaints: c || [] });
    } catch (err) {
      toast.error("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'admin') loadAll();
  }, [user]);

  const handleSaveBus = async (busData, id) => {
    try {
      if (id) await adminService.updateBus(id, busData);
      else await adminService.createBus(busData);
      toast.success(id ? "Bus updated" : "Bus created");
      loadAll();
    } catch (error) {
      throw error; // Let modal handle error toast
    }
  };

  const navItems = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "bookings", label: "Bookings", icon: Calendar },
    { id: "buses", label: "Fleet & Buses", icon: Bus },
    { id: "users", label: "Users", icon: Users },
    { id: "driver-users", label: "Drivers", icon: Car },
    { id: "driver-requests", label: "Requests", icon: ShieldCheck },
    { id: "complaints", label: "Complaints", icon: MessageSquare },
  ];

  if (!user || user.role !== 'admin') return <div className="min-h-screen flex items-center justify-center">Access Denied</div>;

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-slate-900">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 bg-slate-900 text-white w-72 transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 shadow-2xl flex flex-col`}>
        <div className="h-20 flex items-center px-8 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-indigo-500/30">J</div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">JABO Admin</h1>
              <p className="text-xs text-slate-400 font-medium">Management Portal</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
          {navItems.map(item => (
            <button key={item.id} onClick={() => { setTab(item.id); if (window.innerWidth < 1024) setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all font-medium ${tab === item.id ? 'bg-white/10 text-white shadow-lg backdrop-blur-sm' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
              <item.icon size={20} className={tab === item.id ? 'text-indigo-400' : ''} />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-white/10">
          <button onClick={() => { logout(); navigate('/login'); }} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-rose-500/10 hover:text-rose-400 transition-colors font-medium">
            <LogOut size={20} /> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'lg:ml-72' : 'ml-0'}`}>
        <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-gray-200 h-20 px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-gray-100 rounded-lg lg:hidden">
              <Menu size={24} />
            </button>
            <h2 className="text-xl font-bold text-slate-800 capitalize">{tab.replace('-', ' ')}</h2>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold border border-slate-200">
              {user.name?.charAt(0).toUpperCase()}
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {loading ? (
            <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" /></div>
          ) : (
            <>
              {tab === 'overview' && <ModernOverviewTab {...data} onNavigate={setTab} />}
              {tab === 'bookings' && <BookingsTab bookings={data.bookings} />}
              {tab === 'buses' && <BusesTab buses={data.buses} onEdit={setEditingBus} onCreate={() => setCreatingBus(true)} onDelete={async (id) => { if (window.confirm('Delete bus?')) { await adminService.deleteBus(id); loadAll(); } }} />}
              {tab === 'users' && <UsersTab users={data.users.filter(u => u.role === 'user')} onDelete={async (id) => { if (window.confirm('Delete user?')) { await adminService.deleteUser(id); loadAll(); } }} />}
              {tab === 'driver-users' && <UsersTab title="Drivers" type="driver" users={data.users.filter(u => u.role === 'driver')} onDelete={async (id) => { if (window.confirm('Delete driver?')) { await adminService.deleteUser(id); loadAll(); } }} />}
              {tab === 'driver-requests' && <DriverRequestsTab drivers={data.drivers} onApprove={async (id) => { await adminService.approveDriver(id); loadAll(); }} onReject={async (id) => { await adminService.rejectDriver(id); loadAll(); }} />}
              {tab === 'complaints' && (
                <div className="space-y-4 animate-in fade-in">
                  {data.complaints.map(c => (
                    <div key={c._id} className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                      <div className="flex justify-between mb-2">
                        <h3 className="font-bold text-gray-900">{c.subject}</h3>
                        <p className="text-xs text-gray-500">{new Date(c.createdAt).toLocaleDateString()}</p>
                      </div>
                      <p className="text-gray-600 mb-4">{c.message}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-500 bg-gray-50 p-3 rounded-lg">
                        <User size={16} /> From: <span className="font-semibold text-gray-900">{c.user?.name}</span> ({c.user?.email})
                      </div>
                    </div>
                  ))}
                  {data.complaints.length === 0 && <div className="text-center text-gray-500 py-12">No complaints found</div>}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {(editingBus || creatingBus) && (
        <BusEditModal
          bus={editingBus}
          onClose={() => { setEditingBus(null); setCreatingBus(false); }}
          onSave={handleSaveBus}
        />
      )}
    </div>
  );
};

export default AdminDashboard;
