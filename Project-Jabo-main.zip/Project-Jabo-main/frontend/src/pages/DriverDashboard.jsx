// ==========================================
// FILE: frontend/src/pages/DriverDashboard.jsx
// ==========================================

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {
  Car,
  DollarSign,
  Users,
  MapPin,
  AlertCircle,
  CheckCircle,
  Wifi,
  WifiOff,
  Timer,
  Home as HomeIcon,
  List,
  MessageCircle,
  User as UserIcon,
  Phone,
  Navigation,
  LogOut,
  Circle as LucideCircle,
  TrendingUp,
  CreditCard,
  Calendar,
  Settings,
  Shield,
  FileText,
  Bell,
  ChevronRight,
  Power
} from 'lucide-react';
import Skeleton from '../components/common/Skeleton';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import { getDriverProfile } from '../services/driverService';
import {
  acceptShuttleRequest,
  fetchDriverAvailableShuttles,
  fetchDriverShuttles,
  updateShuttleStatus,
} from '../services/shuttleService';
import { MapContainer, TileLayer, Marker, Circle as LeafletCircle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const ACTIVE_STATUSES = ['accepted', 'on_the_way', 'arrived', 'started'];
const STATUS_LABELS = {
  pending: 'Pending',
  accepted: 'Assigned',
  on_the_way: 'On the way',
  arrived: 'Reached pickup',
  started: 'Ride started',
  completed: 'Completed',
  cancelled: 'Cancelled',
};

const STATUS_ACTIONS = {
  accepted: { next: 'on_the_way', label: 'Head to Pickup' },
  on_the_way: { next: 'arrived', label: 'Arrived at Pickup' },
  arrived: { next: 'started', label: 'Start Ride' },
  started: { next: 'completed', label: 'Complete Ride' },
};

const TAB_CONFIG = [
  { id: 'home', label: 'Home', icon: HomeIcon },
  { id: 'trips', label: 'Trips', icon: List },
  { id: 'messages', label: 'Chat', icon: MessageCircle },
  { id: 'profile', label: 'Profile', icon: UserIcon },
];

const DEFAULT_COORDS = { lat: 23.8103, lng: 90.4125 };

const currency = (amount = 0) => `৳${amount.toLocaleString('en-US')}`;

// ==========================================
// DRIVER DASHBOARD COMPONENT
// ==========================================
const DriverDashboard = () => {
  const navigate = useNavigate();

  const { user, loading: authLoading, logout } = useAuth();
  const { socket, isConnected } = useSocket();

  const [activeTab, setActiveTab] = useState('home');
  const [driverProfile, setDriverProfile] = useState(null);
  const [isAvailable, setIsAvailable] = useState(true);
  const [loading, setLoading] = useState(true);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [activeRide, setActiveRide] = useState(null);
  const [completedRides, setCompletedRides] = useState([]);
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const [driverPosition, setDriverPosition] = useState(null);

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const ensureDriver = useCallback(() => {
    if (authLoading) return false;
    if (!user) {
      navigate('/login', { replace: true, state: { from: '/driver-dashboard' } });
      return false;
    }
    if (user.role !== 'driver') {
      navigate('/', { replace: true });
      return false;
    }
    return true;
  }, [authLoading, navigate, user]);

  useEffect(() => {
    ensureDriver();
  }, [ensureDriver]);

  const loadDriverProfile = useCallback(async () => {
    try {
      const response = await getDriverProfile();
      setDriverProfile(response.data);
      setIsAvailable(response.data?.stats?.availability?.isAvailable ?? true);
    } catch (error) {
      console.error('Failed to load driver profile', error);
    }
  }, []);

  const refreshAvailable = useCallback(async () => {
    try {
      const response = await fetchDriverAvailableShuttles();
      setPendingRequests(response.data || []);
    } catch (error) {
      console.error('Failed to load available shuttles', error);
    }
  }, []);

  const refreshDriverRides = useCallback(async () => {
    try {
      const response = await fetchDriverShuttles();
      const rides = response.data || [];
      const active = rides.find((ride) => ACTIVE_STATUSES.includes(ride.status));
      setActiveRide(active || null);
      setCompletedRides(rides.filter((ride) => ride.status === 'completed'));
    } catch (error) {
      console.error('Failed to fetch driver rides', error);
      toast.error('Unable to load your rides right now.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!ensureDriver()) return;
    setLoading(true);
    Promise.allSettled([loadDriverProfile(), refreshAvailable(), refreshDriverRides()]).finally(() =>
      setLoading(false)
    );
  }, [ensureDriver, loadDriverProfile, refreshAvailable, refreshDriverRides]);

  useEffect(() => {
    if (!socket || !driverProfile?.driver?.id) return;
    socket.emit('driver-online');
  }, [socket, driverProfile]);

  useEffect(() => {
    if (!socket || authLoading || user?.role !== 'driver') return;

    const handleIncoming = async (payload) => {
      console.log('🚗 New shuttle request received:', payload);

      toast.custom(
        () => (
          <div className="px-4 py-3 bg-white shadow-lg rounded-xl border border-orange-100 flex items-center gap-3 animate-in slide-in-from-top-2">
            <div className="bg-orange-100 p-2 rounded-full">
              <Car className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-800">New shuttle request!</p>
              <p className="text-xs text-gray-500">{payload.pickup?.address ?? 'Tap to view details'}</p>
            </div>
          </div>
        ),
        { duration: 4000 }
      );

      setPendingRequests((prev) => {
        const exists = prev.some(req => req._id === payload._id);
        if (exists) return prev;
        return [payload, ...prev];
      });

      try {
        await refreshAvailable();
      } catch (error) {
        console.error('❌ Error refreshing available shuttles:', error);
      }
    };
    const removeRequest = ({ shuttleId }) => {
      setPendingRequests((prev) => prev.filter((ride) => ride._id !== shuttleId));
    };

    const handleAssigned = async () => {
      await Promise.all([
        refreshDriverRides(),
        refreshAvailable()
      ]);
    };

    const handleShuttleCancelled = async ({ shuttleId }) => {
      if (activeRide?._id === shuttleId) {
        toast('Passenger cancelled the ride.');
        setActiveRide(null);
        setIsAvailable(true);
      }
      await Promise.all([
        refreshDriverRides(),
        refreshAvailable()
      ]);
    };

    const handleAvailabilityUpdate = ({ isAvailable: available }) => {
      setIsAvailable(available);
    };

    socket.on('incoming-shuttle-request', handleIncoming);
    socket.on('request-already-taken', removeRequest);
    socket.on('remove-request', removeRequest);
    socket.on('driver-shuttle-assigned', handleAssigned);
    socket.on('shuttle-cancelled', handleShuttleCancelled);
    socket.on('driver:availability:updated', handleAvailabilityUpdate);

    return () => {
      socket.off('incoming-shuttle-request', handleIncoming);
      socket.off('request-already-taken', removeRequest);
      socket.off('remove-request', removeRequest);
      socket.off('driver-shuttle-assigned', handleAssigned);
      socket.off('shuttle-cancelled', handleShuttleCancelled);
      socket.off('driver:availability:updated', handleAvailabilityUpdate);
    };
  }, [socket, activeRide, authLoading, user, refreshAvailable, refreshDriverRides]);

  useEffect(() => {
    if (!socket || !activeRide) {
      setMessages([]);
      return;
    }

    socket.emit('shuttle:join', activeRide._id);

    const handleMessage = (payload) => {
      if (!payload._id || !payload.content || !payload.senderType) return;

      if (activeRide && (!payload.shuttleId || payload.shuttleId === activeRide._id)) {
        setMessages((prev) => {
          const exists = prev.some(m => m._id === payload._id);
          if (exists) return prev;
          return [...prev, payload];
        });
      }
    };

    const handleSocketError = (error) => {
      if (error.message) toast.error(error.message);
    };

    socket.on('chat:message', handleMessage);
    socket.on('error', handleSocketError);

    return () => {
      socket.off('chat:message', handleMessage);
      socket.off('error', handleSocketError);
      socket.emit('shuttle:leave', activeRide._id);
    };
  }, [socket, activeRide]);

  const handleAvailabilityToggle = () => {
    if (!socket) {
      toast.error('Socket connection missing.');
      return;
    }
    const targetState = !isAvailable;
    setIsAvailable(targetState);
    socket.emit('driver:availability', { isAvailable: targetState });
    if (!targetState) {
      toast.success('You are now offline');
    } else {
      toast.success('You are now available');
    }
  };

  const handleAccept = async (shuttleId) => {
    try {
      const response = await acceptShuttleRequest(shuttleId);
      const ride = response.data;
      toast.success('Ride accepted. Passenger notified.');
      setActiveRide(ride);
      setIsAvailable(false);
      setPendingRequests((prev) => prev.filter((req) => req._id !== shuttleId));
    } catch (error) {
      const message = error.response?.data?.message || 'Could not accept this ride.';
      toast.error(message);
      refreshAvailable();
    }
  };

  const handleAdvanceStatus = async () => {
    if (!activeRide) return;
    const action = STATUS_ACTIONS[activeRide.status];
    if (!action) return;
    try {
      await updateShuttleStatus(activeRide._id, action.next);
      toast.success(`Status updated: ${STATUS_LABELS[action.next]}`);
      refreshDriverRides();
    } catch (error) {
      const message = error.response?.data?.message || 'Unable to update status.';
      toast.error(message);
    }
  };

  const sendMessage = () => {
    if (!socket || !activeRide || !messageInput.trim()) return;

    const messageContent = messageInput.trim();
    setMessageInput('');

    try {
      socket.emit('chat:message', {
        shuttleId: activeRide._id,
        content: messageContent,
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message.');
      setMessageInput(messageContent);
    }
  };

  const nextAction = useMemo(() => {
    if (!activeRide) return null;
    return STATUS_ACTIONS[activeRide.status] || null;
  }, [activeRide]);

  const todaysEarnings = useMemo(() => {
    const today = new Date();
    return completedRides
      .filter((ride) => {
        if (!ride.completedAt) return false;
        const completedAt = new Date(ride.completedAt);
        return completedAt.toDateString() === today.toDateString();
      })
      .reduce((sum, ride) => sum + (ride.fare?.total || 0), 0);
  }, [completedRides]);

  const driverInitials = useMemo(() => {
    if (!user?.name) return 'D';
    return user.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }, [user?.name]);

  if (authLoading || !user || user.role !== 'driver') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="h-10 w-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">Connecting to Jabo Driver...</p>
        </div>
      </div>
    );
  }

  const earningsToday = driverProfile?.stats?.earningsToday ?? todaysEarnings;
  const totalRides = driverProfile?.stats?.totalCompleted ?? completedRides.length;

  // ==========================================
  // RENDER: HOME TAB
  // ==========================================
  const renderHomeTab = () => (
    <div className="space-y-6 animate-in fade-in pb-20 lg:pb-0">
      {/* HEADER STATS CARD */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 rounded-3xl p-6 text-white shadow-xl shadow-orange-200 relative overflow-hidden">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-fullblur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-black/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2"></div>

        <div className="relative z-10 flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center font-bold text-lg border border-white/30">
                {driverInitials}
              </div>
              <div>
                <h2 className="text-lg font-bold leading-tight">{user?.name}</h2>
                <p className="text-orange-100 text-xs flex items-center gap-1">
                  <Car className="h-3 w-3" /> {driverProfile?.driver?.vehicleType}
                </p>
              </div>
            </div>

            {/* ONLINE TOGGLE */}
            <button
              onClick={handleAvailabilityToggle}
              className={`relative group px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${isAvailable
                  ? 'bg-white text-emerald-600 shadow-lg'
                  : 'bg-white/10 text-white border border-white/20 hover:bg-white/20'
                }`}
            >
              <span className={`h-2 w-2 rounded-full ${isAvailable ? 'bg-emerald-500 animate-pulse' : 'bg-gray-400'}`}></span>
              {isAvailable ? 'Online' : 'Offline'}
            </button>
          </div>

          <div className="flex gap-4">
            <div className="flex-1 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
              <p className="text-orange-100 text-xs uppercase tracking-wide mb-1">Earnings Today</p>
              <p className="text-2xl font-bold">{currency(earningsToday)}</p>
            </div>
            <div className="flex-1 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
              <p className="text-orange-100 text-xs uppercase tracking-wide mb-1">Rides Completed</p>
              <p className="text-2xl font-bold">{totalRides}</p>
            </div>
          </div>
        </div>
      </section>

      {/* QUICK STATS GRID */}
      <StatsGrid
        loading={loading}
        stats={[
          { label: 'Requests', value: pendingRequests.length, icon: <Bell className="h-5 w-5 text-blue-600" />, color: 'bg-blue-50' },
          { label: 'Rating', value: '4.8★', icon: <Users className="h-5 w-5 text-yellow-500" />, color: 'bg-yellow-50' },
          { label: 'Hours', value: '6.5h', icon: <Timer className="h-5 w-5 text-purple-600" />, color: 'bg-purple-50' },
        ]}
      />

      {/* ACTIVE RIDE OR INCOMING REQUESTS */}
      {activeRide ? (
        <ActiveRidePanel
          ride={activeRide}
          driverPosition={driverPosition}
          nextAction={nextAction}
          onAdvance={handleAdvanceStatus}
        />
      ) : (
        <IncomingRequests
          loading={loading}
          requests={pendingRequests}
          onAccept={handleAccept}
          onIgnore={(id) => setPendingRequests((prev) => prev.filter((req) => req._id !== id))}
        />
      )}
    </div>
  );

  // ==========================================
  // RENDER: TRIPS TAB
  // ==========================================
  const renderTripsTab = () => (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden min-h-[70vh]">
      <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
        <h3 className="text-lg font-bold text-gray-900">Trip History</h3>
        <span className="text-xs font-medium px-3 py-1 bg-gray-100 text-gray-600 rounded-full">{completedRides.length} Trips</span>
      </div>

      {completedRides.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center text-gray-400">
          <div className="h-20 w-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            <List className="h-8 w-8 text-gray-300" />
          </div>
          <p className="font-medium text-gray-900">No trips yet</p>
          <p className="text-sm mt-1">Your completed rides will appear here.</p>
        </div>
      ) : (
        <div className="divide-y divide-gray-100">
          {completedRides.map((ride) => (
            <div key={ride._id} className="p-5 hover:bg-gray-50 transition-colors group">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold text-xs">
                    {ride.user?.name?.[0] || 'U'}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{ride.user?.name || 'Passenger'}</p>
                    <p className="text-xs text-gray-500">
                      {ride.completedAt ? new Date(ride.completedAt).toLocaleString(undefined, {
                        weekday: 'short', hour: 'numeric', minute: 'numeric'
                      }) : 'Date N/A'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-900 text-base">{currency(ride.fare?.total)}</p>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                    Paid
                  </span>
                </div>
              </div>

              <div className="pl-13 ml-3 border-l-2 border-gray-100 space-y-3 py-1 relative">
                <div className="relative pl-6">
                  <div className="absolute left-[-5px] top-1 h-2.5 w-2.5 rounded-full border-2 border-white bg-green-500 shadow-sm"></div>
                  <p className="text-sm text-gray-600 leading-snug">{ride.pickup?.address}</p>
                </div>
                <div className="relative pl-6">
                  <div className="absolute left-[-5px] top-1 h-2.5 w-2.5 rounded-full border-2 border-white bg-red-500 shadow-sm"></div>
                  <p className="text-sm text-gray-600 leading-snug">{ride.dropoff?.address}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  // ==========================================
  // RENDER: MESSAGES TAB
  // ==========================================
  const renderMessagesTab = () => (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 flex flex-col h-[calc(100vh-140px)] lg:h-[700px] overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
              <MessageCircle className="h-5 w-5 text-blue-600" />
            </div>
            {activeRide && <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 border-2 border-white rounded-full"></div>}
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-900">Live Chat</h3>
            <p className="text-xs text-gray-500">
              {activeRide ? `Connected with ${activeRide.user?.name}` : 'No active session'}
            </p>
          </div>
        </div>
      </div>

      {activeRide ? (
        <>
          <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#f8fafc]">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-gray-400 space-y-2">
                <MessageCircle className="h-12 w-12 text-gray-200" />
                <p className="text-sm">Start the conversation</p>
              </div>
            )}

            {messages.map((msg) => {
              const isMyMessage = msg.senderId === user?.id;
              return (
                <div key={`${msg._id}-${msg.createdAt}`} className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm shadow-sm ${isMyMessage
                      ? 'bg-orange-500 text-white rounded-tr-none'
                      : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none'
                    }`}>
                    <p className="leading-relaxed">{msg.content}</p>
                    <p className={`text-[10px] mt-1 text-right ${isMyMessage ? 'text-orange-100/80' : 'text-gray-400'}`}>
                      {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-4 bg-white border-t border-gray-100 flex items-center gap-3">
            <input
              type="text"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
              placeholder="Type your message..."
              className="flex-1 bg-gray-50 border-0 rounded-full px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-gray-900 placeholder:text-gray-400"
            />
            <button
              onClick={sendMessage}
              disabled={!messageInput.trim()}
              className="h-11 w-11 rounded-full bg-orange-600 flex items-center justify-center text-white hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-orange-200"
            >
              <Navigation className="h-5 w-5 rotate-90" />
            </button>
          </div>
        </>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-gray-500 bg-gray-50">
          <div className="h-20 w-20 bg-white rounded-full shadow-sm flex items-center justify-center mb-4">
            <MessageCircle className="h-8 w-8 text-gray-300" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">No Active Ride</h3>
          <p className="text-sm max-w-xs mx-auto mt-2">Chat will become available once you accept a ride request.</p>
        </div>
      )}
    </div>
  );

  // ==========================================
  // RENDER: PROFILE TAB
  // ==========================================
  const renderProfileTab = () => (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="relative h-32 bg-gradient-to-r from-orange-400 to-amber-500">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      </div>

      <div className="px-6 pb-6">
        <div className="relative -mt-12 mb-6 flex justify-between items-end">
          <div className="h-24 w-24 rounded-2xl bg-white p-1.5 shadow-lg">
            <div className="h-full w-full bg-gray-100 rounded-xl flex items-center justify-center text-2xl font-bold text-gray-400">
              {driverInitials}
            </div>
          </div>
          <button className="px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold transition-colors flex items-center gap-2">
            <Settings className="h-4 w-4" /> Edit
          </button>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">{user?.name}</h2>
          <p className="text-gray-500 flex items-center gap-2 mt-1">
            <ShieldCheckBadge verified={true} />
            Verified Driver
          </p>
        </div>

        <div className="space-y-6">
          <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2">
            <Car className="h-4 w-4 text-orange-500" /> Vehicle Details
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InfoCard label="Model" value={driverProfile?.driver?.vehicleModel || 'Not Set'} icon={<Car className="h-4 w-4" />} />
            <InfoCard label="Brand" value={driverProfile?.driver?.vehicleBrand || 'Not Set'} icon={<Shield className="h-4 w-4" />} />
            <InfoCard label="Plate Number" value={driverProfile?.driver?.vehicleRegistrationNumber} icon={<FileText className="h-4 w-4" />} />
            <InfoCard label="Type" value={driverProfile?.driver?.vehicleType} icon={<Navigation className="h-4 w-4" />} />
          </div>

          <div className="h-px bg-gray-100 my-6"></div>

          <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2">
            <Shield className="h-4 w-4 text-orange-500" /> Legal & Privacy
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InfoCard label="License No." value={driverProfile?.driver?.licenseNumber} icon={<FileText className="h-4 w-4" />} />
            <InfoCard label="NID Number" value={driverProfile?.driver?.nidNumber} icon={<UserIcon className="h-4 w-4" />} />
          </div>

          <div className="pt-6">
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-100 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Log Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'home': return renderHomeTab();
      case 'trips': return renderTripsTab();
      case 'messages': return renderMessagesTab();
      case 'profile': return renderProfileTab();
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50/50 pb-20 lg:pb-0 font-sans">
      <div className="lg:flex max-w-7xl mx-auto">
        {/* Desktop Sidebar (Only visible on large screens) */}
        <aside className="hidden lg:flex w-72 flex-col fixed inset-y-0 left-0 bg-white border-r border-gray-100 z-50">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center gap-2 text-orange-600 font-bold text-xl">
              <Navigation className="h-8 w-8" />
              <span>Jabo Driver</span>
            </div>
          </div>

          <div className="p-4 flex-1 space-y-1">
            {TAB_CONFIG.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === tab.id
                    ? 'bg-orange-50 text-orange-700'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                  }`}
              >
                <tab.icon className={`h-5 w-5 ${activeTab === tab.id ? 'text-orange-600' : 'text-gray-400'}`} />
                {tab.label}
              </button>
            ))}
          </div>

          <div className="p-4 border-t border-gray-100">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 text-white">
              <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Status</p>
              <div className="flex items-center justify-between">
                <p className="font-semibold">{isAvailable ? 'Online' : 'Offline'}</p>
                <div className={`h-2 w-2 rounded-full ${isAvailable ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`}></div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 lg:pl-72 w-full">
          <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8">
            {/* Mobile Header */}
            <header className="lg:hidden flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Driver Portal</h1>
                <p className="text-xs text-gray-500">{new Date().toDateString()}</p>
              </div>
              <div className="h-10 w-10 rounded-full overflow-hidden border border-gray-200">
                <div className="h-full w-full bg-orange-100 flex items-center justify-center font-bold text-orange-800 text-xs">
                  {driverInitials}
                </div>
              </div>
            </header>

            {renderTabContent()}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <DriverBottomNav tabs={TAB_CONFIG} activeTab={activeTab} onChange={setActiveTab} />
    </div>
  );
};

// ==========================================
// SUB-COMPONENTS
// ==========================================

const StatsGrid = ({ loading, stats }) => (
  <div className="grid grid-cols-3 gap-3 sm:gap-4">
    {stats.map((stat) => (
      <div key={stat.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3 sm:p-4 text-center sm:text-left flex flex-col items-center sm:items-start gap-2 sm:gap-0">
        <div className={`p-2 rounded-xl ${stat.color} mb-1 inline-block`}>{stat.icon}</div>
        <div>
          <p className="text-[10px] sm:text-xs text-gray-500 font-medium uppercase">{stat.label}</p>
          {loading ? (
            <Skeleton className="h-6 w-12 mt-1" />
          ) : (
            <p className="text-base sm:text-xl font-bold text-gray-900 leading-none mt-1">{stat.value}</p>
          )}
        </div>
      </div>
    ))}
  </div>
);

const IncomingRequests = ({ loading, requests, onAccept, onIgnore }) => (
  <section className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
    <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
      <h3 className="text-lg font-bold text-gray-900">Requests</h3>
      {requests.length > 0 && (
        <span className="flex items-center gap-1 text-xs font-bold text-white bg-red-500 px-2 py-0.5 rounded-full animate-pulse">
          {requests.length} New
        </span>
      )}
    </div>

    {loading ? (
      <PendingRequestsSkeleton />
    ) : requests.length > 0 ? (
      <div className="divide-y divide-gray-100">
        {requests.map((request) => (
          <div key={request._id} className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <UserIcon className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{request.user?.name || 'Passenger'}</p>
                  <p className="text-xs text-gray-500">Distance: {request.distance?.toFixed(1) || '--'} km</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-lg text-emerald-600">{currency(request.fare?.total)}</p>
                <p className="text-[10px] text-gray-400 uppercase font-medium">Est. Fare</p>
              </div>
            </div>

            <div className="space-y-3 mb-6 relative">
              <div className="absolute left-[3px] top-2 bottom-4 w-0.5 bg-gray-200 border-l border-dashed border-gray-300"></div>
              <div className="flex gap-3 relative z-10">
                <div className="h-2 w-2 rounded-full border-2 border-white bg-green-500 shadow-sm mt-1.5 shrink-0"></div>
                <p className="text-sm text-gray-600 font-medium">{request.pickup?.address}</p>
              </div>
              <div className="flex gap-3 relative z-10">
                <div className="h-2 w-2 rounded-full border-2 border-white bg-red-500 shadow-sm mt-1.5 shrink-0"></div>
                <p className="text-sm text-gray-600 font-medium">{request.dropoff?.address}</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => onIgnore(request._id)}
                className="flex-1 rounded-xl py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                Decline
              </button>
              <button
                onClick={() => onAccept(request._id)}
                className="flex-[2] rounded-xl py-3 text-sm font-bold text-white bg-gray-900 hover:bg-black transition-all shadow-lg shadow-gray-200"
              >
                Accept Ride
              </button>
            </div>
          </div>
        ))}
      </div>
    ) : (
      <div className="py-12 flex flex-col items-center text-center px-4">
        <div className="h-20 w-20 bg-blue-50 rounded-full flex items-center justify-center mb-4 animate-pulse">
          <Wifi className="h-8 w-8 text-blue-500" />
        </div>
        <h3 className="text-lg font-bold text-gray-900">Scanning for requests...</h3>
        <p className="text-sm text-gray-500 mt-1 max-w-xs">
          Stay online and nearby high-demand areas to receive trip requests.
        </p>
      </div>
    )}
  </section>
);

const ActiveRidePanel = ({ ride, driverPosition, nextAction, onAdvance }) => {
  if (!ride) return null;

  const pickupCoords = coordsToLatLng(ride.pickup?.coordinates);
  const dropoffCoords = coordsToLatLng(ride.dropoff?.coordinates);

  return (
    <section className="bg-white rounded-3xl border border-orange-100 shadow-xl shadow-orange-100/50 overflow-hidden">
      {/* STATUS HEADER */}
      <div className="bg-orange-50 px-6 py-4 border-b border-orange-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-orange-500 animate-pulse"></div>
          <span className="text-sm font-bold text-orange-800 uppercase tracking-wide">Live Ride</span>
        </div>
        <span className="text-xs font-bold bg-white text-orange-600 px-2 py-1 rounded-md border border-orange-100 shadow-sm">
          {STATUS_LABELS[ride.status]}
        </span>
      </div>

      <div className="p-6">
        {/* PASSENGER INFO */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center">
              <UserIcon className="h-6 w-6 text-gray-500" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 text-lg">{ride.user?.name}</h3>
              <a href={`tel:${ride.user?.phone}`} className="inline-flex items-center gap-1 text-sm font-semibold text-blue-600 hover:underline bg-blue-50 px-2 py-0.5 rounded-md mt-1">
                <Phone className="h-3 w-3" /> Call Passenger
              </a>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400 uppercase font-medium">To Collect</p>
            <p className="text-xl font-bold text-gray-900">{currency(ride.fare?.total)}</p>
          </div>
        </div>

        {/* MAP PREVIEW */}
        <div className="h-48 rounded-2xl overflow-hidden border border-gray-200 mb-6 relative group">
          <DriverRideMap
            pickup={pickupCoords}
            dropoff={dropoffCoords}
            driverPosition={driverPosition}
          />
          <button
            onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${pickupCoords.lat},${pickupCoords.lng}`)}
            className="absolute bottom-3 right-3 bg-white shadow-lg text-sm font-bold px-4 py-2 rounded-xl flex items-center gap-2 hover:scale-105 transition-transform"
          >
            <Navigation className="h-4 w-4 text-blue-600" /> Open Maps
          </button>
        </div>

        {/* ACTION BUTTON */}
        <button
          disabled={!nextAction}
          onClick={onAdvance}
          className="w-full relative overflow-hidden group rounded-2xl bg-gradient-to-r from-orange-600 to-orange-500 text-white font-bold py-4 text-lg shadow-lg shadow-orange-200 hover:shadow-orange-300 transition-all active:scale-[0.98]"
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            {nextAction ? nextAction.label : 'Waiting...'} <ChevronRight className="h-5 w-5" />
          </span>
        </button>
      </div>
    </section>
  );
};

const DriverRideMap = ({ pickup, dropoff, driverPosition }) => {
  const center = pickup?.lat ? [pickup.lat, pickup.lng] : [DEFAULT_COORDS.lat, DEFAULT_COORDS.lng];
  return (
    <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
      <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
      {pickup?.lat && (
        <Marker position={[pickup.lat, pickup.lng]}>
          <LeafletCircle center={[pickup.lat, pickup.lng]} radius={100} pathOptions={{ color: '#10B981', fillColor: '#10B981', fillOpacity: 0.2 }} />
        </Marker>
      )}
      {dropoff?.lat && <Marker position={[dropoff.lat, dropoff.lng]} />}
      {driverPosition && <Marker position={driverPosition} />}
    </MapContainer>
  );
};

const DriverBottomNav = ({ tabs, activeTab, onChange }) => (
  <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] lg:hidden z-40 pb-safe">
    <div className="flex justify-around items-center h-16">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex flex-col items-center justify-center w-full h-full transition-all ${isActive ? 'text-orange-600' : 'text-gray-400 hover:text-gray-600'
              }`}
          >
            <div className={`relative p-1.5 rounded-xl transition-all ${isActive ? 'bg-orange-50 translate-y-[-2px]' : ''}`}>
              <tab.icon className={`h-6 w-6 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {tab.id === 'messages' && <div className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full border border-white"></div>}
            </div>
            <span className={`text-[10px] font-medium mt-0.5 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  </div>
);

const InfoCard = ({ label, value, icon }) => (
  <div className="flex items-center gap-3 p-3 rounded-2xl border border-gray-100 bg-gray-50/50">
    <div className="h-8 w-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-gray-500 border border-gray-100 shrink-0">
      {icon}
    </div>
    <div className="min-w-0">
      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">{label}</p>
      <p className="text-sm font-semibold text-gray-900 truncate">{value || 'N/A'}</p>
    </div>
  </div>
);

const ShieldCheckBadge = () => (
  <div className="h-4 w-4 bg-sky-500 rounded-full flex items-center justify-center text-white p-0.5">
    <CheckCircle className="h-full w-full" />
  </div>
);

const coordsToLatLng = (coords) => {
  if (!Array.isArray(coords) || coords.length < 2) return DEFAULT_COORDS;
  return { lat: coords[1], lng: coords[0] };
};

const PendingRequestsSkeleton = () => (
  <div className="p-6 space-y-6">
    {[1, 2].map((i) => (
      <div key={i} className="animate-pulse space-y-4">
        <div className="flex justify-between">
          <div className="h-4 w-32 bg-gray-200 rounded"></div>
          <div className="h-4 w-16 bg-gray-200 rounded"></div>
        </div>
        <div className="space-y-2">
          <div className="h-3 w-full bg-gray-100 rounded"></div>
          <div className="h-3 w-2/3 bg-gray-100 rounded"></div>
        </div>
        <div className="h-10 w-full bg-gray-200 rounded-xl"></div>
      </div>
    ))}
  </div>
);

export default DriverDashboard;
