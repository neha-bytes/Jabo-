import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { MapPin, Users, Bus, Clock, CheckCircle2, CreditCard, ArrowRight } from 'lucide-react';
import { getBusById } from '../services/busService';
import { createBooking } from '../services/bookingService';
import { processFakePayment } from '../services/paymentService';
import { useAuth } from '../context/AuthContext';
import LoginModal from '../components/LoginModal';
import PaymentModal from '../components/PaymentModal';

const paymentOptions = [
  { label: 'bKash', value: 'bKash', description: 'Mobile wallet (instant)' },
  { label: 'Nagad', value: 'Nagad', description: 'Quick cash-in' },
  { label: 'Card', value: 'Card', description: 'Visa / Master / Amex' },
  { label: 'Cash', value: 'Cash', description: 'Pay at counter' },
];

const Booking = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [bus, setBus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [journeyDate, setJourneyDate] = useState(new Date().toISOString().split('T')[0]);
  const [contactInfo, setContactInfo] = useState({
    fullName: '',
    email: '',
    phone: '',
  });

  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [pendingPayment, setPendingPayment] = useState(false);

  // Pre-fill user information when user is loaded
  useEffect(() => {
    if (user && !contactInfo.fullName && !contactInfo.email && !contactInfo.phone) {
      setContactInfo({
        fullName: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
      });
    }
  }, [user]);
  const [submitting, setSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('bKash');
  const [bookingResult, setBookingResult] = useState(null);
  const [paymentReceipt, setPaymentReceipt] = useState(null);
  const [showShuttlePrompt, setShowShuttlePrompt] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const busId = params.get('busId');
    const date = params.get('date') || new Date().toISOString().split('T')[0];

    // Update journeyDate state if it's different
    if (date !== journeyDate) {
      setJourneyDate(date);
    }

    if (!busId) {
      setError('Missing bus information. Please start from the search page.');
      setLoading(false);
      return;
    }

    const fetchBus = async () => {
      try {
        // Use the date from URL params, not the state (to avoid race condition)
        const dateToUse = params.get('date') || journeyDate;
        const response = await getBusById(busId, dateToUse);
        if (response.success) {
          setBus(response.data);
        } else {
          setError('Unable to load bus details.');
        }
      } catch (err) {
        setError('Unable to load bus details.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBus();
  }, [location.search, journeyDate]);

  const seatColumns = useMemo(() => {
    if (!bus?.seats?.seatLayout) return 4;
    const parts = bus.seats.seatLayout.split('x').map((part) => parseInt(part, 10));
    return parts.reduce((sum, val) => sum + (isNaN(val) ? 0 : val), 0) || 4;
  }, [bus]);

  const seatMap = useMemo(() => {
    if (!bus?.seats?.totalSeats) return [];
    const seats = [];
    const rows = Math.ceil(bus.seats.totalSeats / seatColumns);
    for (let row = 0; row < rows; row += 1) {
      for (let col = 0; col < seatColumns; col += 1) {
        const seatNumber = row * seatColumns + col + 1;
        if (seatNumber > bus.seats.totalSeats) break;
        seats.push(`${String.fromCharCode(65 + row)}${col + 1}`);
      }
    }
    return seats;
  }, [bus, seatColumns]);

  const toggleSeat = (seat) => {
    // Use bookedSeatsForDate if available (date-specific), otherwise fall back to global bookedSeats
    const bookedSeats = bus.bookedSeatsForDate || bus.seats?.bookedSeats || [];
    if (bookedSeats.includes(seat)) return;
    setSelectedSeats((prev) =>
      prev.includes(seat) ? prev.filter((s) => s !== seat) : [...prev, seat]
    );
  };

  const totalFare = useMemo(() => {
    if (!bus?.fare?.baseFare) return 0;
    return selectedSeats.length * bus.fare.baseFare;
  }, [selectedSeats, bus]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedSeats.length) {
      toast.error('Please select at least one seat.');
      return;
    }
    if (!contactInfo.fullName || !contactInfo.email || !contactInfo.phone) {
      toast.error('Please provide passenger contact details.');
      return;
    }

    // Check if user is logged in
    if (!user) {
      setPendingPayment(true);
      setShowLoginModal(true);
      return;
    }

    // Show payment modal
    setShowPaymentModal(true);
  };

  /**
   * Auto-download ticket PDF after successful booking
   * @param {string} bookingId - The ID of the created booking
   */
  const downloadTicket = async (bookingId) => {
    try {
      // Get authentication token
      const token = localStorage.getItem('token');

      if (!token) {
        console.error('No auth token found for ticket download');
        return;
      }

      // Build API URL
      const baseUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
      const apiUrl = `${baseUrl}/bookings/${bookingId}/ticket`;

      // Fetch the PDF with authentication
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      // Check if request was successful
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to download ticket');
      }

      // Get the PDF blob
      const blob = await response.blob();

      // Create a download link and trigger download
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Jabo_Ticket_${bookingId}.pdf`;
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      // Show success message
      toast.success('Ticket downloaded successfully!');
    } catch (error) {
      console.error('Auto-download ticket failed:', error);
      // Don't show error toast to user since booking is successful
      // The user can still download from booking details page
    }
  };

  const handlePaymentSuccess = async (paymentData) => {
    setSubmitting(true);
    try {
      // Create booking payload
      const bookingPayload = {
        busId: bus._id,
        journeyDate,
        seats: selectedSeats,
        contactInfo,
        payment: { method: paymentMethod },
      };

      // Create the booking
      const bookingResponse = await createBooking(bookingPayload);

      if (!bookingResponse.success) {
        throw new Error('Unable to create booking');
      }

      const createdBooking = bookingResponse.data;
      setBookingResult(createdBooking);

      // Process payment
      const paymentResponse = await processFakePayment({
        paymentType: 'Booking',
        relatedId: createdBooking._id,
        method: paymentMethod,
        amount: {
          subtotal: totalFare,
          total: totalFare,
        },
        description: `Bus booking for ${contactInfo.fullName}`,
      });

      if (paymentResponse.success) {
        setPaymentReceipt(paymentResponse.data);

        // ✅ AUTO-DOWNLOAD TICKET IMMEDIATELY AFTER SUCCESSFUL PAYMENT
        await downloadTicket(createdBooking._id);

        // Show shuttle prompt
        setShowShuttlePrompt(true);

        // Show success message
        toast.success('Booking & payment successful!');
      }
    } catch (err) {
      const message =
        err.response?.data?.message || err.message || 'Failed to place booking. Please try again.';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleLoginSuccess = (data) => {
    // User logged in successfully
    setShowLoginModal(false);
    // If payment was pending, proceed to payment modal
    if (pendingPayment) {
      setPendingPayment(false);
      // Small delay to let login modal close smoothly
      setTimeout(() => {
        setShowPaymentModal(true);
      }, 300);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-gray-500 font-medium">Loading booking details...</p>
      </div>
    );
  }

  // Don't return null, show login modal instead

  if (error) {
    return (
      <div className="max-w-3xl mx-auto py-16 px-4 text-center">
        <div className="bg-red-50 rounded-2xl p-8 border border-red-100 mb-6">
          <p className="text-red-600 font-medium text-lg mb-2">Something went wrong</p>
          <p className="text-red-500 mb-6">{error}</p>
          <button
            onClick={() => navigate('/search')}
            className="px-6 py-3 rounded-xl bg-red-600 text-white font-semibold hover:bg-red-700 transition"
          >
            Back to search
          </button>
        </div>
      </div>
    );
  }

  const handleShuttleAction = (action) => {
    setShowShuttlePrompt(false);
    if (action === 'book' && bookingResult) {
      navigate(`/shuttle-booking?bookingId=${bookingResult._id}`, {
        state: { booking: bookingResult },
      });
    } else if (bookingResult) {
      navigate('/dashboard', {
        state: { message: 'Booking confirmed', bookingId: bookingResult._id },
      });
    } else {
      navigate('/');
    }
  };

  return (
    <>
      <div className="bg-gray-50 min-h-screen py-8 md:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">

            {/* Journey Header */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50/50 rounded-full translate-x-1/3 -translate-y-1/3"></div>
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 bg-blue-50 text-blue-600 text-xs font-bold uppercase rounded-full tracking-wider">
                      {bus.busType}
                    </span>
                    <span className="text-gray-400 text-xs font-medium">•</span>
                    <span className="text-gray-500 text-xs font-medium">Coach #{bus.coachNumber}</span>
                  </div>
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">{bus.busName}</h1>
                  <div className="flex items-center gap-2 text-gray-500 text-sm">
                    <MapPin className="h-4 w-4" />
                    {bus.route.origin}
                    <ArrowRight className="h-3 w-3" />
                    {bus.route.destination}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500 font-medium uppercase mb-1">Departure</p>
                  <p className="text-2xl font-bold text-gray-900 flex items-center justify-end gap-2">
                    <Clock className="h-5 w-5 text-blue-600" />
                    {bus.schedule.departureTime}
                  </p>
                  <p className="text-sm text-gray-500">
                    {new Date(journeyDate).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                  </p>
                </div>
              </div>
            </div>

            {/* Seat Selection */}
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                Select Your Seats
              </h2>

              <div className="flex justify-center mb-8">
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-md border border-gray-200 bg-white"></div>
                    <span className="text-gray-600">Available</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-md border border-gray-200 bg-gray-100 opacity-50"></div>
                    <span className="text-gray-400">Booked</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-md border border-blue-600 bg-blue-600"></div>
                    <span className="text-gray-900 font-medium">Selected</span>
                  </div>
                </div>
              </div>

              <div className="max-w-md mx-auto bg-gray-50 p-6 rounded-2xl border border-gray-200">
                <div className="w-full h-8 border-b-2 border-gray-200 mb-8 flex items-end justify-center pb-1">
                  <span className="text-xs text-gray-400 uppercase tracking-widest font-semibold">Driver's Side</span>
                </div>

                <div
                  className="grid gap-3"
                  style={{ gridTemplateColumns: `repeat(${seatColumns}, minmax(0, 1fr))` }}
                >
                  {seatMap.map((seat) => {
                    const bookedSeats = bus.bookedSeatsForDate || bus.seats?.bookedSeats || [];
                    const isBooked = bookedSeats.includes(seat);
                    const isSelected = selectedSeats.includes(seat);

                    return (
                      <button
                        type="button"
                        key={seat}
                        onClick={() => toggleSeat(seat)}
                        disabled={isBooked}
                        className={`
                          relative h-12 rounded-lg text-sm font-bold transition-all duration-200
                          ${isBooked
                            ? 'bg-gray-200 text-gray-300 cursor-not-allowed border border-transparent'
                            : isSelected
                              ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 border border-blue-600 transform scale-105'
                              : 'bg-white text-gray-700 border border-gray-200 hover:border-blue-400 hover:shadow-sm'
                          }
                        `}
                      >
                        {seat}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Passenger Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all"
                      placeholder="Enter passenger name"
                      value={contactInfo.fullName}
                      onChange={(e) => setContactInfo({ ...contactInfo, fullName: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all"
                      placeholder="name@example.com"
                      value={contactInfo.email}
                      onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
                    <input
                      type="tel"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-500 transition-all"
                      placeholder="01XXXXXXXXX"
                      value={contactInfo.phone}
                      onChange={(e) => setContactInfo({ ...contactInfo, phone: e.target.value })}
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-blue-600" /> Payment Method
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  {paymentOptions.map((option) => (
                    <label
                      key={option.value}
                      className={`
                      relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-200
                      ${paymentMethod === option.value
                          ? 'border-blue-600 bg-blue-50/50'
                          : 'border-gray-100 hover:border-blue-100 bg-white'
                        }
                    `}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`mt-1 h-5 w-5 rounded-full border flex items-center justify-center
                          ${paymentMethod === option.value ? 'border-blue-600' : 'border-gray-300'}
                       `}>
                          {paymentMethod === option.value && <div className="h-2.5 w-2.5 rounded-full bg-blue-600"></div>}
                        </div>
                        <input
                          type="radio"
                          name="paymentMethod"
                          value={option.value}
                          checked={paymentMethod === option.value}
                          onChange={(e) => setPaymentMethod(e.target.value)}
                          className="hidden"
                        />
                        <div>
                          <p className={`font-bold ${paymentMethod === option.value ? 'text-blue-900' : 'text-gray-900'}`}>
                            {option.label}
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">{option.description}</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>

                {paymentReceipt ? (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-3 text-green-700">
                    <CheckCircle2 className="h-5 w-5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-sm">Payment Confirmed</p>
                      <p className="text-xs opacity-80">Transaction ID: {paymentReceipt.gateway.transactionId}</p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-start gap-3">
                    <div className="mt-0.5 w-2 h-2 rounded-full bg-blue-400 flex-shrink-0"></div>
                    <p className="text-xs text-blue-800 leading-relaxed">
                      This is a demo secure payment environment. Select your preferred method to simulate an instant transaction. No actual money will be deducted.
                    </p>
                  </div>
                )}
              </div>
            </form>
          </div>

          <aside className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Booking Summary</h3>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">Seat Price</span>
                  <span className="font-semibold text-gray-900">{bus.fare.currency} {bus.fare.baseFare}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">Selected Seats</span>
                  <span className="font-semibold text-gray-900">{selectedSeats.length || '-'}</span>
                </div>
                {selectedSeats.length > 0 && (
                  <div className="flex flex-wrap gap-2 justify-end">
                    {selectedSeats.map(seat => (
                      <span key={seat} className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md border border-blue-100">
                        {seat}
                      </span>
                    ))}
                  </div>
                )}
                <div className="pt-4 border-t border-dashed border-gray-200 flex justify-between items-end">
                  <span className="text-gray-500 font-medium">Total Payable</span>
                  <span className="text-3xl font-bold text-blue-600">{bus.fare.currency} {totalFare}</span>
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="w-full bg-gray-900 text-white font-bold py-4 rounded-xl hover:bg-blue-600 transition-all shadow-lg hover:shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Confirm & Pay</span>
                  </>
                )}
              </button>
              <p className="text-xs text-center text-gray-400 mt-4">
                By clicking confirm, you agree to our Terms & Conditions
              </p>
            </div>
          </aside>
        </div>
      </div>

      <ShuttlePromptModal
        open={showShuttlePrompt}
        onBook={() => handleShuttleAction('book')}
        onSkip={() => handleShuttleAction('skip')}
      />
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => {
          setShowLoginModal(false);
          setPendingPayment(false);
        }}
        onSuccess={handleLoginSuccess}
      />
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSuccess={() => {
          setShowLoginModal(false);
          if (pendingPayment) {
            setShowPaymentModal(true);
            setPendingPayment(false);
          }
        }}
      />

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onSuccess={handlePaymentSuccess}
        amount={totalFare}
        currency={bus?.fare?.currency || 'BDT'}
        paymentMethod={paymentMethod}
      />
    </>
  );
};

export default Booking;

const ShuttlePromptModal = ({ open, onBook, onSkip }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
        <div className="text-center space-y-2">
          <h3 className="text-2xl font-bold text-gray-800">Need a shuttle ride?</h3>
          <p className="text-sm text-gray-500">
            We can arrange a last-mile shuttle to or from the bus station. Recommended for a hassle-free trip.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <button
            onClick={onBook}
            className="w-full bg-blue-600 text-white font-semibold py-3 rounded-2xl hover:bg-blue-700 transition"
          >
            Yes, book a shuttle
          </button>
          <button
            onClick={onSkip}
            className="w-full border border-gray-200 text-gray-600 font-semibold py-3 rounded-2xl hover:bg-gray-50 transition"
          >
            Not now
          </button>
        </div>
      </div>
    </div>
  );
};
