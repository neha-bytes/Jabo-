import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {
  MapPin,
  Navigation,
  Clock,
  Car,
  Phone,
  User,
  X,
  CheckCircle2,
  Loader2,
  MessageCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { fetchShuttleById } from '../services/shuttleService';
import Skeleton from '../components/common/Skeleton';

const STATUS_CONFIG = {
  pending: {
    label: 'Searching for driver...',
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    icon: Loader2,
    phase: 1,
  },
  accepted: {
    label: 'Driver accepted',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    icon: CheckCircle2,
    phase: 2,
  },
  on_the_way: {
    label: 'Driver is on the way',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    icon: Navigation,
    phase: 2,
  },
  arrived: {
    label: 'Driver arrived',
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    icon: MapPin,
    phase: 2,
  },
  started: {
    label: 'Ride in progress',
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    icon: Car,
    phase: 3,
  },
  completed: {
    label: 'Ride completed',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    icon: CheckCircle2,
    phase: 3,
  },
  cancelled: {
    label: 'Cancelled',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    icon: X,
    phase: 0,
  },
};

const ShuttleStatus = () => {
  const { requestId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { socket } = useSocket();
  const [shuttle, setShuttle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    const loadShuttle = async () => {
      try {
        setLoading(true);
        const response = await fetchShuttleById(requestId);
        if (response && response.success && response.data) {
          setShuttle(response.data);
        } else {
          const errorMsg = response?.message || 'Shuttle request not found';
          toast.error(errorMsg);
          setTimeout(() => navigate('/dashboard'), 1000);
        }
      } catch (error) {
        console.error('Error loading shuttle:', error);
        const errorMsg = error.response?.data?.message || 
                        error.message || 
                        'Failed to load shuttle request';
        toast.error(errorMsg);
        setTimeout(() => navigate('/dashboard'), 1000);
      } finally {
        setLoading(false);
      }
    };

    if (requestId) {
      loadShuttle();
    } else {
      toast.error('Invalid shuttle request ID');
      navigate('/dashboard');
    }
  }, [requestId, navigate]);

  // Join shuttle room for real-time updates
  useEffect(() => {
    if (!socket || !requestId) return;

    socket.emit('shuttle:join', requestId);

    let hasShownAssignedToast = false;

    const handleShuttleAssigned = ({ shuttleId, driver }) => {
      if (shuttleId === requestId && !hasShownAssignedToast) {
        hasShownAssignedToast = true;
        toast.success('Driver accepted your request!');
        refreshShuttle();
      }
    };

    const handleRideStatusChanged = ({ shuttleId, status }) => {
      if (shuttleId === requestId) {
        refreshShuttle();
      }
    };

    socket.on('shuttle-assigned', handleShuttleAssigned);
    socket.on('ride-status-changed', handleRideStatusChanged);

    return () => {
      socket.emit('shuttle:leave', requestId);
      socket.off('shuttle-assigned', handleShuttleAssigned);
      socket.off('ride-status-changed', handleRideStatusChanged);
    };
  }, [socket, requestId]);

  const refreshShuttle = async () => {
    try {
      const response = await fetchShuttleById(requestId);
      if (response.success) {
        setShuttle(response.data);
      }
    } catch (error) {
      console.error('Error refreshing shuttle:', error);
    }
  };

  const handleCancel = async () => {
    if (!window.confirm('Are you sure you want to cancel this shuttle request?')) {
      return;
    }

    try {
      setCancelling(true);
      const { cancelShuttleRequest } = await import('../services/shuttleService');
      await cancelShuttleRequest(requestId, 'Cancelled by user');
      toast.success('Shuttle request cancelled');
      navigate('/dashboard');
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to cancel request';
      toast.error(message);
    } finally {
      setCancelling(false);
    }
  };

  const handleViewLiveTrack = () => {
    navigate('/dashboard', { state: { activeShuttleId: requestId, activeNav: 'live' } });
  };

  const handleMessageDriver = () => {
    navigate('/dashboard', { state: { activeShuttleId: requestId, activeNav: 'chat' } });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="max-w-md w-full mx-4">
          <Skeleton className="h-64 w-full rounded-2xl mb-4" />
          <Skeleton className="h-32 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!shuttle) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Shuttle request not found</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const statusInfo = STATUS_CONFIG[shuttle.status] || STATUS_CONFIG.pending;
  const StatusIcon = statusInfo.icon;
  const isPhase1 = statusInfo.phase === 1;
  const isPhase2 = statusInfo.phase === 2;
  const isPhase3 = statusInfo.phase === 3;
  const canCancel = ['pending', 'accepted'].includes(shuttle.status);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-gray-600 hover:text-gray-800 mb-4 inline-flex items-center gap-2"
          >
            <X className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Shuttle Request</h1>
          <p className="text-gray-600 mt-1">Reference: {shuttle.shuttleReference}</p>
        </div>

        {/* Status Card */}
        <div className={`rounded-2xl p-6 mb-6 ${statusInfo.bgColor} border-2 border-current ${statusInfo.color.replace('text-', 'border-')}`}>
          <div className="flex items-center gap-4">
            {isPhase1 ? (
              <div className="relative">
                <Loader2 className="h-12 w-12 animate-spin" />
                <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-current opacity-20"></div>
              </div>
            ) : (
              <StatusIcon className="h-12 w-12" />
            )}
            <div className="flex-1">
              <p className="text-sm font-semibold uppercase tracking-wide opacity-75">Status</p>
              <p className="text-2xl font-bold">{statusInfo.label}</p>
            </div>
          </div>
        </div>

        {/* Phase 1: Searching for Driver */}
        {isPhase1 && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-amber-100 mb-4">
                  <Loader2 className="h-12 w-12 text-amber-600 animate-spin" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Finding a driver...</h2>
                <p className="text-gray-600">We're searching for nearby drivers to accept your request</p>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <MapPin className="h-5 w-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Pickup</p>
                    <p className="font-semibold text-gray-900">{shuttle.pickup?.address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <Navigation className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Drop-off</p>
                    <p className="font-semibold text-gray-900">{shuttle.dropoff?.address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <Car className="h-5 w-5 text-purple-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Vehicle Type</p>
                    <p className="font-semibold text-gray-900">{shuttle.vehicleType}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <Clock className="h-5 w-5 text-indigo-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Scheduled Time</p>
                    <p className="font-semibold text-gray-900">
                      {new Date(shuttle.scheduledTime).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
                  <div className="flex-1">
                    <p className="text-sm text-blue-600 font-semibold">Estimated Fare</p>
                    <p className="text-2xl font-bold text-blue-900">BDT {shuttle.fare?.total || 0}</p>
                  </div>
                </div>
              </div>

              {canCancel && (
                <button
                  onClick={handleCancel}
                  disabled={cancelling}
                  className="w-full py-3 px-6 rounded-xl border-2 border-red-200 text-red-600 font-semibold hover:bg-red-50 transition-colors disabled:opacity-50"
                >
                  {cancelling ? 'Cancelling...' : 'Cancel Request'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Phase 2: Driver Accepted */}
        {isPhase2 && shuttle.driver && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-green-100 mb-4">
                  <CheckCircle2 className="h-12 w-12 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Driver Found!</h2>
                <p className="text-gray-600">Your driver is on the way</p>
              </div>

              {/* Driver Info Card */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 mb-6 border-2 border-blue-200">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center text-white text-2xl font-bold">
                    {shuttle.driver?.user?.name?.charAt(0)?.toUpperCase() || 'D'}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900">
                      {shuttle.driver?.user?.name || 'Driver'}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {shuttle.vehicleType} • {shuttle.driver?.vehicleModel || 'Vehicle'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="text-xs text-gray-500">Phone</p>
                      <p className="font-semibold text-gray-900">
                        {shuttle.driver?.user?.phone || 'Not available'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                    <Car className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="text-xs text-gray-500">Vehicle</p>
                      <p className="font-semibold text-gray-900">
                        {shuttle.driver?.vehicleRegistrationNumber || 'N/A'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Route Info */}
              <div className="space-y-4 mb-6">
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <MapPin className="h-5 w-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Pickup</p>
                    <p className="font-semibold text-gray-900">{shuttle.pickup?.address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <Navigation className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Drop-off</p>
                    <p className="font-semibold text-gray-900">{shuttle.dropoff?.address}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleViewLiveTrack}
                  className="w-full py-3 px-6 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Navigation className="h-5 w-5" />
                  View Live Track
                </button>
                <button
                  onClick={handleMessageDriver}
                  className="w-full py-3 px-6 rounded-xl border-2 border-gray-200 text-gray-700 font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  Message Driver
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Phase 3: Ride in Progress */}
        {isPhase3 && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-indigo-100 mb-4">
                  <Car className="h-12 w-12 text-indigo-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{statusInfo.label}</h2>
              </div>

              {shuttle.driver && (
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 mb-6 border-2 border-indigo-200">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full bg-indigo-600 flex items-center justify-center text-white text-2xl font-bold">
                      {shuttle.driver?.user?.name?.charAt(0)?.toUpperCase() || 'D'}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900">
                        {shuttle.driver?.user?.name || 'Driver'}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {shuttle.vehicleType} • {shuttle.driver?.vehicleModel || 'Vehicle'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3">
                <button
                  onClick={handleViewLiveTrack}
                  className="w-full py-3 px-6 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Navigation className="h-5 w-5" />
                  View Live Track
                </button>
                <button
                  onClick={handleMessageDriver}
                  className="w-full py-3 px-6 rounded-xl border-2 border-gray-200 text-gray-700 font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  Message Driver
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ShuttleStatus;

