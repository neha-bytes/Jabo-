import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from 'use-debounce';
import { getRouteSuggestions } from '../services/busService';
import { Search, MapPin, Calendar, Shield, Headphones, CreditCard, TrendingUp, Star, ChevronRight, Clock, ArrowRight, Sparkles, Bus } from 'lucide-react';

const Home = () => {
  const [searchData, setSearchData] = useState({
    origin: '',
    destination: '',
    date: '',
  });
  const navigate = useNavigate();

  const [suggestions, setSuggestions] = useState([]);
  const [activeSuggestionBox, setActiveSuggestionBox] = useState(null); // 'origin' or 'destination'



  useEffect(() => {
    const fetchSuggestions = async (term, field) => {
      if (term.length > 1) {
        try {
          const response = await getRouteSuggestions(term);
          if (response.success) {
            setSuggestions(response.data);
            setActiveSuggestionBox(field);
          }
        } catch (error) {
          console.error("Failed to fetch suggestions:", error);
          setSuggestions([]);
        }
      } else {
        setSuggestions([]);
        setActiveSuggestionBox(null);
      }
    };

    if (activeSuggestionBox === 'origin') {
      fetchSuggestions(searchData.origin, 'origin');
    } else if (activeSuggestionBox === 'destination') {
      fetchSuggestions(searchData.destination, 'destination');
    }

  }, [searchData.origin, searchData.destination, activeSuggestionBox]);
  const handleSuggestionClick = (field, value) => {
    setSearchData({ ...searchData, [field]: value });
    setSuggestions([]);
    setActiveSuggestionBox(null);
  };


  const handleSearch = (e) => {
    e.preventDefault();
    if (searchData.origin && searchData.destination && searchData.date) {
      const queryParams = new URLSearchParams(searchData).toString();
      navigate(`/search?${queryParams}`);
    }
  };

  const features = [
    {
      icon: Shield,
      title: 'Safe & Secure',
      description: 'Verified buses and drivers with real-time tracking for your peace of mind',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: CreditCard,
      title: 'Easy Payment',
      description: 'Multiple payment methods including bKash, Nagad, and cards',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Headphones,
      title: '24/7 Support',
      description: 'Always here to help with dedicated customer service team',
      color: 'from-green-500 to-green-600'
    },
  ];

  const popularRoutes = [
    { from: 'Dhaka', to: 'Chittagong', price: '৳800', duration: '5-6 hrs', rating: 4.8 },
    { from: 'Dhaka', to: 'Sylhet', price: '৳750', duration: '6-7 hrs', rating: 4.7 },
    { from: 'Dhaka', to: "Cox's Bazar", price: '৳1200', duration: '8-9 hrs', rating: 4.9 },
    { from: 'Dhaka', to: 'Rangpur', price: '৳650', duration: '7-8 hrs', rating: 4.6 },
  ];

  const testimonials = [
    { name: 'Rahul Ahmed', text: 'Best bus booking experience! Very smooth and reliable.', rating: 5 },
    { name: 'Fatima Khan', text: 'Great service and comfortable buses. Highly recommended!', rating: 5 },
    { name: 'Karim Hassan', text: 'Easy to use and excellent customer support.', rating: 4 },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex items-center justify-center bg-[#020617] text-white overflow-hidden pt-20">

        {/* Advanced Animated Background */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          {/* Deep Space Gradient */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1e1b4b] via-[#020617] to-[#020617]"></div>

          {/* Animated Stars/Particles (CSS driven) */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-10 left-10 w-1 h-1 bg-white rounded-full animate-pulse duration-[3000ms]"></div>
            <div className="absolute top-1/4 right-1/4 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse duration-[5000ms]"></div>
            <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-white rounded-full animate-pulse duration-[4000ms]"></div>
            <div className="absolute top-1/2 right-10 w-2 h-2 bg-indigo-500 rounded-full animate-pulse duration-[6000ms] blur-[1px]"></div>
            <div className="absolute bottom-10 left-1/4 w-1 h-1 bg-white rounded-full animate-pulse duration-[3500ms]"></div>
          </div>

          {/* Floating Ethereal Orbs */}
          <div className="absolute top-0 left-0 w-[800px] h-[800px] bg-blue-600/10 rounded-full mix-blend-screen filter blur-[120px] animate-[pulse_8s_infinite]"></div>
          <div className="absolute bottom-0 right-0 w-[800px] h-[800px] bg-violet-600/10 rounded-full mix-blend-screen filter blur-[120px] animate-[pulse_10s_infinite] delay-1000"></div>
        </div>

        <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10 flex flex-col items-center">

          {/* Content Entrance Animation */}
          <div className="w-full flex flex-col items-center animate-in slide-in-from-bottom-10 fade-in duration-1000">

            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/5 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 shadow-2xl mb-8 hover:bg-white/10 transition-colors cursor-default">
              <Sparkles className="h-4 w-4 text-amber-400 fill-amber-400 animate-spin-slow" />
              <span className="text-sm font-semibold text-blue-100 tracking-wide">The Premium Booking Experience</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-center mb-8 leading-[1.1] tracking-tight">
              <span className="block text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                Explore Bangladesh
              </span>
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-indigo-400 drop-shadow-sm animate-gradient-x">
                Without Limits.
              </span>
            </h1>

            <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto text-center font-medium leading-relaxed mb-16">
              Secure tickets, premium operators, and real-time tracking. <br className="hidden md:block" />
              Your journey begins with a single click.
            </p>

            {/* Dark Glass Search Bar (Restored & Fixed) */}
            <div className="w-full max-w-5xl relative z-50">
              <div className="bg-slate-900/40 backdrop-blur-2xl rounded-[2.5rem] p-3 border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] ring-1 ring-white/5 relative group transition-all duration-500 hover:border-white/20 hover:shadow-[0_0_70px_rgba(37,99,235,0.15)]">

                {/* Glow effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-transparent to-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none rounded-[2.5rem]"></div>

                <div className="bg-[#0f172a]/60 rounded-[2rem] p-6 sm:p-8 backdrop-blur-xl relative z-10">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5">

                    {/* From Input */}
                    <div className="md:col-span-4 relative group/input">
                      <div className="absolute left-5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 group-focus-within/input:bg-blue-500 group-focus-within/input:text-white transition-all duration-300">
                        <MapPin className="h-5 w-5" />
                      </div>
                      <label className="absolute left-[4.5rem] top-3 text-xs font-bold text-slate-400 uppercase tracking-wider pointer-events-none group-focus-within/input:text-blue-400 transition-colors">From</label>
                      <input
                        type="text"
                        value={searchData.origin}
                        onChange={(e) => {
                          setSearchData({ ...searchData, origin: e.target.value });
                          setActiveSuggestionBox('origin');
                        }}
                        className="w-full h-[4.5rem] pl-[4.5rem] pr-6 bg-slate-900/60 border border-white/5 rounded-2xl focus:outline-none focus:bg-slate-900 text-white font-bold text-lg placeholder-slate-600 transition-all focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 pt-5"
                        placeholder="Dhaka"
                      />
                      {activeSuggestionBox === 'origin' && suggestions.length > 0 && (
                        <ul className="absolute z-[100] w-full mt-2 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl max-h-60 overflow-auto overflow-x-hidden p-2 animate-in fade-in zoom-in-95 duration-200">
                          {suggestions.map((suggestion, index) => (
                            <li
                              key={index}
                              onClick={() => handleSuggestionClick('origin', suggestion)}
                              className="px-4 py-3 cursor-pointer hover:bg-white/5 rounded-xl transition-colors text-slate-200 font-medium flex items-center gap-3 group/item"
                            >
                              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 group-hover/item:text-white transition-colors"><MapPin size={14} /></div>
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    {/* To Input */}
                    <div className="md:col-span-4 relative group/input">
                      <div className="absolute left-5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 group-focus-within/input:bg-violet-500 group-focus-within/input:text-white transition-all duration-300">
                        <MapPin className="h-5 w-5" />
                      </div>
                      <label className="absolute left-[4.5rem] top-3 text-xs font-bold text-slate-400 uppercase tracking-wider pointer-events-none group-focus-within/input:text-violet-400 transition-colors">To</label>
                      <input
                        type="text"
                        value={searchData.destination}
                        onChange={(e) => {
                          setSearchData({ ...searchData, destination: e.target.value });
                          setActiveSuggestionBox('destination');
                        }}
                        className="w-full h-[4.5rem] pl-[4.5rem] pr-6 bg-slate-900/60 border border-white/5 rounded-2xl focus:outline-none focus:bg-slate-900 text-white font-bold text-lg placeholder-slate-600 transition-all focus:border-violet-500/50 focus:ring-4 focus:ring-violet-500/10 pt-5"
                        placeholder="Chittagong"
                      />
                      {activeSuggestionBox === 'destination' && suggestions.length > 0 && (
                        <ul className="absolute z-[100] w-full mt-2 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl max-h-60 overflow-auto overflow-x-hidden p-2 animate-in fade-in zoom-in-95 duration-200">
                          {suggestions.map((suggestion, index) => (
                            <li
                              key={index}
                              onClick={() => handleSuggestionClick('destination', suggestion)}
                              className="px-4 py-3 cursor-pointer hover:bg-white/5 rounded-xl transition-colors text-slate-200 font-medium flex items-center gap-3 group/item"
                            >
                              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 group-hover/item:text-white transition-colors"><MapPin size={14} /></div>
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    {/* Date Input */}
                    <div className="md:col-span-3 relative group/input">
                      <div className="absolute left-5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-focus-within/input:bg-emerald-500 group-focus-within/input:text-white transition-all duration-300">
                        <Calendar className="h-5 w-5" />
                      </div>
                      <label className="absolute left-[4.5rem] top-3 text-xs font-bold text-slate-400 uppercase tracking-wider pointer-events-none group-focus-within/input:text-emerald-400 transition-colors">Journey Date</label>
                      <input
                        type="date"
                        value={searchData.date}
                        onChange={(e) => setSearchData({ ...searchData, date: e.target.value })}
                        className="w-full h-[4.5rem] pl-[4.5rem] pr-6 bg-slate-900/60 border border-white/5 rounded-2xl focus:outline-none focus:bg-slate-900 text-white font-bold text-lg placeholder-slate-600 transition-all focus:border-emerald-500/50 focus:ring-4 focus:ring-emerald-500/10 pt-5 [color-scheme:dark]"
                        min={new Date().toISOString().split('T')[0]}
                      />
                    </div>

                    {/* Search Button */}
                    <div className="md:col-span-1">
                      <button
                        onClick={handleSearch}
                        className="w-full h-[4.5rem] bg-gradient-to-br from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white rounded-2xl shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] transition-all duration-300 flex items-center justify-center transform hover:scale-[1.02] active:scale-[0.98] group/btn"
                      >
                        <Search className="h-8 w-8 group-hover/btn:rotate-12 transition-transform" />
                      </button>
                    </div>

                  </div>
                </div>
              </div>

              {/* Quick Chips below search */}
              <div className="flex flex-wrap justify-center gap-3 mt-8">
                {['Dhaka to Cox\'s Bazar', 'Sylhet to Dhaka', 'Chittagong Express', 'Night Coach'].map((chip, i) => (
                  <button key={i} className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-slate-400 hover:bg-white/10 hover:text-white hover:border-white/20 transition-all">
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <div className="inline-block mb-4">
              <span className="inline-flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold border border-blue-100">
                <Star className="h-4 w-4 fill-current" />
                Why Choose JABO
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 tracking-tight">Travel with Confidence</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">Experience the best in online bus booking with our premium services designed for your comfort.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group relative bg-white rounded-[2rem] p-10 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-gray-100 overflow-hidden"
              >
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${feature.color} opacity-10 rounded-bl-full -mr-10 -mt-10 group-hover:scale-150 transition-transform duration-700 ease-out`}></div>

                <div className="relative z-10">
                  <div className={`w-20 h-20 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-10 shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-500`}>
                    <feature.icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-900 group-hover:text-blue-600 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-gray-500 leading-relaxed text-lg">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Routes */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
            <div>
              <div className="inline-block mb-4">
                <span className="inline-flex items-center gap-2 bg-green-50 text-green-700 px-4 py-2 rounded-full text-sm font-semibold border border-green-100">
                  <TrendingUp className="h-4 w-4" />
                  Trending Routes
                </span>
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-2 tracking-tight">Popular Destinations</h2>
              <p className="text-lg text-gray-500">Most traveled routes this month</p>
            </div>

            <button className="hidden md:flex items-center gap-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors group">
              View all routes
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularRoutes.map((route, index) => (
              <div
                key={index}
                onClick={() => setSearchData({ origin: route.from, destination: route.to, date: '' })}
                className="group bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer border border-gray-100 hover:border-blue-200 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Bus className="h-24 w-24 text-blue-600 transform -rotate-12 translate-x-8 -translate-y-8" />
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-6">
                    <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-full">BUS</span>
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="text-sm font-bold">{route.rating}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 mb-6">
                    <div className="text-lg font-bold text-gray-900">{route.from}</div>
                    <div className="flex-1 flex flex-col items-center">
                      <div className="w-full border-t border-dashed border-gray-300 relative top-1/2"></div>
                      <Bus className="h-4 w-4 text-gray-400 bg-white px-1 z-10" />
                    </div>
                    <div className="text-lg font-bold text-gray-900">{route.to}</div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Starting from</p>
                      <p className="text-2xl font-bold text-blue-600">{route.price}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500 mb-1">Duration</p>
                      <div className="flex items-center gap-1 justify-end">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <p className="text-sm font-semibold text-gray-700">{route.duration}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-[#0F172A] relative overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-blue-900/20 rounded-full blur-[100px]"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-block mb-4">
              <span className="inline-flex items-center gap-2 bg-white/10 text-blue-300 px-4 py-2 rounded-full text-sm font-medium border border-white/10">
                <Shield className="h-4 w-4" />
                Trusted Review
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Loved by Travelers</h2>
            <p className="text-gray-400 text-lg">See what our customers have to say about their journey</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-lg rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-colors duration-300"
              >
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < testimonial.rating ? 'text-yellow-500 fill-current' : 'text-gray-600'}`}
                    />
                  ))}
                </div>
                <p className="text-gray-300 mb-8 text-lg leading-relaxed italic">"{testimonial.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-white">{testimonial.name}</p>
                    <p className="text-sm text-blue-400">Verified Traveler</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 bg-blue-600 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
          <div className="absolute -left-10 -bottom-10 w-64 h-64 bg-white/20 rounded-full blur-3xl"></div>
          <div className="absolute -right-10 -top-10 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-10 font-medium max-w-2xl mx-auto">
            Book your tickets now and enjoy a seamless travel experience with JABO.
          </p>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="inline-flex items-center gap-3 bg-white text-blue-600 font-bold py-4 px-10 rounded-xl hover:bg-gray-50 transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
          >
            <span>Get Started</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </section>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.5; }
        }
        .animate-pulse {
          animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .delay-1000 {
          animation-delay: 1s;
        }
        .delay-2000 {
          animation-delay: 2s;
        }
        .bg-size-200 {
          background-size: 200%;
        }
        .bg-pos-100 {
          background-position: 100%;
        }
      `}</style>
    </div>
  );
};

export default Home;
