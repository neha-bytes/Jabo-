import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {
  ArrowLeft,
  Bus,
  MapPin,
  Calendar,
  Users,
  CreditCard,
  Car,
  CheckCircle2,
  Clock,
  X,
  Navigation,
  Lock,
  Download
} from 'lucide-react';
import { getBookingById } from '../services/bookingService';
import { fetchShuttleById } from '../services/shuttleService';
import Skeleton from '../components/common/Skeleton';

// Helper function to parse 12-hour time format
const parseTime12Hour = (timeStr) => {
  if (!timeStr) return null;
  const trimmed = timeStr.trim().toUpperCase();
  const match = trimmed.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/);
  if (!match) {
    const parts = trimmed.split(':');
    if (parts.length >= 2) {
      const hours = parseInt(parts[0], 10);
      const minutes = parseInt(parts[1], 10);
      if (!isNaN(hours) && !isNaN(minutes)) {
        return { hours, minutes };
      }
    }
    return null;
  }
  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3];
  if (isNaN(hours) || isNaN(minutes)) return null;
  if (period === 'PM' && hours !== 12) {
    hours += 12;
  } else if (period === 'AM' && hours === 12) {
    hours = 0;
  }
  return { hours, minutes };
};

// Helper to check if bus has departed
const hasBusDeparted = (journeyDate, bus) => {
  if (!journeyDate || !bus?.schedule?.departureTime) return false;
  try {
    const date = new Date(journeyDate);
    const timeParts = parseTime12Hour(bus.schedule.departureTime);
    if (!timeParts) return false;
    date.setHours(timeParts.hours, timeParts.minutes, 0, 0);
    return new Date() > date;
  } catch (error) {
    return false;
  }
};

const BookingDetails = () => {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [shuttle, setShuttle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloadingTicket, setDownloadingTicket] = useState(false);

  useEffect(() => {
    const loadBooking = async () => {
      try {
        setLoading(true);
        const response = await getBookingById(bookingId);
        if (response?.success && response.data) {
          setBooking(response.data);

          // Load shuttle if it exists
          if (response.data.shuttleService?.shuttleId) {
            try {
              const shuttleResponse = await fetchShuttleById(response.data.shuttleService.shuttleId);
              if (shuttleResponse?.success && shuttleResponse.data) {
                setShuttle(shuttleResponse.data);
              }
            } catch (err) {
              console.error('Error loading shuttle:', err);
            }
          }
        } else {
          toast.error('Booking not found');
          navigate('/dashboard');
        }
      } catch (error) {
        console.error('Error loading booking:', error);
        toast.error('Failed to load booking details');
        navigate('/dashboard');
      } finally {
        setLoading(false);
      }
    };

    if (bookingId) {
      loadBooking();
    }
  }, [bookingId, navigate]);

  // Function to download ticket with authentication
  const handleDownloadTicket = async () => {
    try {
      setDownloadingTicket(true);

      // Get token from localStorage
      const token = localStorage.getItem('token');

      if (!token) {
        toast.error('Please login to download ticket');
        navigate('/login');
        return;
      }

      // Build the API URL - VITE_API_URL already includes /api
      const baseUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
      const apiUrl = `${baseUrl}/bookings/${booking._id}/ticket`;

      console.log('Downloading from:', apiUrl); // Debug log

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to download ticket');
      }

      // Get the PDF blob
      const blob = await response.blob();

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Jabo_Ticket_${booking._id}.pdf`;
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success('Ticket downloaded successfully!');
    } catch (error) {
      console.error('Download error:', error);
      toast.error(error.message || 'Failed to download ticket');
    } finally {
      setDownloadingTicket(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getShuttleStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'accepted':
      case 'on_the_way':
      case 'arrived':
      case 'started':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-64 w-full rounded-2xl mb-4" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Booking not found</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const hasShuttle = booking.shuttleService?.requested;
  const shuttleIncomplete = hasShuttle && shuttle && !['completed', 'cancelled'].includes(shuttle.status);
  const busDeparted = hasBusDeparted(booking.journeyDate, booking.bus);
  const canBookShuttle = !hasShuttle && booking.status === 'confirmed' && !busDeparted;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-gray-600 hover:text-gray-800 mb-4 inline-flex items-center gap-2"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Booking Details</h1>
          <p className="text-gray-600 mt-1">Booking ID: {booking._id}</p>
        </div>

        {/* Bus Booking Information */}
        <div className="bg-white rounded-2xl shadow-md p-6 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
            <h2 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
              <Bus className="h-6 w-6 text-blue-600" />
              Bus Booking Information
            </h2>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              {/* Status Badge */}
              <span className={`px-4 py-2 rounded-full text-sm font-bold border ${getStatusColor(booking.status)}`}>
                {booking.status?.toUpperCase() || 'PENDING'}
              </span>

              {/* DOWNLOAD TICKET BUTTON - ONLY WHEN CONFIRMED */}
              {booking.status === 'confirmed' && (
                <button
                  onClick={handleDownloadTicket}
                  disabled={downloadingTicket}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <Download className="h-5 w-5" />
                  {downloadingTicket ? 'Downloading...' : 'Download Ticket (PDF)'}
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Bus Name</p>
                <p className="text-lg font-semibold text-gray-900">
                  {booking.bus?.busName || 'Pending assignment'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Route
                </p>
                <p className="text-lg font-semibold text-gray-900">
                  {booking.bus?.route?.origin || 'N/A'} → {booking.bus?.route?.destination || 'N/A'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1 flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Journey Date & Time
                </p>
                <p className="text-lg font-semibold text-gray-900">
                  {new Date(booking.journeyDate).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
                {booking.bus?.schedule?.departureTime ? (
                  <p className="text-lg font-semibold text-gray-900 mt-1">
                    {booking.bus.schedule.departureTime}
                  </p>
                ) : (
                  <p className="text-sm text-gray-500 mt-1">Time not available</p>
                )}
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-1 flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Seats
                </p>
                <p className="text-lg font-semibold text-gray-900">
                  {booking.seats?.join(', ') || 'N/A'}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {booking.seats?.length || 0} seat{booking.seats?.length !== 1 ? 's' : ''}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1 flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  Payment
                </p>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold border ${getPaymentStatusColor(booking.payment?.status)}`}>
                    {booking.payment?.status?.toUpperCase() || 'PENDING'}
                  </span>
                  <span className="text-sm text-gray-600">
                    ({booking.payment?.method || 'Cash'})
                  </span>
                </div>
                <p className="text-lg font-semibold text-gray-900 mt-2">
                  Total Fare: BDT {booking.totalFare || 0}
                </p>
                {booking.payment?.paidAt && (
                  <p className="text-sm text-gray-600 mt-1">
                    Paid on: {new Date(booking.payment.paidAt).toLocaleString()}
                  </p>
                )}
              </div>
              {booking.bus?.coachNumber && (
                <div>
                  <p className="text-sm text-gray-500 mb-1">Coach Number</p>
                  <p className="text-lg font-semibold text-gray-900">{booking.bus.coachNumber}</p>
                </div>
              )}
            </div>
          </div>

          {booking.contactInfo && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-500 mb-2">Contact Information</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-xs text-gray-400">Name</p>
                  <p className="font-semibold text-gray-900">{booking.contactInfo.fullName}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Email</p>
                  <p className="font-semibold text-gray-900">{booking.contactInfo.email}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Phone</p>
                  <p className="font-semibold text-gray-900">{booking.contactInfo.phone}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Shuttle Booking Status */}
        <div className="bg-white rounded-2xl shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
              <Car className="h-6 w-6 text-indigo-600" />
              Shuttle Booking Status
            </h2>
            {hasShuttle && shuttle && (
              <span className={`px-3 py-1 rounded-full text-sm font-semibold border ${getShuttleStatusColor(shuttle.status)}`}>
                {shuttle.status?.replace('_', ' ').toUpperCase() || 'PENDING'}
              </span>
            )}
          </div>

          {!hasShuttle ? (
            <div className="text-center py-8">
              <Car className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No shuttle booking for this trip</p>
              {busDeparted ? (
                <div className="flex items-center justify-center gap-2 text-amber-600">
                  <Lock className="h-5 w-5" />
                  <p className="font-semibold">Bus has departed - Shuttle booking is locked</p>
                </div>
              ) : canBookShuttle ? (
                <button
  onClick={() => navigate(`/shuttle-booking?bookingId=${booking._id}`)}
  className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
>
  Book Shuttle
</button>
              ) : null}
            </div>
          ) : shuttle ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm text-gray-500 mb-1">Pickup Location</p>
                  <p className="font-semibold text-gray-900">{shuttle.pickup?.address || 'N/A'}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm text-gray-500 mb-1">Drop-off Location</p>
                  <p className="font-semibold text-gray-900">{shuttle.dropoff?.address || 'N/A'}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm text-gray-500 mb-1">Vehicle Type</p>
                  <p className="font-semibold text-gray-900">{shuttle.vehicleType || 'N/A'}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm text-gray-500 mb-1">Scheduled Time</p>
                  <p className="font-semibold text-gray-900">
                    {new Date(shuttle.scheduledTime).toLocaleString()}
                  </p>
                </div>
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm text-gray-500 mb-1">Fare</p>
                  <p className="font-semibold text-gray-900">BDT {shuttle.fare?.total || 0}</p>
                </div>
              </div>
              {shuttle.driver && (
                <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
                  <p className="text-sm text-indigo-600 mb-2">Driver Information</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
                      {shuttle.driver?.user?.name?.charAt(0)?.toUpperCase() || 'D'}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        {shuttle.driver?.user?.name || 'Driver'}
                      </p>
                      <p className="text-sm text-gray-600">
                        {shuttle.driver?.user?.phone || 'N/A'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
              {shuttleIncomplete && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <button
                    onClick={() => navigate(`/shuttle/status/${shuttle._id}`)}
                    className="w-full px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Navigation className="h-5 w-5" />
                    View Shuttle Status
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Clock className="h-12 w-12 text-amber-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Shuttle booking is being processed</p>
              {canBookShuttle && (
                <button
                  onClick={() => navigate(`/shuttle-booking?bookingId=${booking._id}`, {
                    state: { booking }
                  })}
                  className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
                >
                  Complete Shuttle Booking
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingDetails;
