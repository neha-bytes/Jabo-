import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext(null);

const resolveSocketUrl = () => {
  const explicit = import.meta.env.VITE_SOCKET_URL;
  if (explicit) return explicit;
  const apiUrl = import.meta.env.VITE_API_URL;
  if (apiUrl) {
    try {
      const url = new URL(apiUrl);
      if (url.pathname.endsWith('/api')) {
        url.pathname = url.pathname.replace(/\/api$/, '');
      }
      return url.toString().replace(/\/$/, '');
    } catch {
      // swallow parsing issues and fall back
    }
  }
  return 'http://localhost:5000';
};

export const SocketProvider = ({ children }) => {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef(null);
  const url = useMemo(resolveSocketUrl, []);

  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token || !user) {
      if (socketRef.current) {
        console.log('🔌 Disconnecting socket - no token or user');
        socketRef.current.disconnect();
        socketRef.current = null;
        setIsConnected(false);
      }
      return;
    }

    // *** FIX: Log socket connection attempt ***
    console.log('🔌 Attempting socket connection:', {
      url,
      userId: user?.id,
      userRole: user?.role,
      hasToken: !!token
    });

    const socket = io(url, {
      transports: ['websocket'],
      auth: { token },
      autoConnect: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socketRef.current = socket;

    const handleConnect = () => {
      console.log('✅ Socket connected:', socket.id);
      setIsConnected(true);

      // *** FIX: Emit driver-online event immediately after connection ***
      if (user?.role === 'driver') {
        console.log('🚗 Emitting driver-online event for driver');
        socket.emit('driver-online');
      }
    };

    const handleDisconnect = (reason) => {
      console.log('❌ Socket disconnected:', reason);
      setIsConnected(false);
    };

    const handleConnectError = (error) => {
      console.error('❌ Socket connection error:', error.message);
    };

    socket.on('connect', handleConnect);
    socket.on('disconnect', handleDisconnect);
    socket.on('connect_error', handleConnectError);

    // *** FIX: Add error handler for debugging ***
    socket.on('error', (error) => {
      console.error('❌ Socket error:', error);
    });

    return () => {
      console.log('🔌 Cleaning up socket connection');
      socket.off('connect', handleConnect);
      socket.off('disconnect', handleDisconnect);
      socket.off('connect_error', handleConnectError);
      socket.off('error');
      socket.disconnect();
      socketRef.current = null;
      setIsConnected(false);
    };
  }, [user, url]);

  const value = useMemo(
    () => ({
      socket: socketRef.current,
      isConnected,
    }),
    [isConnected]
  );

  return <SocketContext.Provider value={value}>{children}</SocketContext.Provider>;
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within SocketProvider');
  }
  return context;
};
