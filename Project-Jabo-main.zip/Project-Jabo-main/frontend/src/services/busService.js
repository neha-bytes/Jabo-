import api from './api';

/**
 * Search for buses based on origin, destination, and date.
 * @param {object} params - The search parameters.
 * @param {string} params.origin - The origin city.
 * @param {string} params.destination - The destination city.
 * @param {string} params.date - The date of travel (YYYY-MM-DD).
 * @returns {Promise<object>} The search results.
 */
export const searchBuses = async (params) => {
  try {
    const response = await api.get('/buses/search', { params });
    return response.data;
  } catch (error) {
    console.error('Error searching buses:', error);
    throw error;
  }
};

/**
 * Get route suggestions for autocomplete.
 * @param {string} term - The search term.
 * @returns {Promise<Array<string>>} A list of suggestions.
 */
export const getRouteSuggestions = async (term) => {
  try {
    const response = await api.get('/buses/routes/suggestions', {
      params: { term },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching route suggestions:', error);
    throw error;
  }
};

export const getBusById = async (id, date = null) => {
  try {
    const params = date ? { date } : {};
    const response = await api.get(`/buses/${id}`, { params });
    return response.data;
  } catch (error) {
    console.error('Error fetching bus by id:', error);
    throw error;
  }
};

/**
 * Get all active buses.
 * @returns {Promise<object>} All active buses.
 */
export const getAllBuses = async () => {
  try {
    const response = await api.get('/buses');
    return response.data;
  } catch (error) {
    console.error('Error fetching all buses:', error);
    throw error;
  }
};


