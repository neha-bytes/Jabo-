import api from './api';

export const complaintService = {
  create: async (payload) => {
    const res = await api.post('/complaints', payload);
    return res.data.data;
  },
  getMine: async () => {
    const res = await api.get('/complaints/me');
    return res.data.data;
  },
};
