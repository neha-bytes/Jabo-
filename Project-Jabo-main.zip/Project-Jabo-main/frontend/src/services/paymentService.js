import api from './api';

export const processFakePayment = async ({
  paymentType,
  relatedId,
  method,
  amount,
  description,
}) => {
  try {
    const response = await api.post('/payments/fake', {
      paymentType,
      relatedId,
      method,
      amount,
      description,
    });
    return response.data;
  } catch (error) {
    console.error('Error processing payment:', error);
    throw error;
  }
};



