import api from './api';

export const createBooking = async (payload) => {
  try {
    const response = await api.post('/bookings', payload);
    return response.data;
  } catch (error) {
    console.error('Error creating booking:', error);
    throw error;
  }
};

export const getBookingById = async (id) => {
  try {
    const response = await api.get(`/bookings/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching booking:', error);
    throw error;
  }
};

export const getPublicBooking = async (id) => {
  try {
    const response = await api.get(`/bookings/public/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching public booking:', error);
    throw error;
  }
};

export const getMyBookings = async (params = {}) => {
  try {
    const response = await api.get('/bookings/my', { params });
    return response.data;
  } catch (error) {
    console.error('Error fetching user bookings:', error);
    throw error;
  }
};

