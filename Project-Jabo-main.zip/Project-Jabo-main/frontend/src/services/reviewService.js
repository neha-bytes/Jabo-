import api from './api';

export const createReview = async (payload) => {
  try {
    const response = await api.post('/reviews', payload);
    return response.data;
  } catch (error) {
    console.error('Error creating review:', error);
    throw error;
  }
};

export const getDriverReviews = async (driverId, params = {}) => {
  try {
    const response = await api.get(`/reviews/driver/${driverId}`, { params });
    return response.data;
  } catch (error) {
    console.error('Error fetching driver reviews:', error);
    throw error;
  }
};

export const getMyReviews = async () => {
  try {
    const response = await api.get('/reviews/my');
    return response.data;
  } catch (error) {
    console.error('Error fetching my reviews:', error);
    throw error;
  }
};

export const checkCanReview = async (shuttleId) => {
  try {
    const response = await api.get(`/reviews/check/${shuttleId}`);
    return response.data;
  } catch (error) {
    console.error('Error checking review eligibility:', error);
    throw error;
  }
};








