import api from './api';

export const getDriverProfile = async () => {
  const response = await api.get('/drivers/me');
  return response.data;
};



