import api from './api';

export const createShuttleRequest = async (payload) => {
  try {
    const response = await api.post('/shuttles', payload);
    return response.data;
  } catch (error) {
    console.error('Error creating shuttle request:', error);
    throw error;
  }
};

export const fetchUserShuttles = async (params = {}) => {
  const response = await api.get('/shuttles/my-rides', { params });
  return response.data;
};

export const fetchShuttleById = async (id) => {
  const response = await api.get(`/shuttles/${id}`);
  return response.data;
};

export const fetchShuttleMessages = async (id, params = {}) => {
  const response = await api.get(`/shuttles/${id}/messages`, { params });
  return response.data;
};

export const cancelShuttleRequest = async (id, reason) => {
  const response = await api.put(`/shuttles/${id}/cancel`, { reason });
  return response.data;
};

export const fetchDriverAvailableShuttles = async () => {
  const response = await api.get('/shuttles/driver/available');
  return response.data;
};

export const fetchDriverShuttles = async (params = {}) => {
  const response = await api.get('/shuttles/driver/my-rides', { params });
  return response.data;
};

export const acceptShuttleRequest = async (shuttleId) => {
  const response = await api.put(`/shuttles/${shuttleId}/accept`);
  return response.data;
};

export const updateShuttleStatus = async (shuttleId, status) => {
  const response = await api.put(`/shuttles/${shuttleId}/status`, { status });
  return response.data;
};

