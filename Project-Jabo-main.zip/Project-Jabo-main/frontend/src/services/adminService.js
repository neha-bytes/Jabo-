// frontend/src/services/adminService.js

import api from "./api";

export const adminService = {
  /* =========================
     USERS
     ========================= */
  getUsers: async () => {
    const res = await api.get("/admin/users");
    return res.data.data;
  },

  getUserById: async (id) => {
    const res = await api.get(`/admin/users/${id}`);
    return res.data.data;
  },

  updateUser: async (id, payload) => {
    const res = await api.put(`/admin/users/${id}`, payload);
    return res.data.data;
  },

  deleteUser: async (id) => {
    const res = await api.delete(`/admin/users/${id}`);
    return res.data;
  },

  /* =========================
     DRIVERS
     ========================= */
  getDrivers: async (query = "") => {
    const res = await api.get(`/admin/drivers${query ? `?${query}` : ""}`);
    return res.data.data;
  },

  approveDriver: async (id) => {
    const res = await api.put(`/admin/drivers/${id}/approve`);
    return res.data.data;
  },

  rejectDriver: async (id) => {
    const res = await api.delete(`/admin/drivers/${id}/reject`);
    return res.data;
  },

  /* =========================
     BUSES
     ========================= */
  getBuses: async () => {
    const res = await api.get("/admin/buses");
    return res.data.data;
  },

  getBusById: async (id) => {
    const res = await api.get(`/admin/buses/${id}`);
    return res.data.data;
  },

  updateBus: async (id, payload) => {
    const res = await api.put(`/admin/buses/${id}`, payload);
    return res.data.data;
  },

  createBus: async (busData) => {
    const response = await api.post("/admin/buses", busData);
    return response.data;
  },

  deleteBus: async (id) => {
    const res = await api.delete(`/admin/buses/${id}`);
    return res.data;
  },

  /* =========================
     BOOKINGS
     ========================= */
  getBookings: async () => {
    const res = await api.get("/admin/bookings");
    return res.data.data;
  },

  deleteBooking: async (id) => {
    const res = await api.delete(`/admin/bookings/${id}`);
    return res.data;
  },

  /* =========================
     REVIEWS
     ========================= */
  getReviews: async () => {
    const res = await api.get("/admin/reviews");
    return res.data.data;
  },

  deleteReview: async (id) => {
    const res = await api.delete(`/admin/reviews/${id}`);
    return res.data;
  },

  /* =========================
     COMPLAINTS
     ========================= */
  getComplaints: async () => {
    const res = await api.get("/admin/complaints");
    return res.data.data;
  },

  deleteComplaint: async (id) => {
    const res = await api.delete(`/admin/complaints/${id}`);
    return res.data;
  },

  /* =========================
     DASHBOARD
     ========================= */
  getDashboardStats: async () => {
    const res = await api.get("/admin/stats");
    return res.data.data;
  },
};
