# JABO Bus Booking - Frontend Setup

This document describes the frontend implementation for the JABO bus booking application.

## Overview

The frontend is built with:
- **React 19** - UI framework
- **React Router DOM** - Routing
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **Axios** - API calls

## Project Structure

```
frontend/
├── src/
│   ├── components/
│   │   ├── common/           # Reusable components
│   │   │   ├── Button.jsx
│   │   │   ├── Card.jsx
│   │   │   └── Input.jsx
│   │   └── layout/           # Layout components
│   │       ├── Navbar.jsx
│   │       ├── Footer.jsx
│   │       └── Layout.jsx
│   ├── pages/                # Page components
│   │   ├── Home.jsx
│   │   ├── Login.jsx
│   │   └── Signup.jsx
│   ├── context/              # Context providers
│   │   └── AuthContext.jsx
│   ├── services/             # API services
│   │   ├── api.js
│   │   └── authService.js
│   ├── App.jsx               # Main app component
│   ├── main.jsx              # Entry point
│   ├── App.css               # Global styles
│   └── index.css             # Tailwind imports
```

## Features

### Pages Created

#### 1. **Home Page** (`src/pages/Home.jsx`)
- Beautiful hero section with search form
- Features section highlighting key benefits
- Popular routes showcase
- Customer testimonials
- Call-to-action section

#### 2. **Login Page** (`src/pages/Login.jsx`)
- Modern, clean design
- Email/phone and password inputs
- Show/hide password toggle
- Error handling
- Loading states
- Link to signup page

#### 3. **Signup Page** (`src/pages/Signup.jsx`)
- Full registration form
- Name, email, phone, password fields
- Password confirmation
- Form validation
- Success message
- Link to login page

### Components Created

#### **Navbar** (`src/components/layout/Navbar.jsx`)
- Responsive navigation bar
- Logo and brand name
- Desktop and mobile menus
- User dropdown (when logged in)
- Login/Signup buttons (when logged out)
- Sticky positioning

#### **Footer** (`src/components/layout/Footer.jsx`)
- Social media links
- Quick links
- Support links
- Contact information
- Copyright notice

#### **Layout** (`src/components/layout/Layout.jsx`)
- Wraps pages with Navbar and Footer
- Uses React Router's Outlet
- Flexible layout system

### Common Components

#### **Button** (`src/components/common/Button.jsx`)
- Reusable button with variants
- Loading states
- Size options
- Disabled states

#### **Input** (`src/components/common/Input.jsx`)
- Reusable input field
- Icon support
- Error states
- Validation

#### **Card** (`src/components/common/Card.jsx`)
- Reusable card container
- Hover effects
- Customizable padding

## Routing

The application uses React Router with the following routes:

- `/` - Home page (with Navbar & Footer)
- `/login` - Login page (without Navbar & Footer)
- `/signup` - Signup page (without Navbar & Footer)

Pages that need Navbar and Footer are wrapped with the Layout component using nested routes.

## Styling

The application uses Tailwind CSS for styling with:
- Custom gradients
- Hover effects
- Smooth transitions
- Responsive design
- Modern color scheme (blues and purples)

## Authentication

The app uses React Context for state management:
- `AuthContext` - Provides auth state and methods
- `authService` - Handles API calls
- Local storage for token persistence
- Automatic token refresh

## Running the Application

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Environment Variables

Create a `.env` file in the root directory:
```
VITE_API_URL=http://localhost:5000/api
```

## Notes

- All pages are fully responsive
- Icons are from Lucide React
- Form validation is implemented
- Loading states are handled
- Error messages are user-friendly
- The design is modern and professional


