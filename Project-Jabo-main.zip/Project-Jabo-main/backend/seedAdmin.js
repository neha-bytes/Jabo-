/**
 * seedAdmin.js
 * Simple script to create a default admin user if one doesn't exist
 * Usage: node seedAdmin.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');

(async () => {
  try {
    await connectDB();

    const email = process.env.ADMIN_EMAIL || 'admin@jabo.app';
    const password = process.env.ADMIN_PASS || 'Admin123!';
    const name = process.env.ADMIN_NAME || 'Jabo Admin';
    const phone = process.env.ADMIN_PHONE || '01700000000';

    const existing = await User.findOne({ email });
    if (existing) {
      console.log('Admin already exists:', existing.email);
      process.exit(0);
    }

    const admin = await User.create({
      name,
      email,
      phone,
      password,
      role: 'admin',
      isVerified: true,
    });

    console.log('Admin created:', admin.email);
    process.exit(0);
  } catch (err) {
    console.error('Failed to seed admin', err.message);
    process.exit(1);
  }
})();
