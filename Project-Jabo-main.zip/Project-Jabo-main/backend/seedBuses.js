const mongoose = require("mongoose");
const Bus = require("./models/Bus");
const busData = require("./data/bus-seed-data.json");
require("dotenv").config();

const seedBuses = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("✅ MongoDB Connected...");

    // Clear existing buses (optional - remove if you want to keep existing data)
    // await Bus.deleteMany({});
    // console.log("🗑️  Existing buses removed");

    // Insert seed data
    const buses = await Bus.insertMany(busData);
    console.log(`✅ ${buses.length} buses inserted successfully!`);

    // Display inserted buses
    buses.forEach((bus, index) => {
      console.log(
        `${index + 1}. ${bus.busName} - ${bus.route.origin} to ${
          bus.route.destination
        }`
      );
    });

    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
};

seedBuses();
