// Review Model - backend/models/Review.js
// ============================================

const mongoose = require("mongoose");

/**
 * Review Schema
 * Handles ratings and reviews for buses and drivers
 * Used for: Rate & Review feature
 */
const reviewSchema = new mongoose.Schema(
  {
    // User who gave the review
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Review Type (bus trip or shuttle ride)
    reviewType: {
      type: String,
      enum: ["bus", "shuttle"],
      required: true,
    },

    // Reference to the trip
    trip: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: "reviewType", // Dynamic reference based on reviewType
      required: true,
    },

    // Bus Review (if reviewType is 'bus')
    bus: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bus",
      default: null,
    },

    // Driver Review
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      default: null,
    },

    // Rating (1-5 stars)
    rating: {
      overall: {
        type: Number,
        required: true,
        min: 1,
        max: 5,
      },
      cleanliness: {
        type: Number,
        min: 1,
        max: 5,
      },
      punctuality: {
        type: Number,
        min: 1,
        max: 5,
      },
      comfort: {
        type: Number,
        min: 1,
        max: 5,
      },
      service: {
        type: Number,
        min: 1,
        max: 5,
      },
    },

    // Review Text
    comment: {
      type: String,
      trim: true,
      maxlength: [500, "Comment cannot exceed 500 characters"],
    },

    // Review Images (optional)
    images: [String],

    // Helpful votes
    helpfulVotes: {
      type: Number,
      default: 0,
    },

    // Response from operator/driver
    response: {
      text: String,
      respondedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      respondedAt: Date,
    },

    // Review Status
    status: {
      type: String,
      enum: ["active", "hidden", "flagged"],
      default: "active",
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
reviewSchema.index({ bus: 1, createdAt: -1 });
reviewSchema.index({ driver: 1, createdAt: -1 });
reviewSchema.index({ user: 1 });

// Ensure one review per trip per user
reviewSchema.index({ user: 1, trip: 1 }, { unique: true });

/**
 * Static Method: Calculate Average Rating
 * @param {ObjectId} entityId - Bus or Driver ID
 * @param {String} entityType - 'bus' or 'driver'
 * @returns {Object} - Average ratings
 */
reviewSchema.statics.calculateAverageRating = async function (
  entityId,
  entityType
) {
  const field = entityType === "bus" ? "bus" : "driver";

  const result = await this.aggregate([
    { $match: { [field]: entityId, status: "active" } },
    {
      $group: {
        _id: null,
        averageOverall: { $avg: "$rating.overall" },
        averageCleanliness: { $avg: "$rating.cleanliness" },
        averagePunctuality: { $avg: "$rating.punctuality" },
        averageComfort: { $avg: "$rating.comfort" },
        averageService: { $avg: "$rating.service" },
        count: { $sum: 1 },
      },
    },
  ]);

  return result.length > 0 ? result[0] : { averageOverall: 0, count: 0 };
};

module.exports = mongoose.model("Review", reviewSchema);
