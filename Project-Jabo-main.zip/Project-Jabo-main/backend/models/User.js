const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

/**
 * User Schema
 * Handles user registration, authentication, and profile management
 * Used by: General users, Drivers, and Admins
 */
const userSchema = new mongoose.Schema(
  {
    // Basic Information
    name: {
      type: String,
      required: [true, "Please provide a name"],
      trim: true,
      minlength: [2, "Name must be at least 2 characters long"],
    },

    email: {
      type: String,
      required: [true, "Please provide an email"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please provide a valid email address"],
    },

    phone: {
      type: String,
      required: [true, "Please provide a phone number"],
      unique: true,
      match: [
        /^01[3-9]\d{8}$/,
        "Please provide a valid Bangladeshi phone number (01XXXXXXXXX)",
      ],
    },

    studentId: {
      type: String,
      trim: true,
    },

    password: {
      type: String,
      required: [true, "Please provide a password"],
      minlength: [6, "Password must be at least 6 characters long"],
      select: false, // Don't return password in queries by default
    },

    // Role Management
    role: {
      type: String,
      enum: ["user", "driver", "admin"],
      default: "user",
    },

    // Account Status
    isVerified: {
      type: Boolean,
      default: false,
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    // Profile Information
    profileImage: {
      type: String,
      default: null,
    },

    address: {
      street: String,
      city: String,
      district: String,
      postalCode: String,
    },

    // User Preferences
    preferences: {
      seatPreference: {
        type: String,
        enum: ["window", "aisle", "any"],
        default: "any",
      },
      notifications: {
        email: { type: Boolean, default: true },
        sms: { type: Boolean, default: true },
        push: { type: Boolean, default: true },
      },
    },

    // For password reset functionality
    resetPasswordToken: String,
    resetPasswordExpire: Date,
  },
  {
    timestamps: true, // Automatically creates createdAt and updatedAt fields
  }
);

/**
 * Pre-save Middleware
 * Hash password before saving to database
 * Only runs if password is modified
 */
userSchema.pre("save", async function (next) {
  // If password is not modified, skip hashing
  if (!this.isModified("password")) {
    return next();
  }

  // Generate salt and hash password
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

/**
 * Instance Method: Compare Password
 * Used during login to verify user password
 * @param {String} candidatePassword - Password entered by user
 * @returns {Boolean} - True if password matches
 */
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

/**
 * Instance Method: Get Public Profile
 * Returns user data without sensitive information
 * @returns {Object} - User profile object
 */
userSchema.methods.getPublicProfile = function () {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    phone: this.phone,
    studentId: this.studentId,
    role: this.role,
    profileImage: this.profileImage,
    isVerified: this.isVerified,
  };
};

module.exports = mongoose.model("User", userSchema);
