const mongoose = require("mongoose");

const passengerSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true },
    email: { type: String, trim: true },
    phone: { type: String, trim: true },
    gender: {
      type: String,
      enum: ["male", "female", "other"],
      lowercase: true,
    },
  },
  { _id: false }
);

const contactInfoSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
  },
  { _id: false }
);

const locationSchema = new mongoose.Schema(
  {
    address: { type: String, trim: true },
    coordinates: {
      type: [Number],
      validate: {
        validator: (coords) =>
          !coords || coords.length === 0 || coords.length === 2,
        message: "Coordinates must be [longitude, latitude]",
      },
    },
    contactName: { type: String, trim: true },
    contactPhone: { type: String, trim: true },
  },
  { _id: false }
);

const bookingSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    bus: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bus",
      required: true,
    },
    journeyDate: {
      type: Date,
      required: true,
    },
    seats: {
      type: [String],
      required: true,
      validate: {
        validator: (arr) => arr.length > 0,
        message: "At least one seat must be selected",
      },
    },
    totalFare: {
      type: Number,
      required: true,
      min: 0,
    },
    status: {
      type: String,
      enum: ["pending", "confirmed", "cancelled", "completed"],
      default: "pending",
    },
    payment: {
      method: { type: String, default: "cash" },
      status: {
        type: String,
        enum: ["pending", "paid", "failed", "refunded"],
        default: "pending",
      },
      transactionId: { type: String },
      paidAt: { type: Date },
    },
    passengers: {
      type: [passengerSchema],
      default: [],
    },
    contactInfo: contactInfoSchema,
    shuttleService: {
      requested: { type: Boolean, default: false },
      status: {
        type: String,
        enum: [
          "not_requested",
          "pending",
          "accepted",
          "on_the_way",
          "arrived",
          "started",
          "completed",
          "cancelled",
        ],
        default: "not_requested",
      },
      shuttleId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Shuttle",
      },
      vehicleType: { type: String, trim: true },
      pickup: locationSchema,
      dropoff: locationSchema,
      scheduledTime: { type: Date },
      notes: { type: String, trim: true },
      fare: {
        baseFare: Number,
        distanceFare: Number,
        total: Number,
      },
      demoResponse: mongoose.Schema.Types.Mixed,
    },
    meta: {
      source: { type: String, default: "web" },
      initiatedBy: { type: String, default: "user" },
    },
  },
  {
    timestamps: true,
  }
);

bookingSchema.index({ journeyDate: 1 });
bookingSchema.index({ bus: 1, journeyDate: 1 });

/**
 * Get the exact bus departure time as a UTC Date object
 * Handles timezone conversion correctly for Bangladesh (UTC+6)
 */
bookingSchema.methods.getBusDepartureTime = function () {
  if (!this.bus?.schedule?.departureTime) {
    return null;
  }

  // Parse the 12-hour time format
  const timeStr = this.bus.schedule.departureTime.trim().toUpperCase();
  const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/);

  if (!match) return null;

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3];

  // Convert to 24-hour format
  if (period === "PM" && hours !== 12) hours += 12;
  else if (period === "AM" && hours === 12) hours = 0;

  // journeyDate is stored as UTC representing the local date
  // e.g., "2025-12-27T18:00:00.000Z" = Dec 28 midnight Bangladesh time
  const journeyUTC = new Date(this.journeyDate);

  // Add 6 hours to shift to Bangladesh local time to extract correct date
  const localOffset = 6 * 60 * 60 * 1000; // 6 hours in ms
  const localDate = new Date(journeyUTC.getTime() + localOffset);

  // Extract date components from the shifted date
  const year = localDate.getUTCFullYear();
  const month = localDate.getUTCMonth();
  const day = localDate.getUTCDate();

  // Create departure time in UTC directly
  // Bangladesh time 15:50 = UTC 09:50 (subtract 6 hours)
  const departureUTC = new Date(
    Date.UTC(
      year,
      month,
      day,
      hours - 6, // Subtract 6 hours to convert Bangladesh time to UTC
      minutes,
      0,
      0
    )
  );

  return departureUTC;
};

const Booking = mongoose.model("Booking", bookingSchema);

module.exports = Booking;
