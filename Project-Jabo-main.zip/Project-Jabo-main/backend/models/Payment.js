// Payment Model - backend/models/Payment.js
// ============================================

/**
 * Payment Schema
 * Tracks all payment transactions (bookings and shuttles)
 */
const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    // Payment Reference (auto-generated in pre-save hook)
    paymentReference: {
      type: String,
      unique: true,
      required: false, // Will be auto-generated if not provided
    },

    // User who made payment
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },

    // Payment Type
    paymentType: {
      type: String,
      enum: ["Booking", "Shuttle"],
      required: true,
    },

    // Reference to booking or shuttle
    relatedId: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: "paymentType",
      required: true,
    },

    // Payment Method
    method: {
      type: String,
      enum: ["bKash", "Nagad", "Rocket", "Cash"],
      default: "bKash",
    },

    // Amount Details
    amount: {
      subtotal: {
        type: Number,
        required: true,
      },
      total: {
        type: Number,
        required: true,
      },
    },

    // Payment Gateway Details (for fake transaction)
    gateway: {
      transactionId: {
        type: String,
        default: null,
      },
    },

    // Payment Status
    status: {
      type: String,
      enum: ["pending", "completed", "failed"],
      default: "pending",
    },

    // Timestamps
    completedAt: {
      type: Date,
      default: null,
    },

    // Payment Description
    description: {
      type: String,
      required: true,
    },

    // Customer Information (for invoice)
    customerInfo: {
      name: String,
      email: String,
      phone: String,
    },
  },
  {
    timestamps: true,
  }
);

// Generate unique payment reference
paymentSchema.pre("save", async function (next) {
  if (!this.paymentReference || this.paymentReference.trim() === "") {
    const date = new Date().toISOString().slice(2, 10).replace(/-/g, "");
    const random = Math.floor(100000 + Math.random() * 900000);
    const timestamp = Date.now().toString().slice(-6);
    this.paymentReference = `PAY${date}${random}${timestamp}`;
  }
  next();
});

// Indexes
paymentSchema.index({ user: 1, createdAt: -1 });
paymentSchema.index({ paymentReference: 1 });
paymentSchema.index({ "gateway.transactionId": 1 });
paymentSchema.index({ status: 1 });

/**
 * Instance Method: Mark as Completed
 * Updates payment status to completed with randomly generated transaction ID
 */
paymentSchema.methods.markAsCompleted = async function () {
  // Generate random transaction ID
  const date = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  const random = Math.floor(1000000000 + Math.random() * 9000000000);
  const transactionId = `TXN${date}${random}`;

  this.status = "completed";
  this.completedAt = new Date();
  this.gateway.transactionId = transactionId;

  return this.save();
};

/**
 * Static Method: Create Payment
 * Creates a new payment record
 */
paymentSchema.statics.createPayment = async function (paymentData) {
  const payment = new this(paymentData);
  return payment.save();
};

module.exports = mongoose.model("Payment", paymentSchema);
