// Driver Model - backend/models/Driver.js
// ============================================
const mongoose = require("mongoose");

/**
 * Driver Schema
 * Stores driver-specific information
 * References User model for authentication
 */
const driverSchema = new mongoose.Schema(
  {
    // Reference to User
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },

    // Driver License Information
    licenseNumber: {
      type: String,
      required: [true, "License number is required"],
      trim: true,
      unique: true,
    },

    licenseExpiryDate: {
      type: Date,
      required: true,
    },

    nidNumber: {
      type: String,
      required: [true, "NID number is required"],
      trim: true,
      unique: true,
    },

    // Vehicle Information
    vehicleType: {
      type: String,
      enum: ["Car", "Bike", "Microbus"],
      required: true,
    },

    vehicleRegistrationNumber: {
      type: String,
      required: true,
      trim: true,
    },

    vehicleBrand: {
      type: String,
      required: true,
      trim: true,
    },

    vehicleModel: {
      type: String,
      required: true,
      trim: true,
    },

    vehicleYear: {
      type: Number,
      required: true,
    },

    vehicleColor: {
      type: String,
      required: true,
      trim: true,
    },

    // Driver Availability & Presence
    isAvailable: {
      type: Boolean,
      default: true,
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    isOnline: {
      type: Boolean,
      default: false,
    },

    lastSeenAt: Date,

    currentLocation: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number], // [lon, lat]
        default: [0, 0],
      },
      updatedAt: Date,
    },

    serviceRadiusKm: {
      type: Number,
      default: 5,
      min: 1,
      max: 20,
    },

    socketId: String,

    activeShuttle: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shuttle",
    },

    // Documents
    documents: {
      licenseCopy: String,
      nidCopy: String,
      vehicleRegistrationCopy: String,
      profilePhoto: String,
      vehiclePhoto: String,
    },

    // Banking Information (for payments)
    bankAccount: {
      accountNumber: String,
      bankName: String,
      accountHolderName: String,
      branch: String,
      routingNumber: String,
    },

    // Ratings and Statistics
    totalRides: {
      type: Number,
      default: 0,
    },

    totalEarnings: {
      type: Number,
      default: 0,
    },

    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },

    // Verification timestamps
    verifiedAt: Date,
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
driverSchema.index({ user: 1 });
driverSchema.index({ licenseNumber: 1 });
driverSchema.index({ nidNumber: 1 });
driverSchema.index({ isAvailable: 1, isVerified: 1, isActive: 1 });
driverSchema.index({ currentLocation: "2dsphere" });

/**
 * Instance Method: Get Public Profile
 * Returns driver data without sensitive information
 */
driverSchema.methods.getPublicProfile = function () {
  return {
    id: this._id,
    user: this.user,
    licenseNumber: this.licenseNumber,
    licenseExpiryDate: this.licenseExpiryDate,
    vehicleType: this.vehicleType,
    vehicleRegistrationNumber: this.vehicleRegistrationNumber,
    vehicleBrand: this.vehicleBrand,
    vehicleModel: this.vehicleModel,
    vehicleYear: this.vehicleYear,
    isAvailable: this.isAvailable,
    isVerified: this.isVerified,
    isOnline: this.isOnline,
    totalRides: this.totalRides,
    totalEarnings: this.totalEarnings,
    averageRating: this.averageRating,
    currentLocation: this.currentLocation,
    serviceRadiusKm: this.serviceRadiusKm,
  };
};

module.exports = mongoose.model("Driver", driverSchema);


