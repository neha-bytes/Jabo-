const mongoose = require("mongoose");

const shuttleMessageSchema = new mongoose.Schema(
  {
    shuttle: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shuttle",
      required: true,
      index: true,
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
    },
    senderType: {
      type: String,
      enum: ["user", "driver", "system"],
      required: true,
    },
    content: {
      type: String,
      trim: true,
      required: true,
    },
    seenBy: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        seenAt: Date,
      },
    ],
    meta: mongoose.Schema.Types.Mixed,
    isSystem: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

shuttleMessageSchema.index({ shuttle: 1, createdAt: -1 });

module.exports = mongoose.model("ShuttleMessage", shuttleMessageSchema);



