const mongoose = require("mongoose");

const busSchema = new mongoose.Schema(
  {
    busName: {
      type: String,
      required: [true, "Bus name is required"],
      trim: true,
    },
    operatorName: {
      type: String,
      required: [true, "Operator name is required"],
      trim: true,
    },
    coachNumber: {
      type: String,
      required: [true, "Coach number is required"],
      unique: true,
      trim: true,
    },
    busType: {
      type: String,
      enum: ["AC", "Non-AC", "Sleeper", "Semi-Sleeper", "Luxury"],
      required: [true, "Bus type is required"],
    },
    route: {
      origin: {
        type: String,
        required: [true, "Origin is required"],
        trim: true,
      },
      destination: {
        type: String,
        required: [true, "Destination is required"],
        trim: true,
      },
    },
    stoppages: [
      {
        name: {
          type: String,
          required: true,
          trim: true,
        },
        arrivalTime: {
          type: String,
          required: true,
        },
        fare: {
          type: Number,
          required: true,
          min: 0,
        },
      },
    ],
    schedule: {
      departureTime: {
        type: String,
        required: [true, "Departure time is required"],
      },
      arrivalTime: {
        type: String,
        required: [true, "Arrival time is required"],
      },
      daysOfOperation: {
        type: [String],
        enum: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        default: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
      },
    },
    fare: {
      baseFare: {
        type: Number,
        required: [true, "Base fare is required"],
        min: 0,
      },
      currency: {
        type: String,
        default: "BDT",
      },
    },
    seats: {
      totalSeats: {
        type: Number,
        required: true,
        default: 40,
      },
      availableSeats: {
        type: Number,
        required: true,
        default: 40,
      },
      seatLayout: {
        type: String,
        enum: ["2x2", "2x3", "1x2"],
        default: "2x2",
      },
      bookedSeats: {
        type: [String],
        default: [],
      },
    },
    amenities: {
      type: [String],
      enum: [
        "WiFi",
        "Charging Port",
        "Water",
        "Snacks",
        "TV",
        "Blanket",
        "Reading Light",
      ],
      default: [],
    },
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
    },
    status: {
      type: String,
      enum: ["Active", "Inactive", "Maintenance", "Cancelled"],
      default: "Active",
    },
    rating: {
      average: {
        type: Number,
        default: 0,
        min: 0,
        max: 5,
      },
      count: {
        type: Number,
        default: 0,
      },
    },
    gpsEnabled: {
      type: Boolean,
      default: false,
    },
    currentLocation: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        default: [0, 0],
      },
    },
  },
  {
    timestamps: true,
  }
);

// Index for geospatial queries
busSchema.index({ currentLocation: "2dsphere" });

// Index for efficient route searches
busSchema.index({ "route.origin": 1, "route.destination": 1 });
busSchema.index({ "schedule.departureTime": 1 });

// Virtual for occupied seats percentage
busSchema.virtual("occupancyRate").get(function () {
  return (
    ((this.seats.totalSeats - this.seats.availableSeats) /
      this.seats.totalSeats) *
    100
  );
});

// Method to book seats
busSchema.methods.bookSeats = function (seatNumbers) {
  if (seatNumbers.length > this.seats.availableSeats) {
    throw new Error("Not enough available seats");
  }
  this.seats.bookedSeats.push(...seatNumbers);
  this.seats.availableSeats -= seatNumbers.length;
  return this.save();
};

// Method to release seats (for cancellation)
busSchema.methods.releaseSeats = function (seatNumbers) {
  this.seats.bookedSeats = this.seats.bookedSeats.filter(
    (seat) => !seatNumbers.includes(seat)
  );
  this.seats.availableSeats += seatNumbers.length;
  return this.save();
};

// Static method to find available buses
busSchema.statics.findAvailableBuses = function (origin, destination, date) {
  return this.find({
    "route.origin": origin,
    "route.destination": destination,
    "seats.availableSeats": { $gt: 0 },
    status: "Active",
  });
};

const Bus = mongoose.model("Bus", busSchema);

module.exports = Bus;
