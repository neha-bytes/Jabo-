// Shuttle Model - backend/models/Shuttle.js
// ============================================
const mongoose = require("mongoose");

const generateShuttleReference = () => {
  const date = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  const random = Math.floor(1000 + Math.random() * 9000);
  return `SHT${date}${random}`;
};

/**
 * Shuttle Schema
 * Manages shuttle ride requests (car, bike, microbus)
 * Used for: Shuttle Service Request feature
 */
const shuttleSchema = new mongoose.Schema(
  {
    // Shuttle Reference Number
    shuttleReference: {
      type: String,
      unique: true,
      default: generateShuttleReference,
    },

    // Related booking
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Booking",
      required: true,
    },

    // User who requested the shuttle
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Assigned Driver
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      default: null,
    },

    // Vehicle Type Requested
    vehicleType: {
      type: String,
      enum: ["Car", "Bike", "Microbus"],
      required: [true, "Vehicle type is required"],
    },

    // Pickup and Drop-off Locations
    pickup: {
      address: {
        type: String,
        required: true,
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        validate: {
          validator: (coords) =>
            !coords || coords.length === 0 || coords.length === 2,
          message: "Coordinates must be [longitude, latitude]",
        },
      },
      contactName: String,
      contactPhone: String,
    },

    dropoff: {
      address: {
        type: String,
        required: true,
      },
      coordinates: {
        type: [Number],
        validate: {
          validator: (coords) =>
            !coords || coords.length === 0 || coords.length === 2,
          message: "Coordinates must be [longitude, latitude]",
        },
      },
    },

    // Trip Details
    scheduledTime: {
      type: Date,
      required: true,
    },

    distance: {
      type: Number, // in kilometers
      default: 0,
    },

    estimatedDuration: {
      type: Number, // in minutes
      default: 0,
    },

    // Pricing
    fare: {
      baseFare: Number,
      distanceFare: Number,
      total: {
        type: Number,
        required: true,
      },
    },

    // Payment
    payment: {
      method: {
        type: String,
        enum: ["bKash", "Nagad", "Cash", "Card"],
        default: "Cash",
      },
      status: {
        type: String,
        enum: ["pending", "completed", "failed"],
        default: "pending",
      },
      transactionId: String,
      paidAt: Date,
    },

    // Ride Status
    status: {
      type: String,
      enum: [
        "pending",
        "accepted",
        "on_the_way",
        "arrived",
        "started",
        "completed",
        "cancelled",
      ],
      default: "pending",
    },

    // Timestamps for tracking
    acceptedAt: Date,
    startedAt: Date,
    completedAt: Date,
    cancelledAt: Date,

    // Assignment metadata
    assignment: {
      acceptedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Driver",
      },
      acceptedAt: Date,
      lockedAt: Date,
    },

    broadcastedDrivers: [
      {
        driver: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Driver",
        },
        notifiedAt: Date,
        distanceKm: Number,
      },
    ],

    timeline: [
      {
        status: String,
        label: String,
        at: Date,
        meta: mongoose.Schema.Types.Mixed,
      },
    ],

    driverLocation: {
      coordinates: {
        type: [Number],
      },
      heading: Number,
      updatedAt: Date,
    },

    activeRideMetrics: {
      etaMinutes: Number,
      countdownSeconds: Number,
      lastUpdated: Date,
    },

    // Cancellation
    cancellation: {
      cancelledBy: {
        type: String,
        enum: ["user", "driver", "admin"],
        default: null,
      },
      reason: String,
    },

    // Special Requests
    specialRequests: String,

    // Number of Passengers
    passengers: {
      type: Number,
      default: 1,
      min: 1,
    },
  },
  {
    timestamps: true,
  }
);

// Generate unique shuttle reference
shuttleSchema.pre("save", async function (next) {
  if (!this.shuttleReference) {
    this.shuttleReference = generateShuttleReference();
  }
  next();
});

// Indexes
shuttleSchema.index({ user: 1, scheduledTime: -1 });
shuttleSchema.index({ driver: 1, status: 1 });
shuttleSchema.index({ booking: 1 });
shuttleSchema.index({ status: 1, vehicleType: 1 });
shuttleSchema.index({ "pickup.coordinates": 1 });

module.exports = mongoose.model("Shuttle", shuttleSchema);
