const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");
const Driver = require("../models/Driver");
const Shuttle = require("../models/Shuttle");
const ShuttleMessage = require("../models/ShuttleMessage");

let io;
const onlineUsers = new Map(); // userId -> Set<socketId>
const onlineDrivers = new Map(); // driverId -> { socketId, userId, vehicleType, location }

const registerUserSocket = (userId, socketId) => {
  if (!onlineUsers.has(userId)) {
    onlineUsers.set(userId, new Set());
  }
  onlineUsers.get(userId).add(socketId);
};

const unregisterUserSocket = (userId, socketId) => {
  if (!userId) return;
  const set = onlineUsers.get(userId);
  if (!set) return;
  set.delete(socketId);
  if (set.size === 0) {
    onlineUsers.delete(userId);
  }
};

const setDriverPresence = async ({ socket, driver, location }) => {
  if (!driver) return;
  onlineDrivers.set(driver._id.toString(), {
    socketId: socket.id,
    userId: socket.user.id,
    vehicleType: driver.vehicleType,
    location: location || driver.currentLocation,
  });

  driver.isOnline = true;
  driver.socketId = socket.id;
  driver.lastSeenAt = new Date();
  if (location?.coordinates?.length === 2) {
    driver.currentLocation = {
      type: "Point",
      coordinates: location.coordinates,
      updatedAt: new Date(),
    };
  }
  await driver.save();
};

const clearDriverPresence = async (socket) => {
  if (socket.user?.role !== "driver") return;
  const driver = await Driver.findOne({ user: socket.user.id });
  if (!driver) return;
  const driverId = driver._id.toString();
  const presence = onlineDrivers.get(driverId);
  if (presence && presence.socketId === socket.id) {
    onlineDrivers.delete(driverId);
    driver.isOnline = false;
    driver.socketId = null;
    driver.lastSeenAt = new Date();
    await driver.save();
  }
};

const authenticateSocket = async (socket, next) => {
  try {
    const token =
      socket.handshake.auth?.token ||
      socket.handshake.headers["authorization"]?.replace("Bearer ", "") ||
      socket.handshake.query?.token;

    if (!token) {
      return next(new Error("Authentication token missing"));
    }

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    socket.user = {
      id: payload.id,
      role: payload.role,
    };
    return next();
  } catch (error) {
    return next(new Error("Invalid socket authentication"));
  }
};

const emitToUser = (userId, event, payload) => {
  const sockets = onlineUsers.get(userId?.toString());
  if (!io || !sockets) return;
  sockets.forEach((socketId) => {
    io.to(socketId).emit(event, payload);
  });
};

const emitToDriver = (driverId, event, payload) => {
  if (!io) return;
  const presence = onlineDrivers.get(driverId?.toString());
  if (presence) {
    io.to(presence.socketId).emit(event, payload);
  }
};

const emitToShuttleRoom = (shuttleId, event, payload) => {
  if (!io) return;
  io.to(`shuttle:${shuttleId}`).emit(event, payload);
};

const joinShuttleRoom = async (socket, shuttleId) => {
  const shuttle = await Shuttle.findById(shuttleId)
    .populate("user", "_id")
    .populate("driver", "user");
  if (!shuttle) {
    socket.emit("error", { message: "Shuttle not found" });
    return;
  }

  const userId = socket.user.id.toString();
  const isOwner = shuttle.user?._id?.toString() === userId;
  const isDriver =
    shuttle.driver?.user?.toString && shuttle.driver.user.toString() === userId;
  const isAdmin = socket.user.role === "admin";

  if (!isOwner && !isDriver && !isAdmin) {
    socket.emit("error", { message: "Unauthorized to join shuttle room" });
    return;
  }

  socket.join(`shuttle:${shuttleId}`);
  socket.emit("shuttle:joined", { shuttleId });
};

const leaveShuttleRoom = (socket, shuttleId) => {
  if (!shuttleId) return;
  socket.leave(`shuttle:${shuttleId}`);
  socket.emit("shuttle:left", { shuttleId });
};

// Fixed handleChatMessage function in socket.js

// ==========================================
// BACKEND FIX: socket.js
// Replace the handleChatMessage function
// ==========================================

const handleChatMessage = async (socket, payload) => {
  try {
    const { shuttleId, content } = payload;

    if (!shuttleId) {
      socket.emit("error", { message: "Shuttle ID is required" });
      return;
    }

    if (!content || !content.trim()) {
      socket.emit("error", { message: "Message content cannot be empty" });
      return;
    }

    const shuttle = await Shuttle.findById(shuttleId)
      .populate("driver", "user")
      .populate("user", "_id");

    if (!shuttle) {
      socket.emit("error", { message: "Shuttle not found" });
      return;
    }

    // Authorization check
    const userId = socket.user.id.toString();
    const isUser = socket.user.role === "user";
    const isDriver = socket.user.role === "driver";

    if (isUser && shuttle.user?._id?.toString() !== userId) {
      socket.emit("error", {
        message: "You are not authorized to send messages in this chat",
      });
      return;
    }

    if (isDriver) {
      const driver = await Driver.findOne({ user: socket.user.id });
      if (
        !driver ||
        !shuttle.driver ||
        shuttle.driver._id.toString() !== driver._id.toString()
      ) {
        socket.emit("error", {
          message: "You are not authorized to send messages in this chat",
        });
        return;
      }
    }

    const senderType = isDriver ? "driver" : "user";
    let driverId = null;

    if (isDriver) {
      const driver = await Driver.findOne({ user: socket.user.id });
      if (driver) {
        driverId = driver._id;
      }
    }

    const message = await ShuttleMessage.create({
      shuttle: shuttleId,
      content: content.trim(),
      senderType,
      sender: isUser ? socket.user.id : null,
      driver: driverId,
    });

    // *** FIX: Add senderId to help frontend identify the sender ***
    const messagePayload = {
      _id: message._id,
      shuttleId: shuttleId,
      content: message.content,
      senderType: message.senderType,
      senderId: socket.user.id, // *** ADD THIS - the actual user ID who sent it ***
      sender: message.sender,
      driver: message.driver,
      createdAt: message.createdAt,
    };

    console.log("💬 Chat message emitted:", {
      shuttleId,
      senderType: messagePayload.senderType,
      senderId: messagePayload.senderId,
      content: content.substring(0, 30),
    });

    emitToShuttleRoom(shuttleId, "chat:message", messagePayload);
  } catch (error) {
    console.error("Chat message error", error);
    socket.emit("error", {
      message: "Failed to send message",
      error: error.message,
    });
  }
};

const handleDriverLocationPing = async (socket, payload) => {
  try {
    const driver = await Driver.findOne({ user: socket.user.id });
    if (!driver) return;

    const { shuttleId, coords, heading } = payload;
    if (!coords || coords.length !== 2) return;

    driver.currentLocation = {
      type: "Point",
      coordinates: coords,
      updatedAt: new Date(),
    };
    driver.lastSeenAt = new Date();
    await driver.save();

    const update = {
      driverLocation: {
        coordinates: coords,
        heading: heading || null,
        updatedAt: new Date(),
      },
    };

    if (shuttleId) {
      const shuttle = await Shuttle.findByIdAndUpdate(
        shuttleId,
        {
          $set: update,
        },
        { new: true }
      );
      if (shuttle) {
        emitToShuttleRoom(shuttleId, "driver-location", update.driverLocation);
      }
    }
  } catch (error) {
    console.error("Driver location error", error);
  }
};

const initSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: process.env.CLIENT_URL || "*",
      methods: ["GET", "POST"],
    },
  });

  io.use(authenticateSocket);

  io.on("connection", async (socket) => {
    const userId = socket.user.id.toString();
    registerUserSocket(userId, socket.id);

    // *** FIX: Auto-register drivers as online when they connect ***
    if (socket.user.role === "driver") {
      try {
        const driver = await Driver.findOne({ user: socket.user.id });
        if (driver) {
          driver.isOnline = true;
          driver.isAvailable = driver.isAvailable !== false;
          driver.lastSeenAt = new Date();
          driver.socketId = socket.id;

          // ✅ ADD THIS: Set a default location if none exists
          if (
            !driver.currentLocation ||
            !driver.currentLocation.coordinates ||
            driver.currentLocation.coordinates.length !== 2
          ) {
            // Default to Dhaka city center if no location
            driver.currentLocation = {
              type: "Point",
              coordinates: [90.4125, 23.8103], // [lng, lat] - Dhaka
              updatedAt: new Date(),
            };
            console.log(`📍 Set default location for driver ${driver._id}`);
          }

          await driver.save();
          await setDriverPresence({ socket, driver });
          socket.join(`driver:${driver._id}`);

          console.log(`✅ Driver ${driver._id} connected and set online`);
          emitToDriver(driver._id, "driver:availability:updated", {
            isAvailable: driver.isAvailable,
            isOnline: true,
          });
        }
      } catch (error) {
        console.error("Error setting driver online:", error);
      }
    }

    if (socket.user.role === "admin") {
      socket.join("admin");
    }

    socket.on("shuttle:join", (shuttleId) =>
      joinShuttleRoom(socket, shuttleId)
    );
    socket.on("join-shuttle-room", (shuttleId) =>
      joinShuttleRoom(socket, shuttleId)
    );
    socket.on("shuttle:leave", (shuttleId) =>
      leaveShuttleRoom(socket, shuttleId)
    );
    socket.on("leave-shuttle-room", (shuttleId) =>
      leaveShuttleRoom(socket, shuttleId)
    );
    socket.on("chat:message", (payload) => handleChatMessage(socket, payload));
    socket.on("chat:typing", ({ shuttleId, isTyping }) =>
      emitToShuttleRoom(shuttleId, "chat:typing", {
        userId,
        isTyping,
      })
    );
    socket.on("chat:seen", async ({ shuttleId }) => {
      await ShuttleMessage.updateMany(
        { shuttle: shuttleId, "seenBy.user": { $ne: userId } },
        {
          $push: {
            seenBy: { user: userId, seenAt: new Date() },
          },
        }
      );
      emitToShuttleRoom(shuttleId, "chat:seen", { userId });
    });

    socket.on("driver-location", (payload) =>
      handleDriverLocationPing(socket, payload)
    );

    socket.on("driver-online", async () => {
      console.log("🔵 ===== DRIVER-ONLINE EVENT RECEIVED =====");
      console.log("🔵 Socket ID:", socket.id);
      console.log("🔵 User ID:", socket.user.id);
      console.log("🔵 User Role:", socket.user.role);

      if (socket.user.role !== "driver") {
        console.log("❌ User is not a driver, ignoring event");
        return;
      }

      const driver = await Driver.findOne({ user: socket.user.id });
      console.log("🔵 Driver found:", driver ? driver._id : "NOT FOUND");

      if (!driver) {
        console.log("❌ No driver document found for user:", socket.user.id);
        return;
      }

      console.log("🔵 Driver BEFORE update:", {
        isOnline: driver.isOnline,
        isAvailable: driver.isAvailable,
        socketId: driver.socketId,
      });

      await setDriverPresence({
        socket,
        driver,
        location: driver.currentLocation,
      });

      console.log("🔵 Driver AFTER update:", {
        isOnline: driver.isOnline,
        isAvailable: driver.isAvailable,
        socketId: driver.socketId,
      });

      console.log("🔵 onlineDrivers Map size:", onlineDrivers.size);
      console.log("🔵 onlineDrivers keys:", Array.from(onlineDrivers.keys()));

      emitToDriver(driver._id, "driver:availability:updated", {
        isAvailable: driver.isAvailable,
      });

      console.log("🔵 ===== DRIVER-ONLINE EVENT COMPLETE =====\n");
    });

    socket.on("driver:availability", async ({ isAvailable, coords }) => {
      if (socket.user.role !== "driver") return;
      const driver = await Driver.findOne({ user: socket.user.id });
      if (!driver) return;
      driver.isAvailable = isAvailable;
      if (coords?.length === 2) {
        driver.currentLocation = {
          type: "Point",
          coordinates: coords,
          updatedAt: new Date(),
        };
      }
      driver.lastSeenAt = new Date();
      driver.isOnline = true;
      await driver.save();
      await setDriverPresence({
        socket,
        driver,
        location: driver.currentLocation,
      });
      emitToDriver(driver._id, "driver:availability:updated", {
        isAvailable: driver.isAvailable,
      });
    });

    socket.on("disconnect", async () => {
      unregisterUserSocket(userId, socket.id);
      await clearDriverPresence(socket);
    });
  });
};

const getIO = () => io;
const getOnlineDrivers = () => onlineDrivers;

module.exports = {
  initSocket,
  getIO,
  emitToUser,
  emitToDriver,
  emitToShuttleRoom,
  getOnlineDrivers,
};
