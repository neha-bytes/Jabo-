/**
 * Database Configuration
 * Handles MongoDB connection using Mongoose
 */

const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    // MongoDB connection options
    const options = {
      // useNewUrlParser: true,      // No longer needed in Mongoose 6+
      // useUnifiedTopology: true,   // No longer needed in Mongoose 6+
    };

    // Connect to MongoDB
    const conn = await mongoose.connect(process.env.MONGO_URI, options);

    console.log("=".repeat(50));
    console.log(`✅ MongoDB Connected Successfully`);
    console.log(`📦 Database: ${conn.connection.name}`);
    console.log(`🖥️  Host: ${conn.connection.host}`);
    console.log("=".repeat(50));

    // Connection event listeners
    mongoose.connection.on("error", (err) => {
      console.error("❌ MongoDB connection error:", err);
    });

    mongoose.connection.on("disconnected", () => {
      console.warn("⚠️  MongoDB disconnected");
    });
  } catch (error) {
    console.error("=".repeat(50));
    console.error("❌ MongoDB Connection Failed");
    console.error(`Error: ${error.message}`);
    console.error("=".repeat(50));
    process.exit(1); // Exit with failure
  }
};

module.exports = connectDB;
