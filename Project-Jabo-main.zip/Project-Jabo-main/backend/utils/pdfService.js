// backend/services/pdfService.js
const PDFDocument = require("pdfkit");
const QRCode = require("qrcode");
const { format } = require("date-fns");

async function generateTicketPDF(booking, bus, user) {
  const doc = new PDFDocument({
    size: "A4",
    margin: 50,
    bufferPages: true,
  });

  const buffers = [];
  doc.on("data", buffers.push.bind(buffers));

  // === HEADER ===
  doc
    .fontSize(32)
    .font("Helvetica-Bold")
    .fillColor("#1e40af")
    .text("E-TICKET", { align: "center" });

  doc
    .fontSize(16)
    .fillColor("#1e293b")
    .font("Helvetica")
    .text(bus.operatorName?.toUpperCase() || "JABO TRAVELS", {
      align: "center",
    });

  doc.moveDown(2);

  // === MAIN TICKET CARD ===
  const cardY = doc.y;
  doc
    .roundedRect(40, cardY - 20, 532, 380, 20)
    .lineWidth(4)
    .strokeColor("#1e40af")
    .stroke();

  doc
    .fontSize(18)
    .font("Helvetica-Bold")
    .fillColor("#166534")
    .text("TICKET CONFIRMED", 70, cardY);

  // === DETAILS GRID ===
  const details = [
    ["Booking ID", booking._id.toString()],
    ["PNR", booking._id.toString().slice(-10).toUpperCase()],
    [
      "Journey Date",
      format(new Date(booking.journeyDate), "dd MMM yyyy, EEEE"),
    ],
    [
      "Route",
      `${bus.route?.origin || "N/A"} to ${bus.route?.destination || "N/A"}`,
    ],
    ["Departure", bus.schedule?.departureTime || "N/A"],
    ["Arrival", bus.schedule?.arrivalTime || "N/A"],
    ["Bus", `${bus.busName || "N/A"} (${bus.coachNumber || "N/A"})`],
    ["Type", bus.busType || "AC/Non-AC"],
    ["Seats", booking.seats.join(", ")],
    [
      "Passenger",
      booking.passengers?.[0]?.fullName ||
        booking.contactInfo?.fullName ||
        "Passenger",
    ],
    ["Phone", booking.contactInfo?.phone || "N/A"],
    ["Email", booking.contactInfo?.email || "N/A"],
    ["Total Fare", `BDT ${booking.totalFare || 0}`],
  ];

  doc.fontSize(11);
  2;
  details.forEach(([label, value], i) => {
    const y = cardY + 50 + i * 24;
    doc
      .font("Helvetica-Bold")
      .fillColor("#1e293b")
      .text(label + ":", 70, y);
    doc
      .font("Helvetica")
      .fillColor("#475569")
      .text(value || "—", 200, y);
  });

  // === QR CODE ===
  const verifyUrl = `${
    process.env.FRONTEND_URL || "http://localhost:5173"
  }/verify/${booking._id}`;
  try {
    const qrImage = await QRCode.toDataURL(verifyUrl);
    const base64 = qrImage.split(",")[1];
    const qrBuffer = Buffer.from(base64, "base64");

    doc.image(qrBuffer, 390, cardY + 50, { width: 140 });
    doc
      .fontSize(10)
      .fillColor("#64748b")
      .text("Scan to Verify Ticket", 390, cardY + 200, {
        width: 140,
        align: "center",
      });
  } catch (err) {
    doc
      .fontSize(9)
      .text("QR Unavailable", 390, cardY + 100, {
        width: 140,
        align: "center",
      });
  }

  // === FOOTER ===
  doc.moveDown(18);
  doc
    .fontSize(11)
    .fillColor("#dc2626")
    .text("Show this ticket at boarding. Keep it safe!", { align: "center" });

  doc.moveDown(1);
  doc
    .fontSize(10)
    .fillColor("#6b7280")
    .text("Support: support@jabo.com | Hotline: +880 96 123 45678", {
      align: "center",
    });

  doc.end();

  return new Promise((resolve) => {
    doc.on("end", () => {
      resolve(Buffer.concat(buffers));
    });
  });
}

module.exports = { generateTicketPDF };
