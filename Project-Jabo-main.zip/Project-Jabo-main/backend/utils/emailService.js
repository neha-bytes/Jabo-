const nodemailer = require("nodemailer");

// Create reusable transporter
const createTransporter = (smtpUser, smtpPass) => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: smtpUser,
      pass: smtpPass,
    },
  });
};

/**
 * Send booking confirmation email
 * @param {Object} bookingData - Booking information
 * @param {Object} busData - Bus information
 * @param {String} recipientEmail - Recipient email address
 */
const sendBookingConfirmation = async (bookingData, busData, recipientEmail) => {
  try {
    // Check SMTP configuration before creating transporter
    const smtpUser = process.env.SMTP_USER || process.env.SMTP_FROM?.match(/<(.+)>/)?.[1] || process.env.SMTP_FROM;
    const smtpPass = process.env.SMTP_PASS;

    if (!smtpUser || !smtpPass) {
      console.warn("SMTP credentials not configured. Email sending skipped.");
      console.warn("SMTP_USER:", smtpUser ? "✓ Set" : "✗ Missing");
      console.warn("SMTP_PASS:", smtpPass ? "✓ Set" : "✗ Missing");
      return { success: false, message: "Email service not configured" };
    }

    const transporter = createTransporter(smtpUser, smtpPass);

    const bookingDate = new Date(bookingData.journeyDate).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #3B82F6; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background-color: #f9fafb; padding: 20px; border-radius: 0 0 8px 8px; }
            .info-row { margin: 15px 0; padding: 10px; background-color: white; border-radius: 4px; }
            .label { font-weight: bold; color: #6B7280; }
            .value { color: #111827; margin-top: 5px; }
            .seats { display: inline-block; background-color: #3B82F6; color: white; padding: 5px 10px; border-radius: 4px; margin: 2px; }
            .footer { text-align: center; margin-top: 20px; color: #6B7280; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎫 Booking Confirmation</h1>
            </div>
            <div class="content">
              <p>Dear ${bookingData.contactInfo.fullName},</p>
              <p>Your bus booking has been confirmed! Here are your booking details:</p>
              
              <div class="info-row">
                <div class="label">Booking ID</div>
                <div class="value">${bookingData._id}</div>
              </div>

              <div class="info-row">
                <div class="label">Bus Name</div>
                <div class="value">${busData.busName || "N/A"}</div>
              </div>

              <div class="info-row">
                <div class="label">Route</div>
                <div class="value">${busData.route?.origin || "N/A"} → ${busData.route?.destination || "N/A"}</div>
              </div>

              <div class="info-row">
                <div class="label">Journey Date</div>
                <div class="value">${bookingDate}</div>
              </div>

              <div class="info-row">
                <div class="label">Departure Time</div>
                <div class="value">${busData.schedule?.departureTime || "N/A"}</div>
              </div>

              <div class="info-row">
                <div class="label">Seats</div>
                <div class="value">
                  ${bookingData.seats.map(seat => `<span class="seats">${seat}</span>`).join("")}
                </div>
              </div>

              <div class="info-row">
                <div class="label">Total Fare</div>
                <div class="value">BDT ${bookingData.totalFare}</div>
              </div>

              <div class="info-row">
                <div class="label">Payment Status</div>
                <div class="value">${bookingData.payment?.status || "pending"}</div>
              </div>

              <p style="margin-top: 20px;">Please arrive at the bus station at least 15 minutes before departure time.</p>
              <p>Thank you for choosing our service!</p>
            </div>
            <div class="footer">
              <p>This is an automated email. Please do not reply.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    // Use SMTP_FROM if available, otherwise use SMTP_USER
    const fromEmail = process.env.SMTP_FROM || `"Jabo Bus Service" <${smtpUser}>`;
    
    const mailOptions = {
      from: fromEmail,
      to: recipientEmail,
      subject: "🎫 Bus Booking Confirmation",
      html: htmlContent,
      text: `
        Booking Confirmation
        
        Dear ${bookingData.contactInfo.fullName},
        
        Your bus booking has been confirmed!
        
        Booking ID: ${bookingData._id}
        Bus: ${busData.busName || "N/A"}
        Route: ${busData.route?.origin || "N/A"} → ${busData.route?.destination || "N/A"}
        Journey Date: ${bookingDate}
        Departure Time: ${busData.schedule?.departureTime || "N/A"}
        Seats: ${bookingData.seats.join(", ")}
        Total Fare: BDT ${bookingData.totalFare}
        Payment Status: ${bookingData.payment?.status || "pending"}
        
        Please arrive at the bus station at least 15 minutes before departure time.
        
        Thank you for choosing our service!
      `,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Booking confirmation email sent:", info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error("Error sending booking confirmation email:", error);
    return { success: false, error: error.message };
  }
};

module.exports = {
  sendBookingConfirmation,
};



