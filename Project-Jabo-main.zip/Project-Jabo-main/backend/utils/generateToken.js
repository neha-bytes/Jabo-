const jwt = require("jsonwebtoken");

/**
 * Generate JWT Token
 * @param {String} userId - User ID
 * @param {String} role - User role (user/driver/admin)
 * @returns {String} - JWT token
 */
const generateToken = (userId, role) => {
  return jwt.sign(
    {
      id: userId,
      role: role, //
    },
    process.env.JWT_SECRET,
    {
      expiresIn: process.env.JWT_EXPIRE || "30d",
    }
  );
};

module.exports = generateToken;
