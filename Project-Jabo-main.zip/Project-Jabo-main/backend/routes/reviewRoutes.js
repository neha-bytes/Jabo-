const express = require("express");
const router = express.Router();
const {
  createReview,
  getDriverReviews,
  getMyReviews,
  checkCanReview,
} = require("../controllers/reviewController");
const { protect } = require("../middleware/authMiddleware");

// All routes require authentication
router.use(protect);

// Create review
router.post("/", createReview);

// Get user's reviews
router.get("/my", getMyReviews);

// Check if user can review a shuttle
router.get("/check/:shuttleId", checkCanReview);

// Get reviews for a driver (public)
router.get("/driver/:driverId", getDriverReviews);

module.exports = router;








