const express = require("express");
const { createFakePayment } = require("../controllers/paymentController");

const router = express.Router();

router.post("/fake", createFakePayment);

module.exports = router;


