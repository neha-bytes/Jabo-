const express = require("express");
const router = express.Router();
const { protect, authorize } = require("../middleware/authMiddleware");
const adminController = require("../controllers/adminController");

// All these routes require admin role
router.use(protect);
router.use(authorize("admin"));

// Users
router.get("/users", adminController.getUsers);
router.get("/users/:id", adminController.getUser);
router.put("/users/:id", adminController.updateUser);
router.delete("/users/:id", adminController.deleteUser);

// Drivers
router.get("/drivers", adminController.getDrivers);
router.put("/drivers/:id/approve", adminController.approveDriver);

// Buses
router.get("/buses", adminController.getBuses);
router.get("/buses/:id", adminController.getBus);
router.post("/buses", adminController.createBus); // ← ADD THIS LINE
router.put("/buses/:id", adminController.updateBus);
router.delete("/buses/:id", adminController.deleteBus);

// Bookings
router.get("/bookings", adminController.getBookings);
router.delete("/bookings/:id", adminController.deleteBooking);

// Reviews
router.get("/reviews", adminController.getReviews);
router.delete("/reviews/:id", adminController.deleteReview);

// Complaints
router.get("/complaints", adminController.getComplaints);
router.delete("/complaints/:id", adminController.deleteComplaint);

router.get("/stats", adminController.getDashboardStats);

module.exports = router;
