const express = require("express");
const router = express.Router();
const {
  register,
  driverSignup,
  login,
  logout,
  getProfile,
  updateProfile,
  changePassword,
} = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

/**
 * Authentication Routes
 * Base URL: /api/auth
 */

// Public Routes
router.post("/register", register);
router.post("/driver-signup", driverSignup);
router.post("/login", login);

// Protected Routes (require authentication)
router.get("/me", protect, getProfile);
router.put("/profile", protect, updateProfile);
router.put("/change-password", protect, changePassword);
router.post("/logout", protect, logout);

module.exports = router;
