// ============================================
// FILE 2: routes/shuttleRoutes.js
// ============================================

const express = require("express");
const router = express.Router();
const {
  createShuttleRequest,
  getUserShuttles,
  getShuttleById,
  getShuttleMessages,
  cancelShuttle,
  getAvailableShuttles,
  getDriverShuttles,
  acceptShuttle,
  updateShuttleStatus,
  getAllShuttles,
} = require("../controllers/shuttleController");

const { protect, authorize } = require("../middleware/authMiddleware");

// USER ROUTES
router.post("/", protect, createShuttleRequest);
router.get("/my-rides", protect, getUserShuttles);
router.get("/:id/messages", protect, getShuttleMessages);
router.get("/:id", protect, getShuttleById);
router.put("/:id/cancel", protect, cancelShuttle);

// DRIVER ROUTES
router.get(
  "/driver/available",
  protect,
  authorize("driver"),
  getAvailableShuttles
);
router.get("/driver/my-rides", protect, authorize("driver"), getDriverShuttles);
router.put("/:id/accept", protect, authorize("driver"), acceptShuttle);
router.put("/:id/status", protect, authorize("driver"), updateShuttleStatus);

router.get("/debug/driver-eligibility", protect, async (req, res) => {
  try {
    const Driver = require("../models/Driver");
    const allDrivers = await Driver.find().populate("user", "name phone");

    const eligibilityReport = allDrivers.map((driver) => ({
      id: driver._id,
      name: driver.user?.name,
      vehicleType: driver.vehicleType,
      isActive: driver.isActive,
      isOnline: driver.isOnline,
      isAvailable: driver.isAvailable,
      hasLocation: !!(driver.currentLocation?.coordinates?.length === 2),
      coordinates: driver.currentLocation?.coordinates,
      lastSeenAt: driver.lastSeenAt,
      activeShuttle: driver.activeShuttle,
      socketId: driver.socketId,
    }));

    res.json({
      success: true,
      total: allDrivers.length,
      online: allDrivers.filter((d) => d.isOnline).length,
      available: allDrivers.filter((d) => d.isAvailable && d.isOnline).length,
      drivers: eligibilityReport,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Helper endpoint to manually set driver online
router.put(
  "/debug/force-driver-online/:driverId",
  protect,
  authorize("admin"),
  async (req, res) => {
    try {
      const Driver = require("../models/Driver");
      const driver = await Driver.findById(req.params.driverId);

      if (!driver) {
        return res
          .status(404)
          .json({ success: false, message: "Driver not found" });
      }

      driver.isOnline = true;
      driver.isAvailable = true;
      driver.isActive = true;
      driver.lastSeenAt = new Date();

      // Set a test location if none exists (Dhaka coordinates)
      if (!driver.currentLocation?.coordinates?.length) {
        driver.currentLocation = {
          type: "Point",
          coordinates: [90.4125, 23.8103],
        };
      }

      await driver.save();

      res.json({
        success: true,
        message: "Driver forced online",
        driver: {
          id: driver._id,
          isOnline: driver.isOnline,
          isAvailable: driver.isAvailable,
          location: driver.currentLocation,
        },
      });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ADMIN ROUTES
router.get("/admin/all", protect, authorize("admin"), getAllShuttles);

module.exports = router;
