const express = require("express");
const router = express.Router();
const { protect, authorize } = require("../middleware/authMiddleware");
const { getDriverProfile } = require("../controllers/driverController");

router.get("/me", protect, authorize("driver"), getDriverProfile);

module.exports = router;



