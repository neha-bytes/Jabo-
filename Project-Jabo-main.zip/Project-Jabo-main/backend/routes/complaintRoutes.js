const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/authMiddleware');
const {
  createComplaint,
  getUserComplaints,
  getAllComplaints,
  updateComplaintStatus,
} = require('../controllers/complaintController');

// Users can create and view their complaints
router.post('/', protect, createComplaint);
router.get('/me', protect, getUserComplaints);

// Admin routes
router.get('/', protect, authorize('admin'), getAllComplaints);
router.put('/:id', protect, authorize('admin'), updateComplaintStatus);

module.exports = router;
