const express = require("express");
const {
  createBooking,
  getBookingById,
  getPublicBookingById,
  getBookingsByEmail,
  attachShuttleDemoRequest,
  getMyBookings,
  downloadTicketPDF,
} = require("../controllers/bookingController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

// Protected route - requires authentication
router.post("/", protect, createBooking);
router.get("/by-email/:email", getBookingsByEmail);
router.get("/public/:id", getPublicBookingById);
router.get("/my", protect, getMyBookings);
router.get("/:id", protect, getBookingById);
router.post("/:id/shuttle-demo", attachShuttleDemoRequest);
router.get("/:id/ticket", protect, downloadTicketPDF);

module.exports = router;
