/**
 * Bus Routes
 * Defines all API endpoints for bus operations
 *
 * Route Structure:
 * - Public routes: Anyone can access
 * - Protected routes: Require authentication
 * - Admin routes: Require authentication + admin role
 */

const express = require("express");
const router = express.Router();

// Import controller functions
const {
  getAllBuses,
  searchBuses,
  getBusById,
  getBusesByRoute,
  createBus,
  updateBus,
  deleteBus,
  getAvailableRoutes,
  getRouteSuggestions,
} = require("../controllers/busController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Import authentication middleware (uncomment when auth is ready)
// const { protect, admin } = require('../middleware/authMiddleware');

// ============================================
// PUBLIC ROUTES (For Normal Users)
// ============================================

/**
 * GET /api/buses/search
 * Search buses by route and date
 * Query params: ?origin=Dhaka&destination=Chittagong&date=2025-11-01
 * IMPORTANT: This route must come BEFORE /:id to avoid conflict
 */
router.get("/search", searchBuses);

/**
 * GET /api/buses/routes/available
 * Get all unique routes with bus count
 * Example response: [{ origin: "Dhaka", destination: "Chittagong", busCount: 3 }]
 * IMPORTANT: This must come before /:id route
 */
router.get("/routes/available", getAvailableRoutes);

/**
 * GET /api/buses/routes/suggestions
 * Get route suggestions for autocomplete
 * Query params: ?term=Dha
 */
router.get("/routes/suggestions", getRouteSuggestions);

/**
 * GET /api/buses/route/:origin/:destination
 * Get buses by specific route
 * Example: /api/buses/route/Dhaka/Chittagong
 */
router.get("/route/:origin/:destination", getBusesByRoute);

/**
 * GET /api/buses
 * Get all active buses
 * Returns list of all buses with status 'Active'
 */
router.get("/", getAllBuses);

/**
 * GET /api/buses/:id
 * Get single bus by ID
 * Returns detailed information about a specific bus
 * IMPORTANT: This should come AFTER specific routes like /search, /routes/available
 */
router.get("/:id", getBusById);

// ============================================
// ADMIN ONLY ROUTES (Protected)
// ============================================

/**
 * POST /api/buses
 * Create new bus
 * Access: Admin only
 * Body: { busName, operatorName, coachNumber, route, fare, seats, etc. }
 *
 * TODO: Add authentication middleware
 * Current: Unprotected (for development)
 * Production: router.post('/', protect, admin, createBus);
 */
router.post("/", protect, authorize("admin"), createBus);

/**
 * PUT /api/buses/:id
 * Update bus information
 * Access: Admin only
 * Body: { any bus fields to update }
 *
 * TODO: Add authentication middleware
 * Current: Unprotected (for development)
 * Production: router.put('/:id', protect, admin, updateBus);
 */
router.put("/:id", protect, authorize("admin"), updateBus);

/**
 * DELETE /api/buses/:id
 * Delete bus from system
 * Access: Admin only
 *
 * TODO: Add authentication middleware
 * Current: Unprotected (for development)
 * Production: router.delete('/:id', protect, admin, deleteBus);
 */
router.delete("/:id", protect, authorize("admin"), deleteBus);

// ============================================
// NOTES FOR FUTURE IMPLEMENTATION
// ============================================

/**
 * When implementing authentication:
 *
 * 1. Uncomment the middleware import at the top
 * 2. Replace the three admin routes above with protected versions
 * 3. The middleware should check:
 *    - protect: User is logged in (valid JWT token)
 *    - admin: User has admin role
 *
 * Example protected route:
 * router.post('/', protect, admin, createBus);
 *
 * This means: POST /api/buses requires user to be logged in AND be an admin
 */

module.exports = router;
