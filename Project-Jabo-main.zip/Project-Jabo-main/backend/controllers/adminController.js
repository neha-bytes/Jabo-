const User = require("../models/User");
const Driver = require("../models/Driver");
const Bus = require("../models/Bus");
const Booking = require("../models/Booking");
const Review = require("../models/Review");
const Complaint = require("../models/Complaint");

/**
 * Admin Controller - provides management endpoints for admin users
 */

// ========== USERS ==========
exports.getUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password").sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: users.length, data: users });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch users",
      error: error.message,
    });
  }
};

exports.getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch user",
      error: error.message,
    });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).select("-password");
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    res
      .status(200)
      .json({ success: true, message: "User updated", data: user });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Failed to update user",
      error: error.message,
    });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, message: "User deleted" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete user",
      error: error.message,
    });
  }
};

// ========== DRIVERS ==========
exports.getDrivers = async (req, res) => {
  try {
    // Allow query param ?isVerified=true/false
    const query = {};
    if (req.query.isVerified)
      query.isVerified = req.query.isVerified === "true";

    const drivers = await Driver.find(query)
      .populate("user", "name email phone")
      .sort({ createdAt: -1 });
    res
      .status(200)
      .json({ success: true, count: drivers.length, data: drivers });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch drivers",
      error: error.message,
    });
  }
};

exports.approveDriver = async (req, res) => {
  try {
    const driver = await Driver.findById(req.params.id);
    if (!driver)
      return res
        .status(404)
        .json({ success: false, message: "Driver not found" });

    driver.isVerified = true;
    driver.verifiedAt = new Date();
    driver.verifiedBy = req.user.id;
    await driver.save();

    // Also mark the linked user as verified
    await User.findByIdAndUpdate(driver.user, { isVerified: true });

    res
      .status(200)
      .json({ success: true, message: "Driver approved", data: driver });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to approve driver",
      error: error.message,
    });
  }
};

exports.rejectDriver = async (req, res) => {
  try {
    const driver = await Driver.findByIdAndDelete(req.params.id);
    if (!driver)
      return res
        .status(404)
        .json({ success: false, message: "Driver not found" });

    res
      .status(200)
      .json({ success: true, message: "Driver request rejected and deleted" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to reject driver",
      error: error.message,
    });
  }
};

// ========== BUSES ==========
exports.createBus = async (req, res) => {
  try {
    const busData = req.body;

    // Basic validation (optional but recommended)
    const requiredFields = [
      "busName",
      "operatorName",
      "coachNumber",
      "busType",
      "route",
      "schedule",
      "fare",
    ];
    for (const field of requiredFields) {
      if (!busData[field]) {
        return res.status(400).json({
          success: false,
          message: `${field} is required`,
        });
      }
    }

    // Ensure nested objects are properly structured
    if (!busData.route.origin || !busData.route.destination) {
      return res.status(400).json({
        success: false,
        message: "Both origin and destination are required in route",
      });
    }

    if (!busData.schedule.departureTime || !busData.schedule.arrivalTime) {
      return res.status(400).json({
        success: false,
        message: "Departure and arrival times are required",
      });
    }

    if (!busData.fare.baseFare) {
      return res.status(400).json({
        success: false,
        message: "Base fare is required",
      });
    }

    // Create the bus
    const newBus = await Bus.create({
      ...busData,
      seats: {
        totalSeats: busData.seats?.totalSeats || 40,
        availableSeats: busData.seats?.totalSeats || 40,
        seatLayout: busData.seats?.seatLayout || "2x2",
        bookedSeats: [],
      },
      amenities: busData.amenities || [],
      stoppages: busData.stoppages || [],
      gpsEnabled: busData.gpsEnabled || false,
      status: busData.status || "Active",
    });

    res.status(201).json({
      success: true,
      message: "Bus created successfully",
      data: newBus,
    });
  } catch (error) {
    console.error("Error creating bus:", error);

    // Handle duplicate coach number
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Coach number already exists. It must be unique.",
      });
    }

    res.status(500).json({
      success: false,
      message: "Failed to create bus",
      error: error.message,
    });
  }
};
exports.getBuses = async (req, res) => {
  try {
    const buses = await Bus.find()
      .populate("driver", "name phone")
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: buses.length, data: buses });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch buses",
      error: error.message,
    });
  }
};

exports.getBus = async (req, res) => {
  try {
    const bus = await Bus.findById(req.params.id).populate(
      "driver",
      "name phone"
    );
    if (!bus)
      return res.status(404).json({ success: false, message: "Bus not found" });
    res.status(200).json({ success: true, data: bus });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch bus",
      error: error.message,
    });
  }
};

// ========== BUSES ==========
exports.updateBus = async (req, res) => {
  console.log("=== BUS UPDATE REQUEST ===");
  console.log("Bus ID:", req.params.id);
  console.log("Raw payload:", JSON.stringify(req.body, null, 2));

  try {
    const updates = req.body;

    // Build flat update object using dot notation for nested fields
    const updateFields = {};

    if (updates.busName !== undefined) updateFields.busName = updates.busName;
    if (updates.operatorName !== undefined)
      updateFields.operatorName = updates.operatorName;
    if (updates.busType !== undefined) updateFields.busType = updates.busType;
    if (updates.status !== undefined) updateFields.status = updates.status;
    if (updates.gpsEnabled !== undefined)
      updateFields.gpsEnabled = updates.gpsEnabled;
    if (updates.amenities !== undefined)
      updateFields.amenities = updates.amenities;
    if (updates.stoppages !== undefined)
      updateFields.stoppages = updates.stoppages;

    // Route
    if (updates.route) {
      if (updates.route.origin !== undefined)
        updateFields["route.origin"] = updates.route.origin;
      if (updates.route.destination !== undefined)
        updateFields["route.destination"] = updates.route.destination;
    }

    // Schedule
    if (updates.schedule) {
      if (updates.schedule.departureTime !== undefined)
        updateFields["schedule.departureTime"] = updates.schedule.departureTime;
      if (updates.schedule.arrivalTime !== undefined)
        updateFields["schedule.arrivalTime"] = updates.schedule.arrivalTime;
      if (updates.schedule.daysOfOperation !== undefined)
        updateFields["schedule.daysOfOperation"] =
          updates.schedule.daysOfOperation;
    }

    // Fare
    if (updates.fare) {
      if (updates.fare.baseFare !== undefined)
        updateFields["fare.baseFare"] = updates.fare.baseFare;
      if (updates.fare.currency !== undefined)
        updateFields["fare.currency"] = updates.fare.currency;
    }

    // Seats – ONLY update specific fields, never the whole object
    if (updates.seats?.totalSeats !== undefined) {
      updateFields["seats.totalSeats"] = updates.seats.totalSeats;
    }
    if (updates.seats?.seatLayout !== undefined) {
      updateFields["seats.seatLayout"] = updates.seats.seatLayout;
    }

    console.log("Final update fields:", JSON.stringify(updateFields, null, 2));

    if (Object.keys(updateFields).length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "No valid fields to update" });
    }

    const bus = await Bus.findByIdAndUpdate(
      req.params.id,
      { $set: updateFields },
      { new: true, runValidators: true }
    ).populate("driver", "name phone");

    if (!bus) {
      return res.status(404).json({ success: false, message: "Bus not found" });
    }

    console.log("Bus updated successfully:", bus._id);
    res.status(200).json({
      success: true,
      message: "Bus updated successfully",
      data: bus,
    });
  } catch (error) {
    console.error("=== BUS UPDATE FAILED ===");
    console.error("Error:", error.message);
    console.error("Full error:", error);

    res.status(400).json({
      success: false,
      message: "Failed to update bus",
      error: error.message,
      details: error.errors || null,
    });
  }
};

exports.deleteBus = async (req, res) => {
  try {
    const bus = await Bus.findByIdAndDelete(req.params.id);
    if (!bus)
      return res.status(404).json({ success: false, message: "Bus not found" });
    res
      .status(200)
      .json({ success: true, message: "Bus deleted successfully" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete bus",
      error: error.message,
    });
  }
};

// ========== BOOKINGS ==========
exports.getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("user", "name email phone")
      .populate("bus", "busName route operatorName")
      .sort({ createdAt: -1 });
    res
      .status(200)
      .json({ success: true, count: bookings.length, data: bookings });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch bookings",
      error: error.message,
    });
  }
};

exports.deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.id);
    if (!booking)
      return res
        .status(404)
        .json({ success: false, message: "Booking not found" });

    // Release seats if booking is deleted
    if (booking.bus && booking.seats) {
      await Bus.findByIdAndUpdate(booking.bus, {
        $pull: { "seats.bookedSeats": { $in: booking.seats } },
        $inc: { "seats.availableSeats": booking.seats.length },
      });
    }

    res
      .status(200)
      .json({ success: true, message: "Booking deleted successfully" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete booking",
      error: error.message,
    });
  }
};

// ========== REVIEWS ==========
exports.getReviews = async (req, res) => {
  try {
    const reviews = await Review.find()
      .populate("user", "name email")
      .populate("bus", "busName")
      .sort({ createdAt: -1 });
    res
      .status(200)
      .json({ success: true, count: reviews.length, data: reviews });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch reviews",
      error: error.message,
    });
  }
};

exports.deleteReview = async (req, res) => {
  try {
    const review = await Review.findByIdAndDelete(req.params.id);
    if (!review)
      return res
        .status(404)
        .json({ success: false, message: "Review not found" });
    res
      .status(200)
      .json({ success: true, message: "Review deleted successfully" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete review",
      error: error.message,
    });
  }
};

// ========== COMPLAINTS ==========
exports.getComplaints = async (req, res) => {
  try {
    const complaints = await Complaint.find()
      .populate("user", "name email phone")
      .sort({ createdAt: -1 });
    res
      .status(200)
      .json({ success: true, count: complaints.length, data: complaints });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch complaints",
      error: error.message,
    });
  }
};

exports.deleteComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndDelete(req.params.id);
    if (!complaint)
      return res
        .status(404)
        .json({ success: false, message: "Complaint not found" });
    res
      .status(200)
      .json({ success: true, message: "Complaint deleted successfully" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete complaint",
      error: error.message,
    });
  }
};

// ========== DASHBOARD STATS ==========
exports.getDashboardStats = async (req, res) => {
  try {
    const [
      totalUsers,
      totalDrivers,
      verifiedDrivers,
      pendingDrivers,
      totalBuses,
      activeBuses,
      totalBookings,
      confirmedBookings,
      pendingBookings,
      totalRevenue,
      totalReviews,
      avgRating,
      totalComplaints,
    ] = await Promise.all([
      User.countDocuments({ role: "user" }),
      User.countDocuments({ role: "driver" }),
      Driver.countDocuments({ isVerified: true }),
      Driver.countDocuments({ isVerified: false }),
      Bus.countDocuments(),
      Bus.countDocuments({ status: "Active" }),
      Booking.countDocuments(),
      Booking.countDocuments({ status: "confirmed" }),
      Booking.countDocuments({ status: "pending" }),
      Booking.aggregate([
        { $group: { _id: null, total: { $sum: "$totalFare" } } },
      ]),
      Review.countDocuments(),
      Review.aggregate([
        { $group: { _id: null, avgRating: { $avg: "$rating.overall" } } },
      ]),
      Complaint.countDocuments(),
    ]);

    res.status(200).json({
      success: true,
      data: {
        users: {
          total: totalUsers,
          drivers: totalDrivers,
          verifiedDrivers,
          pendingDrivers,
        },
        buses: {
          total: totalBuses,
          active: activeBuses,
        },
        bookings: {
          total: totalBookings,
          confirmed: confirmedBookings,
          pending: pendingBookings,
        },
        revenue: {
          total: totalRevenue[0]?.total || 0,
        },
        reviews: {
          total: totalReviews,
          averageRating: avgRating[0]?.avgRating || 0,
        },
        complaints: {
          total: totalComplaints,
        },
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch dashboard stats",
      error: error.message,
    });
  }
};
