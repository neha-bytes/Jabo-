const User = require("../models/User");
const Driver = require("../models/Driver");
const jwt = require("jsonwebtoken");
const generateToken = require("../utils/generateToken");

/**
 * Authentication Controller
 * Handles user registration, login, logout, and profile management
 */

/**
 * @desc    Register a new user
 * @route   POST /api/auth/register
 * @access  Public
 */
exports.register = async (req, res) => {
  try {
    const { name, email, phone, password, role, studentId } = req.body;

    // Validate required fields
    if (!name || !email || !phone || !password) {
      return res.status(400).json({
        success: false,
        message: "Please provide all required fields",
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { phone }],
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message:
          existingUser.email === email
            ? "Email already registered"
            : "Phone number already registered",
      });
    }

    // Create new user
    const user = await User.create({
      name,
      email,
      phone,
      studentId,
      password,
      role: role || "user", // Default to 'user' if not specified
    });

    // Generate JWT token
    const token = generateToken(user._id, user.role);

    // Send response
    res.status(201).json({
      success: true,
      message: "User registered successfully",
      data: {
        user: user.getPublicProfile(),
        token,
      },
    });
  } catch (error) {
    console.error("Registration Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during registration",
      error: error.message,
    });
  }
};

/**
 * @desc    Login user
 * @route   POST /api/auth/login
 * @access  Public
 */
exports.login = async (req, res) => {
  try {
    const { emailOrPhone, password } = req.body;

    // Validate required fields
    if (!emailOrPhone || !password) {
      return res.status(400).json({
        success: false,
        message: "Please provide email/phone and password",
      });
    }

    // Find user by email or phone (include password field)
    const user = await User.findOne({
      $or: [{ email: emailOrPhone }, { phone: emailOrPhone }],
    }).select("+password");

    // Check if user exists
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    // Check if account is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: "Your account has been deactivated. Please contact support.",
      });
    }

    // Verify password
    const isPasswordMatch = await user.comparePassword(password);

    if (!isPasswordMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    // Generate JWT token
    const token = generateToken(user._id, user.role);

    // Send response
    res.status(200).json({
      success: true,
      message: "Login successful",
      data: {
        user: user.getPublicProfile(),
        token,
      },
    });
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during login",
      error: error.message,
    });
  }
};

/**
 * @desc    Get current logged in user profile
 * @route   GET /api/auth/me
 * @access  Private (requires authentication)
 */
exports.getProfile = async (req, res) => {
  try {
    // req.user is set by the auth middleware
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.status(200).json({
      success: true,
      data: {
        user: user.getPublicProfile(),
      },
    });
  } catch (error) {
    console.error("Get Profile Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching profile",
      error: error.message,
    });
  }
};

/**
 * @desc    Update user profile
 * @route   PUT /api/auth/profile
 * @access  Private
 */
exports.updateProfile = async (req, res) => {
  try {
    const { name, phone, address, preferences, profileImage, studentId } =
      req.body;

    // Find user
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Update allowed fields only
    if (name) user.name = name;
    if (phone) user.phone = phone;
    if (studentId !== undefined) user.studentId = studentId;
    if (address) user.address = address;
    if (preferences) user.preferences = { ...user.preferences, ...preferences };
    if (profileImage) user.profileImage = profileImage;

    await user.save();

    res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      data: {
        user: user.getPublicProfile(),
      },
    });
  } catch (error) {
    console.error("Update Profile Error:", error);

    // Handle duplicate phone number error
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Phone number already in use",
      });
    }

    res.status(500).json({
      success: false,
      message: "Server error while updating profile",
      error: error.message,
    });
  }
};

/**
 * @desc    Change password
 * @route   PUT /api/auth/change-password
 * @access  Private
 */
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    // Validate required fields
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: "Please provide current and new password",
      });
    }

    // Validate new password length
    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: "New password must be at least 6 characters long",
      });
    }

    // Find user with password field
    const user = await User.findById(req.user.id).select("+password");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Verify current password
    const isPasswordMatch = await user.comparePassword(currentPassword);

    if (!isPasswordMatch) {
      return res.status(401).json({
        success: false,
        message: "Current password is incorrect",
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    console.error("Change Password Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while changing password",
      error: error.message,
    });
  }
};

/**
 * @desc    Logout user
 * @route   POST /api/auth/logout
 * @access  Private
 */
/**
 * @desc    Register a new driver
 * @route   POST /api/auth/driver-signup
 * @access  Public
 */
exports.driverSignup = async (req, res) => {
  try {
    const {
      // User fields
      name,
      email,
      phone,
      password,
      // Driver fields
      licenseNumber,
      licenseExpiryDate,
      nidNumber,
      vehicleType,
      vehicleRegistrationNumber,
      vehicleBrand,
      vehicleModel,
      vehicleYear,
      vehicleColor,
    } = req.body;

    // Validate required user fields
    if (!name || !email || !phone || !password) {
      return res.status(400).json({
        success: false,
        message: "Please provide all required fields",
      });
    }

    // Validate required driver fields
    if (
      !licenseNumber ||
      !licenseExpiryDate ||
      !nidNumber ||
      !vehicleType ||
      !vehicleRegistrationNumber ||
      !vehicleBrand ||
      !vehicleModel ||
      !vehicleYear ||
      !vehicleColor
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide all driver information (license, NID, vehicle details)",
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { phone }],
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message:
          existingUser.email === email
            ? "Email already registered"
            : "Phone number already registered",
      });
    }

    // Check if license number is already in use
    const existingLicense = await Driver.findOne({ licenseNumber });
    if (existingLicense) {
      return res.status(400).json({
        success: false,
        message: "License number already registered",
      });
    }

    // Check if NID is already in use
    const existingNID = await Driver.findOne({ nidNumber });
    if (existingNID) {
      return res.status(400).json({
        success: false,
        message: "NID number already registered",
      });
    }

    // Check if vehicle registration number is already in use
    const existingVehicle = await Driver.findOne({ vehicleRegistrationNumber });
    if (existingVehicle) {
      return res.status(400).json({
        success: false,
        message: "Vehicle registration number already registered",
      });
    }

    // Create new user with driver role
    const user = await User.create({
      name,
      email,
      phone,
      password,
      role: "driver",
    });

    // Create driver profile
    const driver = await Driver.create({
      user: user._id,
      licenseNumber,
      licenseExpiryDate,
      nidNumber,
      vehicleType,
      vehicleRegistrationNumber,
      vehicleBrand,
      vehicleModel,
      vehicleYear,
      vehicleColor,
    });

    // Generate JWT token
    const token = generateToken(user._id, user.role);

    // Send response
    res.status(201).json({
      success: true,
      message: "Driver registered successfully",
      data: {
        user: user.getPublicProfile(),
        driver: driver.getPublicProfile(),
        token,
      },
    });
  } catch (error) {
    console.error("Driver Registration Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during driver registration",
      error: error.message,
    });
  }
};

/**
 * @desc    Logout user
 * @route   POST /api/auth/logout
 * @access  Private
 */
exports.logout = async (req, res) => {
  try {
    // Since we're using JWT, we don't need to do anything server-side
    // Client should remove the token from storage

    res.status(200).json({
      success: true,
      message: "Logged out successfully",
    });
  } catch (error) {
    console.error("Logout Error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during logout",
      error: error.message,
    });
  }
};
