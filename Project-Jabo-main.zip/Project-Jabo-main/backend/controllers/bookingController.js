const axios = require("axios");
const Booking = require("../models/Booking");
const Bus = require("../models/Bus");
const { sendBookingConfirmation } = require("../utils/emailService");

/**
 * Create a new bus booking with optional shuttle demo request.
 * Route: POST /api/bookings
 * Access: Public (until auth is ready)
 */
const createBooking = async (req, res) => {
  let booking;
  let bus;
  let requestedSeats = [];
  let busLocked = false;

  try {
    const {
      busId,
      journeyDate,
      seats,
      contactInfo,
      passengers = [],
      payment = {},
      shuttleRequest,
    } = req.body;

    if (!busId || !journeyDate || !seats?.length || !contactInfo) {
      return res.status(400).json({
        success: false,
        message: "Bus, journey date, seats and contact info are required",
      });
    }

    bus = await Bus.findById(busId);
    if (!bus) {
      return res.status(404).json({
        success: false,
        message: "Bus not found",
      });
    }

    requestedSeats = seats.map((seat) => seat.toUpperCase());

    // Normalize journeyDate to start of day for accurate date comparison
    const journeyDateObj = new Date(journeyDate);
    const journeyDateStart = new Date(journeyDateObj);
    journeyDateStart.setHours(0, 0, 0, 0);
    const journeyDateEnd = new Date(journeyDateObj);
    journeyDateEnd.setHours(23, 59, 59, 999);

    // Check for existing bookings for this bus on this specific date
    const existingBookings = await Booking.find({
      bus: busId,
      journeyDate: {
        $gte: journeyDateStart,
        $lte: journeyDateEnd,
      },
      status: { $in: ["pending", "confirmed"] },
    });

    // Get all seats already booked for this specific date
    const bookedSeatsForDate = new Set();
    existingBookings.forEach((booking) => {
      booking.seats.forEach((seat) =>
        bookedSeatsForDate.add(seat.toUpperCase())
      );
    });

    // Check if any requested seats are already booked for this date
    const alreadyBooked = requestedSeats.filter((seat) =>
      bookedSeatsForDate.has(seat)
    );

    if (alreadyBooked.length > 0) {
      return res.status(409).json({
        success: false,
        message: `Seats already booked for this date: ${alreadyBooked.join(
          ", "
        )}`,
      });
    }

    // Check if total requested seats exceed bus capacity
    if (requestedSeats.length > bus.seats.totalSeats) {
      return res.status(400).json({
        success: false,
        message: "Not enough seats available",
      });
    }

    // Check if requested seats would exceed available capacity for this date
    const totalBookedForDate = bookedSeatsForDate.size;
    if (totalBookedForDate + requestedSeats.length > bus.seats.totalSeats) {
      return res.status(400).json({
        success: false,
        message: "Not enough seats available for this date",
      });
    }

    const totalFare = requestedSeats.length * bus.fare.baseFare;

    // Pre-fill contact info from authenticated user if not provided
    const finalContactInfo = {
      fullName: contactInfo.fullName || req.user.name || "",
      email: contactInfo.email || req.user.email || "",
      phone: contactInfo.phone || req.user.phone || "",
    };

    const bookingPayload = {
      user: req.user.id, // Now required since route is protected
      bus: bus._id,
      journeyDate: journeyDateStart,
      seats: requestedSeats,
      totalFare,
      contactInfo: finalContactInfo,
      status: "confirmed", // Set status to confirmed after booking completion
      passengers:
        passengers.length > 0
          ? passengers
          : requestedSeats.map((seat, index) => ({
              fullName: `${finalContactInfo.fullName || "Passenger"} ${
                index + 1
              }`,
              email: finalContactInfo.email,
              phone: finalContactInfo.phone,
            })),
      payment: {
        method: payment.method || "cash",
        status: payment.status || "pending",
        transactionId: payment.transactionId,
      },
      meta: {
        source: req.headers["x-client-app"] || "web",
        initiatedBy: "user",
      },
    };

    booking = new Booking(bookingPayload);
    await booking.save();

    // Populate bus data for email
    const populatedBooking = await Booking.findById(booking._id).populate(
      "bus"
    );

    // Send confirmation email (non-blocking)
    sendBookingConfirmation(
      populatedBooking.toObject(),
      populatedBooking.bus.toObject(),
      finalContactInfo.email
    ).catch((emailError) => {
      console.error("Failed to send booking confirmation email:", emailError);
      // Don't fail the booking if email fails
    });

    if (shuttleRequest?.enabled) {
      const demoResponse = await triggerDemoShuttleRequest({
        bookingId: booking._id,
        bus,
        journeyDate,
        contactInfo,
        shuttleRequest,
      });

      booking.shuttleService = {
        requested: true,
        status: "pending_demo",
        vehicleType: shuttleRequest.vehicleType || "Car",
        pickup: shuttleRequest.pickup,
        dropoff: shuttleRequest.dropoff,
        scheduledTime: shuttleRequest.scheduledTime,
        notes: shuttleRequest.notes,
        demoResponse,
      };

      await booking.save();
    }

    res.status(201).json({
      success: true,
      message: "Booking created successfully",
      data: booking,
    });
  } catch (error) {
    console.error("Error creating booking:", error);

    // If booking was created but there's an error, delete it
    if (booking && booking._id) {
      try {
        await Booking.findByIdAndDelete(booking._id);
      } catch (rollbackError) {
        console.error("Failed to rollback booking:", rollbackError);
      }
    }

    res.status(500).json({
      success: false,
      message: "Failed to create booking",
      error: error.message,
    });
  }
};

/**
 * Get booking by ID
 * Route: GET /api/bookings/:id
 */
const getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate("bus")
      .populate("user", "name email");

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    res.status(200).json({
      success: true,
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch booking",
      error: error.message,
    });
  }
};

const getPublicBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate(
      "bus",
      "busName operatorName route schedule"
    );

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    res.status(200).json({
      success: true,
      data: {
        _id: booking._id,
        bus: booking.bus,
        journeyDate: booking.journeyDate,
        seats: booking.seats,
        contactInfo: booking.contactInfo,
        shuttleService: booking.shuttleService,
        payment: booking.payment,
        totalFare: booking.totalFare,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch booking",
      error: error.message,
    });
  }
};

/**
 * Get bookings by email (temporary helper until auth ready)
 * Route: GET /api/bookings/by-email/:email
 */
const getBookingsByEmail = async (req, res) => {
  try {
    const bookings = await Booking.find({
      "contactInfo.email": req.params.email,
    })
      .sort({ createdAt: -1 })
      .populate("bus");

    res.status(200).json({
      success: true,
      count: bookings.length,
      data: bookings,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch bookings",
      error: error.message,
    });
  }
};

/**
 * Attach or update a demo shuttle request
 * Route: POST /api/bookings/:id/shuttle-demo
 */
const attachShuttleDemoRequest = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate("bus");

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    const shuttleRequest = req.body;
    if (!shuttleRequest?.pickup || !shuttleRequest?.dropoff) {
      return res.status(400).json({
        success: false,
        message: "Pickup and dropoff details are required",
      });
    }

    const demoResponse = await triggerDemoShuttleRequest({
      bookingId: booking._id,
      bus: booking.bus,
      journeyDate: booking.journeyDate,
      contactInfo: booking.contactInfo,
      shuttleRequest,
    });

    booking.shuttleService = {
      requested: true,
      status: "pending_demo",
      vehicleType: shuttleRequest.vehicleType || "Car",
      pickup: shuttleRequest.pickup,
      dropoff: shuttleRequest.dropoff,
      scheduledTime: shuttleRequest.scheduledTime,
      notes: shuttleRequest.notes,
      demoResponse,
    };

    await booking.save();

    res.status(200).json({
      success: true,
      message: "Demo shuttle request attached",
      data: booking,
    });
  } catch (error) {
    console.error("Error attaching shuttle demo:", error);
    res.status(500).json({
      success: false,
      message: "Failed to attach shuttle demo request",
      error: error.message,
    });
  }
};

/**
 * Simulates a call to the shuttle microservice.
 * You can later replace this with a real HTTP call.
 */
const getMyBookings = async (req, res) => {
  try {
    const { limit = 25, status } = req.query;

    const query = { user: req.user.id };
    if (status) {
      query.status = status;
    }

    const parsedLimit = Math.min(parseInt(limit, 10) || 25, 50);

    const bookings = await Booking.find(query)
      .populate(
        "bus",
        "busName route coachNumber operatorName schedule currentLocation"
      )
      .sort({ journeyDate: -1 })
      .limit(parsedLimit);

    const now = new Date();
    const activeBooking = bookings.find(
      (booking) =>
        ["pending", "confirmed"].includes(booking.status) &&
        new Date(booking.journeyDate) >= now
    );

    const stats = bookings.reduce(
      (acc, booking) => {
        if (["pending", "confirmed"].includes(booking.status))
          acc.upcoming += 1;
        if (booking.status === "completed") acc.completed += 1;
        if (booking.status === "cancelled") acc.cancelled += 1;
        acc.total += 1;
        return acc;
      },
      { total: 0, upcoming: 0, completed: 0, cancelled: 0 }
    );

    res.status(200).json({
      success: true,
      data: {
        bookings,
        activeBooking: activeBooking || null,
        stats,
      },
    });
  } catch (error) {
    console.error("Error fetching user bookings:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch bookings",
      error: error.message,
    });
  }
};

const triggerDemoShuttleRequest = async ({
  bookingId,
  bus,
  journeyDate,
  contactInfo,
  shuttleRequest,
}) => {
  const payload = {
    referenceId: bookingId?.toString() || `demo-${Date.now()}`,
    vehicleType: shuttleRequest.vehicleType || "Car",
    pickup: shuttleRequest.pickup,
    dropoff: shuttleRequest.dropoff,
    scheduledTime: shuttleRequest.scheduledTime || journeyDate,
    passengerName: contactInfo.fullName,
    passengerPhone: contactInfo.phone,
    notes: shuttleRequest.notes,
  };

  const demoUrl =
    process.env.SHUTTLE_DEMO_WEBHOOK ||
    "https://demo-shuttle-service.jabo.local/api/requests";

  try {
    // In reality this endpoint does not exist, but we keep the call
    // so the integration can be swapped easily once ready.
    const response = await axios.post(demoUrl, payload, {
      timeout: 2000,
    });
    return {
      status: "forwarded",
      target: demoUrl,
      payload,
      echo: response.data,
    };
  } catch (error) {
    return {
      status: "simulated",
      target: demoUrl,
      payload,
      message:
        "Shuttle service not reachable during demo. Payload captured locally.",
    };
  }
};
// Add this import at the top with others
const { generateTicketPDF } = require("../utils/pdfService");

const downloadTicketPDF = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate({
        path: "bus",
        select: "busName operatorName coachNumber busType route schedule fare",
      })
      .populate("user", "name email");

    if (!booking) {
      return res
        .status(404)
        .json({ success: false, message: "Booking not found" });
    }

    // DEBUG: Log the IDs
    console.log("=== PDF Download Debug ===");
    console.log("Booking User ID:", booking.user?._id?.toString());
    console.log("Request User ID:", req.user.id.toString());
    console.log(
      "Match:",
      booking.user?._id?.toString() === req.user.id.toString()
    );
    console.log("========================");

    // Security: Only owner can download
    if (!booking.user) {
      return res.status(403).json({
        success: false,
        message: "This booking is not associated with a user account",
      });
    }

    // Convert BOTH to strings for comparison
    if (booking.user._id.toString() !== req.user.id.toString()) {
      return res.status(403).json({
        success: false,
        message: "Access denied - You can only download your own tickets",
      });
    }

    if (booking.status !== "confirmed") {
      return res
        .status(400)
        .json({ success: false, message: "Ticket not confirmed yet" });
    }

    const pdfBuffer = await generateTicketPDF(
      booking,
      booking.bus,
      booking.user || { name: booking.contactInfo.fullName }
    );

    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Jabo_Ticket_${booking._id}.pdf"`,
      "Content-Length": pdfBuffer.length,
      "Cache-Control": "private, max-age=0",
    });

    res.send(pdfBuffer);
  } catch (error) {
    console.error("PDF Generation Failed:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to generate ticket PDF" });
  }
};

module.exports = {
  createBooking,
  getBookingById,
  getPublicBookingById,
  getBookingsByEmail,
  attachShuttleDemoRequest,
  getMyBookings,
  downloadTicketPDF,
};
