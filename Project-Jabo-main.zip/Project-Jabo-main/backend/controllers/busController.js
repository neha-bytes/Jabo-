/**
 * Bus Controller
 * Handles all bus-related operations
 *
 * PUBLIC ROUTES (Anyone can access):
 * - getAllBuses: Get list of all active buses
 * - searchBuses: Search buses by route and date
 * - getBusById: Get details of a specific bus
 * - getBusesByRoute: Get buses for a specific route
 * - getAvailableRoutes: Get all available routes
 *
 * ADMIN ONLY ROUTES:
 * - createBus: Add new bus to system
 * - updateBus: Update bus information
 * - deleteBus: Remove bus from system
 */

const Bus = require("../models/Bus");
const Booking = require("../models/Booking");

// ============================================
// PUBLIC CONTROLLERS (For Normal Users)
// ============================================

/**
 * @desc    Get all active buses
 * @route   GET /api/buses?date=2025-01-15 (optional date parameter)
 * @access  Public
 * @purpose Users can view all available buses with date-specific seat availability
 */
const getAllBuses = async (req, res) => {
  try {
    // Find only active buses and populate driver info
    const buses = await Bus.find({ status: "Active" })
      .populate("driver", "name phone") // Get driver name and phone
      .sort({ "schedule.departureTime": 1 }); // Sort by departure time

    // Convert buses to plain objects to allow modification
    const busesData = buses.map(bus => bus.toObject());

    // If date is provided, calculate date-specific seat availability
    if (req.query.date) {
      const journeyDateObj = new Date(req.query.date);
      const journeyDateStart = new Date(journeyDateObj);
      journeyDateStart.setHours(0, 0, 0, 0);
      const journeyDateEnd = new Date(journeyDateObj);
      journeyDateEnd.setHours(23, 59, 59, 999);

      // Get all bookings for this date across all buses
      const allBookings = await Booking.find({
        journeyDate: {
          $gte: journeyDateStart,
          $lte: journeyDateEnd,
        },
        status: { $in: ["pending", "confirmed"] },
      });

      // Group booked seats by bus ID
      const bookedSeatsByBus = {};
      allBookings.forEach((booking) => {
        const busId = booking.bus.toString();
        if (!bookedSeatsByBus[busId]) {
          bookedSeatsByBus[busId] = new Set();
        }
        booking.seats.forEach((seat) => bookedSeatsByBus[busId].add(seat.toUpperCase()));
      });

      // Add date-specific seat info to each bus
      busesData.forEach((bus) => {
        const busId = bus._id.toString();
        const bookedSeats = bookedSeatsByBus[busId] || new Set();
        bus.bookedSeatsForDate = Array.from(bookedSeats);
        bus.availableSeatsForDate = bus.seats.totalSeats - bookedSeats.size;
      });
    }

    // Return success response with bus data
    res.status(200).json({
      success: true,
      count: busesData.length,
      data: busesData,
    });
  } catch (error) {
    // Handle any errors
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

/**
 * @desc    Search buses by route and date
 * @route   GET /api/buses/search?origin=Dhaka&destination=Chittagong&date=2025-11-01
 * @access  Public
 * @purpose Main search functionality for users to find buses
 */
const searchBuses = async (req, res) => {
  try {
    // Extract search parameters from query string
    const { origin, destination, date } = req.query;

    // Validate that required fields are provided
    if (!origin || !destination) {
      return res.status(400).json({
        success: false,
        message: "Please provide origin and destination",
      });
    }

    // Build MongoDB query object
    const query = {
      "route.origin": { $regex: origin, $options: "i" }, // Case-insensitive search
      "route.destination": { $regex: destination, $options: "i" },
      status: "Active", // Only show active buses
      "seats.availableSeats": { $gt: 0 }, // Only buses with available seats
    };

    // If date is provided, filter by day of week
    // (e.g., if user selects a Monday, only show buses that operate on Monday)
    if (date) {
      const searchDate = new Date(date);
      const dayName = searchDate.toLocaleDateString("en-US", {
        weekday: "long",
      });
      query["schedule.daysOfOperation"] = dayName;
    }

    // Execute search query
    const buses = await Bus.find(query)
      .populate("driver", "name phone")
      .sort({ "schedule.departureTime": 1 }); // Sort by earliest departure

    // Convert buses to plain objects to allow modification
    const busesData = buses.map(bus => bus.toObject());

    // If date is provided, calculate date-specific seat availability
    if (date) {
      const journeyDateObj = new Date(date);
      const journeyDateStart = new Date(journeyDateObj);
      journeyDateStart.setHours(0, 0, 0, 0);
      const journeyDateEnd = new Date(journeyDateObj);
      journeyDateEnd.setHours(23, 59, 59, 999);

      // Get all bookings for this date for the searched buses
      const busIds = busesData.map(bus => bus._id);
      const allBookings = await Booking.find({
        bus: { $in: busIds },
        journeyDate: {
          $gte: journeyDateStart,
          $lte: journeyDateEnd,
        },
        status: { $in: ["pending", "confirmed"] },
      });

      // Group booked seats by bus ID
      const bookedSeatsByBus = {};
      allBookings.forEach((booking) => {
        const busId = booking.bus.toString();
        if (!bookedSeatsByBus[busId]) {
          bookedSeatsByBus[busId] = new Set();
        }
        booking.seats.forEach((seat) => bookedSeatsByBus[busId].add(seat.toUpperCase()));
      });

      // Add date-specific seat info to each bus
      busesData.forEach((bus) => {
        const busId = bus._id.toString();
        const bookedSeats = bookedSeatsByBus[busId] || new Set();
        bus.bookedSeatsForDate = Array.from(bookedSeats);
        bus.availableSeatsForDate = bus.seats.totalSeats - bookedSeats.size;
      });
    }

    // Return search results
    res.status(200).json({
      success: true,
      count: busesData.length,
      data: busesData,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error searching buses",
      error: error.message,
    });
  }
};

/**
 * @desc    Get single bus by ID
 * @route   GET /api/buses/:id?date=2025-01-15 (optional date parameter)
 * @access  Public
 * @purpose Users can view detailed information of a specific bus
 * @note    If date is provided, returns booked seats for that specific date
 */
const getBusById = async (req, res) => {
  try {
    // Find bus by MongoDB _id
    const bus = await Bus.findById(req.params.id).populate(
      "driver",
      "name phone rating"
    ); // Include driver details

    // Check if bus exists
    if (!bus) {
      return res.status(404).json({
        success: false,
        message: "Bus not found",
      });
    }

    // Convert bus to plain object to allow modification
    const busData = bus.toObject();

    // If date is provided, get booked seats for that specific date
    if (req.query.date) {
      const journeyDateObj = new Date(req.query.date);
      const journeyDateStart = new Date(journeyDateObj);
      journeyDateStart.setHours(0, 0, 0, 0);
      const journeyDateEnd = new Date(journeyDateObj);
      journeyDateEnd.setHours(23, 59, 59, 999);

      // Find existing bookings for this bus on this specific date
      const existingBookings = await Booking.find({
        bus: bus._id,
        journeyDate: {
          $gte: journeyDateStart,
          $lte: journeyDateEnd,
        },
        status: { $in: ["pending", "confirmed"] },
      });

      // Get all seats already booked for this specific date
      const bookedSeatsForDate = new Set();
      existingBookings.forEach((booking) => {
        booking.seats.forEach((seat) => bookedSeatsForDate.add(seat.toUpperCase()));
      });

      // Add booked seats for this date to the response
      busData.bookedSeatsForDate = Array.from(bookedSeatsForDate);
      busData.availableSeatsForDate = bus.seats.totalSeats - bookedSeatsForDate.size;
    }

    // Return bus data
    res.status(200).json({
      success: true,
      data: busData,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching bus",
      error: error.message,
    });
  }
};

/**
 * @desc    Get buses by specific route
 * @route   GET /api/buses/route/:origin/:destination
 * @access  Public
 * @purpose Alternative way to search buses by route without date
 */
const getBusesByRoute = async (req, res) => {
  try {
    const { origin, destination } = req.params;

    // Find all active buses for this route
    const buses = await Bus.find({
      "route.origin": { $regex: origin, $options: "i" },
      "route.destination": { $regex: destination, $options: "i" },
      status: "Active",
    })
      .populate("driver", "name phone")
      .sort({ "schedule.departureTime": 1 });

    res.status(200).json({
      success: true,
      count: buses.length,
      data: buses,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching buses",
      error: error.message,
    });
  }
};

/**
 * @desc    Get all available routes (unique origin-destination pairs)
 * @route   GET /api/buses/routes/available
 * @access  Public
 * @purpose Users can see all available routes in the system
 * @note    Uses MongoDB aggregation to get unique routes
 */
const getAvailableRoutes = async (req, res) => {
  try {
    // MongoDB aggregation pipeline to get unique routes
    const routes = await Bus.aggregate([
      // Step 1: Only consider active buses
      { $match: { status: "Active" } },

      // Step 2: Group by origin-destination pair
      {
        $group: {
          _id: {
            origin: "$route.origin",
            destination: "$route.destination",
          },
          count: { $sum: 1 }, // Count buses on this route
        },
      },

      // Step 3: Format the output
      {
        $project: {
          _id: 0,
          origin: "$_id.origin",
          destination: "$_id.destination",
          busCount: "$count",
        },
      },
    ]);

    res.status(200).json({
      success: true,
      count: routes.length,
      data: routes,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching routes",
      error: error.message,
    });
  }
};

/**
 * @desc    Get route suggestions for autocomplete
 * @route   GET /api/buses/routes/suggestions?term=Dha
 * @access  Public
 * @purpose Provide autocomplete suggestions for origin/destination fields
 */
const getRouteSuggestions = async (req, res) => {
  try {
    const { term } = req.query;
    if (!term) {
      return res.status(200).json({
        success: true,
        data: [],
      });
    }

    const regex = new RegExp(`^${term}`, "i"); // Case-insensitive, starts with term

    // Find unique origins
    const origins = await Bus.distinct("route.origin", {
      "route.origin": regex,
      status: "Active",
    });

    // Find unique destinations
    const destinations = await Bus.distinct("route.destination", {
      "route.destination": regex,
      status: "Active",
    });

    // Combine and get unique values
    const suggestions = [...new Set([...origins, ...destinations])];

    res.status(200).json({
      success: true,
      data: suggestions.sort(), // Sort alphabetically
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching suggestions",
      error: error.message,
    });
  }
};

// ============================================
// ADMIN ONLY CONTROLLERS
// ============================================

/**
 * @desc    Create new bus
 * @route   POST /api/buses
 * @access  Private/Admin
 * @purpose Admin can add new buses to the system
 * @body    All bus details (busName, operatorName, route, etc.)
 */
const createBus = async (req, res) => {
  try {
    // Create new bus with data from request body
    const bus = await Bus.create(req.body);

    // Return created bus
    res.status(201).json({
      success: true,
      message: "Bus created successfully",
      data: bus,
    });
  } catch (error) {
    // Handle validation errors
    res.status(400).json({
      success: false,
      message: "Error creating bus",
      error: error.message,
    });
  }
};

/**
 * @desc    Update bus information
 * @route   PUT /api/buses/:id
 * @access  Private/Admin
 * @purpose Admin can update bus details (schedule, fare, status, etc.)
 */
const updateBus = async (req, res) => {
  try {
    // Find bus by ID and update with new data
    const bus = await Bus.findByIdAndUpdate(req.params.id, req.body, {
      new: true, // Return updated document
      runValidators: true, // Run model validations
    });

    // Check if bus exists
    if (!bus) {
      return res.status(404).json({
        success: false,
        message: "Bus not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Bus updated successfully",
      data: bus,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Error updating bus",
      error: error.message,
    });
  }
};

/**
 * @desc    Delete bus
 * @route   DELETE /api/buses/:id
 * @access  Private/Admin
 * @purpose Admin can remove buses from system
 * @note    Consider soft delete (status: 'Inactive') instead of hard delete
 */
const deleteBus = async (req, res) => {
  try {
    // Find and delete bus
    const bus = await Bus.findByIdAndDelete(req.params.id);

    if (!bus) {
      return res.status(404).json({
        success: false,
        message: "Bus not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Bus deleted successfully",
      data: null,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error deleting bus",
      error: error.message,
    });
  }
};

// Export all controller functions
module.exports = {
  // Public controllers (for normal users)
  getAllBuses,
  searchBuses,
  getBusById,
  getBusesByRoute,
  getAvailableRoutes,
  getRouteSuggestions,

  // Admin controllers
  createBus,
  updateBus,
  deleteBus,
};
