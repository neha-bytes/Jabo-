const Payment = require("../models/Payment");
const Booking = require("../models/Booking");
const Shuttle = require("../models/Shuttle");

const formatPaymentType = (type = "") =>
  type.charAt(0).toUpperCase() + type.slice(1).toLowerCase();

const createFakePayment = async (req, res) => {
  try {
    let { paymentType, relatedId, method = "bKash", amount, description } =
      req.body;

    paymentType = formatPaymentType(paymentType);

    if (!["Booking", "Shuttle"].includes(paymentType)) {
      return res.status(400).json({
        success: false,
        message: "paymentType must be either 'Booking' or 'Shuttle'",
      });
    }

    if (!relatedId || !amount?.subtotal || !amount?.total) {
      return res.status(400).json({
        success: false,
        message: "relatedId and amount (subtotal & total) are required",
      });
    }

    const Model = paymentType === "Booking" ? Booking : Shuttle;
    const relatedDoc = await Model.findById(relatedId).populate(
      paymentType === "Shuttle" ? "booking" : ""
    );

    if (!relatedDoc) {
      return res.status(404).json({
        success: false,
        message: `${paymentType} not found`,
      });
    }

    const customer =
      paymentType === "Booking"
        ? relatedDoc.contactInfo
        : {
            fullName:
              relatedDoc.pickup?.contactName ||
              relatedDoc.booking?.contactInfo?.fullName,
            email: relatedDoc.booking?.contactInfo?.email,
            phone:
              relatedDoc.pickup?.contactPhone ||
              relatedDoc.booking?.contactInfo?.phone,
          };

    const payment = await Payment.create({
      user: relatedDoc.user || null,
      paymentType,
      relatedId,
      method,
      amount,
      status: "pending",
      description:
        description ||
        `Payment for ${paymentType.toLowerCase()} ${relatedId.toString()}`,
      customerInfo: {
        name: customer?.fullName,
        email: customer?.email,
        phone: customer?.phone,
      },
    });

    await payment.markAsCompleted();

    if (paymentType === "Booking") {
      relatedDoc.payment = {
        method,
        status: "paid",
        transactionId: payment.gateway.transactionId,
        paidAt: payment.completedAt,
      };
      // Update booking status to confirmed when payment is successful
      relatedDoc.status = "confirmed";
    } else {
      relatedDoc.payment = {
        method,
        status: "completed",
        transactionId: payment.gateway.transactionId,
        paidAt: payment.completedAt,
      };
    }

    await relatedDoc.save();

    res.status(201).json({
      success: true,
      message: "Fake payment processed successfully",
      data: payment,
      related: relatedDoc,
    });
  } catch (error) {
    console.error("Error processing fake payment:", error);
    res.status(500).json({
      success: false,
      message: "Failed to process fake payment",
      error: error.message,
    });
  }
};

module.exports = {
  createFakePayment,
};


