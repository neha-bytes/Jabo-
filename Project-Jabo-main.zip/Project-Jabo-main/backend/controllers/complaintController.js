const Complaint = require('../models/Complaint');

exports.createComplaint = async (req, res) => {
  try {
    const { subject, message } = req.body;
    if (!subject || !message) {
      return res.status(400).json({ success: false, message: 'Subject and message are required' });
    }

    const complaint = await Complaint.create({ user: req.user.id, subject, message });

    res.status(201).json({ success: true, message: 'Complaint submitted', data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to submit complaint', error: error.message });
  }
};

exports.getUserComplaints = async (req, res) => {
  try {
    const complaints = await Complaint.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: complaints.length, data: complaints });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch complaints', error: error.message });
  }
};

// Admin functions
exports.getAllComplaints = async (req, res) => {
  try {
    const complaints = await Complaint.find().populate('user', 'name email phone').sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: complaints.length, data: complaints });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch complaints', error: error.message });
  }
};

exports.updateComplaintStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, response } = req.body;

    const complaint = await Complaint.findById(id);
    if (!complaint) return res.status(404).json({ success: false, message: 'Complaint not found' });

    if (status) complaint.status = status;
    if (response) {
      complaint.response = {
        text: response,
        respondedBy: req.user.id,
        respondedAt: new Date(),
      };
    }

    await complaint.save();
    res.status(200).json({ success: true, message: 'Complaint updated', data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update complaint', error: error.message });
  }
};
