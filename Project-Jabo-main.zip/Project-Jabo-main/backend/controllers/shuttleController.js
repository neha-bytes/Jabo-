// ============================================
// FILE 1: controllers/shuttleController.js
// Updated to work with your existing Driver model
// ============================================

const Shuttle = require("../models/Shuttle");
const Booking = require("../models/Booking");
const Driver = require("../models/Driver");
const ShuttleMessage = require("../models/ShuttleMessage");
//Fix 1: Added missing imports
const {
  emitToDriver,
  emitToUser,
  emitToShuttleRoom,
  getOnlineDrivers,
} = require("../socket");

const MIN_LEAD_MINUTES = 30;
const MAX_LEAD_MINUTES = 120;
const MAX_PICKUP_DISTANCE_KM = 10;
const ACTIVE_STATUSES = [
  "pending",
  "accepted",
  "on_the_way",
  "arrived",
  "started",
];

/**
 * Shuttle Controller
 * Handles all shuttle-related operations
 */

// ============================================
// USER CONTROLLERS
// ============================================

/**
 * Helper to parse 12-hour time format (e.g., "03:50 PM", "06:00 AM")
 */
function parseTime12Hour(timeStr) {
  if (!timeStr) return null;

  const trimmed = timeStr.trim().toUpperCase();
  const match = trimmed.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/);

  if (!match) {
    // Try 24-hour format as fallback
    const parts = trimmed.split(":");
    if (parts.length >= 2) {
      const hours = parseInt(parts[0], 10);
      const minutes = parseInt(parts[1], 10);
      if (!isNaN(hours) && !isNaN(minutes)) {
        return { hours, minutes };
      }
    }
    return null;
  }

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3];

  if (isNaN(hours) || isNaN(minutes)) return null;

  // Convert to 24-hour format
  if (period === "PM" && hours !== 12) {
    hours += 12;
  } else if (period === "AM" && hours === 12) {
    hours = 0;
  }

  return { hours, minutes };
}

/**
 * @desc    Create new shuttle request (called after booking completion)
 * @route   POST /api/shuttles
 * @access  Private
 */
/**
 * @desc    Create new shuttle request (called after booking completion)
 * @route   POST /api/shuttles
 * @access  Private
 */
const createShuttleRequest = async (req, res) => {
  try {
    console.log("🚀 ========== CREATE SHUTTLE REQUEST ==========");
    console.log("📥 Request body:", JSON.stringify(req.body, null, 2));

    const {
      vehicleType,
      pickup,
      dropoff,
      scheduledTime,
      specialRequests,
      bookingId,
    } = req.body;

    // Validation: Check required fields
    if (!bookingId) {
      console.log("❌ Missing bookingId");
      return res.status(400).json({
        success: false,
        message: "bookingId is required for shuttle requests",
      });
    }

    if (
      !vehicleType ||
      !pickup?.address ||
      !pickup?.coordinates ||
      !dropoff?.address ||
      !scheduledTime
    ) {
      console.log("❌ Missing required fields");
      return res.status(400).json({
        success: false,
        message: "Please provide vehicle type, pickup/drop-off and time",
      });
    }

    // Fetch booking with populated bus data
    console.log("📦 Fetching booking:", bookingId);
    const booking = await Booking.findById(bookingId).populate("bus");

    if (!booking) {
      console.log("❌ Booking not found");
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }

    console.log("✅ Booking found:", {
      bookingId: booking._id,
      journeyDate: booking.journeyDate,
      busName: booking.bus?.busName,
      busDepartureTime: booking.bus?.schedule?.departureTime,
    });

    // Authorization check
    const bookingUserId = booking.user ? booking.user.toString() : null;
    const currentUserId = req.user?.id?.toString();

    if (
      bookingUserId &&
      bookingUserId !== currentUserId &&
      req.user.role !== "admin"
    ) {
      console.log("❌ Unauthorized access");
      return res.status(403).json({
        success: false,
        message: "You are not allowed to request shuttle for this booking",
      });
    }

    // Set user on booking if missing (for legacy bookings)
    if (!booking.user && req.user?.id) {
      booking.user = req.user.id;
      await booking.save();
    }

    // Parse scheduled time (received as UTC ISO string from frontend)
    console.log("⏰ Received scheduledTime (UTC ISO):", scheduledTime);
    const scheduled = new Date(scheduledTime);
    console.log("📅 Scheduled pickup (Date object):", scheduled.toISOString());

    if (Number.isNaN(scheduled.getTime())) {
      console.log("❌ Invalid scheduled time");
      return res.status(400).json({
        success: false,
        message: "Invalid scheduled time",
      });
    }

    // =============================================
    // CLEAN: Get bus departure time using the model method
    // =============================================
    console.log("🚌 ========== BUS DEPARTURE CALCULATION ==========");

    const busDeparture = booking.getBusDepartureTime();

    if (!busDeparture) {
      console.log("❌ Could not determine bus departure time");
      return res.status(400).json({
        success: false,
        message: "Bus departure time information is missing or invalid",
      });
    }

    console.log("🚌 Bus departure (UTC):", busDeparture.toISOString());
    console.log(
      "🚌 Bus departure (Local):",
      busDeparture.toLocaleString("en-US", { timeZone: "Asia/Dhaka" })
    );

    // Validation: Check if bus has already departed
    const now = new Date();
    if (busDeparture <= now) {
      console.log("❌ Bus already departed");
      return res.status(400).json({
        success: false,
        message: "Cannot request shuttle after bus departure time",
      });
    }

    // Calculate time difference (both times now in correct UTC)
    const diffMinutes = (busDeparture - scheduled) / 60000;
    const scheduledFromNow = (scheduled - now) / 60000;

    console.log("⏱️ ========== TIME VALIDATION ==========");
    console.log("Current time (UTC):", now.toISOString());
    console.log("Scheduled pickup (UTC):", scheduled.toISOString());
    console.log("Bus departure (UTC):", busDeparture.toISOString());
    console.log("Minutes from now to pickup:", Math.round(scheduledFromNow));
    console.log("Minutes from pickup to departure:", Math.round(diffMinutes));

    // Validation: Scheduled time must be in future
    if (scheduled < now) {
      console.log("❌ VALIDATION FAILED: Scheduled time in the past");
      return res.status(400).json({
        success: false,
        message: "Scheduled pickup must be in the future",
      });
    }

    // Validation: Minimum lead time (at least 30 minutes before departure)
    if (diffMinutes < MIN_LEAD_MINUTES) {
      console.log("❌ VALIDATION FAILED: Too close to departure");
      return res.status(400).json({
        success: false,
        message: `Shuttle must be requested at least ${MIN_LEAD_MINUTES} minutes before bus departure. Currently ${Math.round(
          diffMinutes
        )} minutes before.`,
      });
    }

    // Validation: Maximum lead time (not more than 120 minutes before)
    if (diffMinutes > MAX_LEAD_MINUTES) {
      console.log("❌ VALIDATION FAILED: Too far from departure");
      return res.status(400).json({
        success: false,
        message: `Shuttle cannot be requested more than ${MAX_LEAD_MINUTES} minutes before departure`,
      });
    }

    console.log("✅ All time validations passed!");

    // Check for existing active shuttles for this booking
    const hasBookingShuttle = await Shuttle.exists({
      booking: booking._id,
      status: { $in: ACTIVE_STATUSES },
    });

    if (hasBookingShuttle) {
      console.log("❌ Active shuttle already exists for booking");
      return res.status(400).json({
        success: false,
        message: "An active shuttle already exists for this booking",
      });
    }

    // Check for existing active shuttles for this user
    const hasActiveShuttle = await Shuttle.exists({
      user: req.user.id,
      status: { $in: ACTIVE_STATUSES },
    });

    if (hasActiveShuttle) {
      console.log("❌ User already has active shuttle");
      return res.status(400).json({
        success: false,
        message: "You already have an active shuttle request in progress",
      });
    }

    // Calculate fare
    const distance = calculateDistance(pickup.coordinates, dropoff.coordinates);
    const fare = calculateFare(vehicleType, distance);
    console.log("💰 Fare calculated:", fare);

    // Create timeline entry
    const timelineEntry = buildTimelineEntry(
      "pending",
      "Shuttle requested by passenger"
    );

    // Get contact info from booking
    const bookingContactInfo = booking.contactInfo || {};
    const passengerCount = booking.seats?.length || 1;

    console.log("✅ Creating shuttle document...");
    const shuttle = await Shuttle.create({
      booking: booking._id,
      user: req.user.id,
      vehicleType,
      pickup: {
        address: pickup.address,
        coordinates: pickup.coordinates,
        contactName: bookingContactInfo.fullName || req.user.name,
        contactPhone: bookingContactInfo.phone || req.user.phone,
      },
      dropoff: {
        address: dropoff.address,
        coordinates: dropoff.coordinates,
      },
      scheduledTime: scheduled, // Already in correct UTC
      passengers: passengerCount,
      specialRequests,
      distance,
      estimatedDuration: Math.ceil(distance * 3),
      fare,
      status: "pending",
      timeline: [timelineEntry],
    });

    console.log("✅ Shuttle created:", {
      shuttleId: shuttle._id,
      scheduledTime: shuttle.scheduledTime.toISOString(),
      status: shuttle.status,
    });

    // Update booking with shuttle info
    booking.shuttleService = {
      requested: true,
      status: "pending",
      shuttleId: shuttle._id,
      vehicleType,
      pickup,
      dropoff,
      scheduledTime: scheduled,
      notes: specialRequests,
      fare,
    };
    await booking.save();
    console.log("✅ Booking updated with shuttle info");

    // Emit socket event to user
    emitToUser(req.user.id, "shuttle-created", {
      shuttleId: shuttle._id,
      status: shuttle.status,
    });

    // Notify eligible drivers
    const notifiedDrivers = await notifyEligibleDrivers(shuttle);
    console.log(`✅ Notified ${notifiedDrivers.length} drivers`);

    console.log("🎉 ========== SHUTTLE CREATION SUCCESSFUL ==========");

    res.status(201).json({
      success: true,
      message:
        notifiedDrivers.length > 0
          ? `Shuttle requested successfully. Notified ${notifiedDrivers.length} nearby drivers...`
          : "Shuttle requested successfully. Waiting for available drivers...",
      data: shuttle,
    });
  } catch (error) {
    console.error("❌ ========== SHUTTLE CREATION FAILED ==========");
    console.error("Error creating shuttle:", error);
    console.error("Error stack:", error.stack);
    res.status(500).json({
      success: false,
      message: "Error creating shuttle request",
      error: error.message,
    });
  }
};
/**
 * @desc    Get user's shuttle history
 * @route   GET /api/shuttles/my-rides
 * @access  Private
 */
const getUserShuttles = async (req, res) => {
  try {
    const { status, limit = 10, page = 1 } = req.query;

    const query = { user: req.user.id };
    if (status) query.status = status;

    const shuttles = await Shuttle.find(query)
      .populate({
        path: "driver",
        populate: {
          path: "user",
          select: "name phone",
        },
      })
      .sort({ scheduledTime: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Shuttle.countDocuments(query);

    res.status(200).json({
      success: true,
      count: shuttles.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: shuttles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching shuttles",
      error: error.message,
    });
  }
};

/**
 * @desc    Get shuttle by ID with tracking
 * @route   GET /api/shuttles/:id
 * @access  Private
 */
const getShuttleById = async (req, res) => {
  try {
    const shuttle = await Shuttle.findById(req.params.id)
      .populate("user", "name phone email")
      .populate({
        path: "driver",
        populate: {
          path: "user",
          select: "name phone",
        },
      });

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    // Authorization check
    const userId = req.user.id.toString();
    const isOwner = shuttle.user?._id?.toString() === userId;

    // Handle driver check - driver.user might be populated as object or just ID
    let isDriver = false;
    if (shuttle.driver && shuttle.driver.user) {
      const driverUserId =
        shuttle.driver.user._id?.toString() ||
        shuttle.driver.user?.toString() ||
        (typeof shuttle.driver.user === "string" ? shuttle.driver.user : null);
      isDriver = driverUserId === userId;
    }

    const isAdmin = req.user.role === "admin";

    if (!isOwner && !isDriver && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to view this shuttle",
      });
    }

    res.status(200).json({
      success: true,
      data: shuttle,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching shuttle",
      error: error.message,
    });
  }
};

/**
 * @desc    Get shuttle chat history
 * @route   GET /api/shuttles/:id/messages
 * @access  Private
 */
const getShuttleMessages = async (req, res) => {
  try {
    const shuttle = await Shuttle.findById(req.params.id)
      .populate("user", "_id")
      .populate("driver", "user");

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    const userId = req.user.id.toString();
    const isOwner = shuttle.user?._id?.toString() === userId;

    // Handle driver check - driver.user might be populated as object or just ID
    let isDriver = false;
    if (shuttle.driver) {
      const driverUserId =
        shuttle.driver.user?._id?.toString() ||
        shuttle.driver.user?.toString() ||
        (typeof shuttle.driver.user === "string" ? shuttle.driver.user : null);
      isDriver = driverUserId === userId;
    }

    const isAdmin = req.user.role === "admin";

    if (!isOwner && !isDriver && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to view these messages",
      });
    }

    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
    const messages = await ShuttleMessage.find({ shuttle: shuttle._id })
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();

    res.status(200).json({
      success: true,
      data: messages.reverse(),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching shuttle messages",
      error: error.message,
    });
  }
};

/**
 * @desc    Cancel shuttle request
 * @route   PUT /api/shuttles/:id/cancel
 * @access  Private
 */
const cancelShuttle = async (req, res) => {
  try {
    const { reason } = req.body;

    const shuttle = await Shuttle.findById(req.params.id);

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    if (shuttle.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to cancel this shuttle",
      });
    }

    if (["completed", "cancelled"].includes(shuttle.status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot cancel ${shuttle.status} shuttle`,
      });
    }

    if (["on_the_way", "arrived", "started"].includes(shuttle.status)) {
      return res.status(400).json({
        success: false,
        message: "Cannot cancel shuttle at this stage. Contact support.",
      });
    }

    shuttle.status = "cancelled";
    shuttle.cancelledAt = new Date();
    shuttle.cancellation = {
      cancelledBy: "user",
      reason: reason || "Cancelled by user",
    };
    shuttle.timeline.push(
      buildTimelineEntry("cancelled", "Passenger cancelled the shuttle", {
        cancelledBy: req.user.id,
      })
    );

    if (shuttle.driver) {
      const driver = await Driver.findById(shuttle.driver);
      if (driver) {
        driver.activeShuttle = null;
        driver.isAvailable = true;
        await driver.save();
        emitToDriver(driver._id, "shuttle-cancelled", {
          shuttleId: shuttle._id,
        });
      }
    }

    await Booking.findByIdAndUpdate(shuttle.booking, {
      $set: {
        "shuttleService.status": "cancelled",
      },
    });

    await shuttle.save();

    const payload = { shuttleId: shuttle._id, status: "cancelled" };
    emitToShuttleRoom(shuttle._id, "ride-status-changed", payload);

    res.status(200).json({
      success: true,
      message: "Shuttle cancelled successfully",
      data: shuttle,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error cancelling shuttle",
      error: error.message,
    });
  }
};

// ============================================
// DRIVER CONTROLLERS
// ============================================

/**
 * @desc    Get available shuttle requests for drivers
 * @route   GET /api/shuttles/driver/available
 * @access  Private/Driver
 */
const getAvailableShuttles = async (req, res) => {
  try {
    // Get driver info
    const driver = await Driver.findOne({ user: req.user.id }).populate(
      "user",
      "name phone"
    );

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found",
      });
    }

    // Find shuttles matching driver's vehicle type
    const shuttles = await Shuttle.find({
      vehicleType: driver.vehicleType,
      status: "pending",
      scheduledTime: { $gte: new Date() },
    })
      .populate("user", "name phone")
      .sort({ scheduledTime: 1 })
      .limit(20);

    res.status(200).json({
      success: true,
      count: shuttles.length,
      data: shuttles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching available shuttles",
      error: error.message,
    });
  }
};

/**
 * @desc    Get driver's assigned shuttles
 * @route   GET /api/shuttles/driver/my-rides
 * @access  Private/Driver
 */
const getDriverShuttles = async (req, res) => {
  try {
    const { status } = req.query;

    // Get driver ID from user
    const driver = await Driver.findOne({ user: req.user.id });

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found",
      });
    }

    const query = { driver: driver._id };
    if (status) query.status = status;

    const shuttles = await Shuttle.find(query)
      .populate("user", "name phone")
      .populate({
        path: "booking",
        populate: {
          path: "bus",
          select: "busName route coachNumber",
        },
      })
      .sort({ scheduledTime: 1 });

    res.status(200).json({
      success: true,
      count: shuttles.length,
      data: shuttles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching driver shuttles",
      error: error.message,
    });
  }
};

/**
 * @desc    Accept shuttle request
 * @route   PUT /api/shuttles/:id/accept
 * @access  Private/Driver
 */
const acceptShuttle = async (req, res) => {
  try {
    const driver = await Driver.findOne({ user: req.user.id });

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found",
      });
    }

    if (!driver.isActive) {
      return res.status(403).json({
        success: false,
        message: "Driver account is inactive",
      });
    }

    // Check for time conflicts with existing shuttles
    // Get the shuttle being accepted to check its scheduled time
    const newShuttle = await Shuttle.findById(req.params.id);
    if (!newShuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    // Find all active shuttles for this driver
    const activeShuttles = await Shuttle.find({
      driver: driver._id,
      status: { $in: ACTIVE_STATUSES },
    });

    // Check for time conflicts
    const newShuttleStart = new Date(newShuttle.scheduledTime);
    const newShuttleEnd = new Date(
      newShuttleStart.getTime() + (newShuttle.estimatedDuration || 60) * 60000
    );

    for (const existingShuttle of activeShuttles) {
      const existingStart = new Date(existingShuttle.scheduledTime);
      const existingEnd = new Date(
        existingStart.getTime() +
          (existingShuttle.estimatedDuration || 60) * 60000
      );

      // Check if times overlap
      if (
        (newShuttleStart >= existingStart && newShuttleStart < existingEnd) ||
        (newShuttleEnd > existingStart && newShuttleEnd <= existingEnd) ||
        (newShuttleStart <= existingStart && newShuttleEnd >= existingEnd)
      ) {
        return res.status(400).json({
          success: false,
          message: "Cannot accept shuttle - time conflict with existing ride",
        });
      }
    }

    const update = {
      driver: driver._id,
      status: "accepted",
      acceptedAt: new Date(),
      assignment: {
        acceptedBy: driver._id,
        acceptedAt: new Date(),
        lockedAt: new Date(),
      },
    };

    const shuttle = await Shuttle.findOneAndUpdate(
      {
        _id: req.params.id,
        status: "pending",
        driver: null,
      },
      {
        $set: update,
        $push: {
          timeline: buildTimelineEntry(
            "accepted",
            "Driver accepted the request",
            {
              driver: driver._id,
            }
          ),
        },
      },
      { new: true }
    )
      .populate("user", "name phone email")
      .populate({
        path: "driver",
        populate: { path: "user", select: "name phone" },
      });

    if (!shuttle) {
      return res.status(400).json({
        success: false,
        message: "Shuttle is no longer available",
      });
    }

    if (shuttle.vehicleType !== driver.vehicleType) {
      return res.status(400).json({
        success: false,
        message: "Vehicle type mismatch",
      });
    }

    driver.activeShuttle = shuttle._id;
    driver.isAvailable = false;
    driver.totalRides += 1;
    await driver.save();

    await Booking.findByIdAndUpdate(shuttle.booking, {
      $set: {
        "shuttleService.status": "accepted",
      },
    });

    emitToUser(shuttle.user._id, "shuttle-assigned", {
      shuttleId: shuttle._id,
      driver: formatDriverPayload(driver),
    });
    emitToShuttleRoom(shuttle._id, "shuttle-assigned", {
      shuttleId: shuttle._id,
      driver: formatDriverPayload(driver),
    });
    emitToDriver(driver._id, "driver-shuttle-assigned", {
      shuttleId: shuttle._id,
    });

    (shuttle.broadcastedDrivers || [])
      .filter((entry) => entry.driver?.toString() !== driver._id.toString())
      .forEach((entry) => {
        emitToDriver(entry.driver, "request-already-taken", {
          shuttleId: shuttle._id,
        });
        emitToDriver(entry.driver, "remove-request", {
          shuttleId: shuttle._id,
        });
      });

    res.status(200).json({
      success: true,
      message: "Shuttle accepted successfully",
      data: shuttle,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error accepting shuttle",
      error: error.message,
    });
  }
};

/**
 * @desc    Update shuttle status
 * @route   PUT /api/shuttles/:id/status
 * @access  Private/Driver
 */
const updateShuttleStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const driver = await Driver.findOne({ user: req.user.id });
    const shuttle = await Shuttle.findById(req.params.id).populate(
      "user",
      "_id"
    );

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    if (
      !shuttle.driver ||
      shuttle.driver.toString() !== driver._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to update this shuttle",
      });
    }

    // Status transition validation
    const validTransitions = {
      accepted: ["on_the_way", "cancelled"],
      on_the_way: ["arrived", "cancelled"],
      arrived: ["started", "cancelled"],
      started: ["completed", "cancelled"],
    };

    if (!validTransitions[shuttle.status]?.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot change status from ${shuttle.status} to ${status}`,
      });
    }

    shuttle.status = status;

    if (status === "started") shuttle.startedAt = new Date();
    if (status === "completed") {
      shuttle.completedAt = new Date();
      shuttle.payment.status = "completed";
      shuttle.payment.paidAt = new Date();
      driver.totalEarnings += shuttle.fare.total;
      driver.activeShuttle = null;
      driver.isAvailable = true;
      await driver.save();
    }
    if (status === "cancelled") {
      driver.activeShuttle = null;
      driver.isAvailable = true;
      await driver.save();
    }

    const statusLabels = {
      on_the_way: "Driver is heading to pickup",
      arrived: "Driver arrived at pickup",
      started: "Ride started",
      completed: "Ride completed",
      cancelled: "Ride cancelled",
    };

    shuttle.timeline.push(
      buildTimelineEntry(status, statusLabels[status] || status, {
        driver: driver._id,
      })
    );

    await shuttle.save();
    await Booking.findByIdAndUpdate(shuttle.booking, {
      $set: {
        "shuttleService.status": status,
      },
    });

    const payload = { shuttleId: shuttle._id, status };
    emitToShuttleRoom(shuttle._id, "ride-status-changed", payload);
    emitToUser(shuttle.user._id, "ride-status-changed", payload);

    res.status(200).json({
      success: true,
      message: "Status updated successfully",
      data: shuttle,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating shuttle status",
      error: error.message,
    });
  }
};

// Add to shuttleController.js
const checkDriverEligibility = async (req, res) => {
  try {
    const allDrivers = await Driver.find().populate("user", "name phone");

    const eligibilityReport = allDrivers.map((driver) => ({
      id: driver._id,
      name: driver.user?.name,
      vehicleType: driver.vehicleType,
      isActive: driver.isActive,
      isOnline: driver.isOnline,
      isAvailable: driver.isAvailable,
      hasLocation: !!(driver.currentLocation?.coordinates?.length === 2),
      lastSeenAt: driver.lastSeenAt,
      activeShuttle: driver.activeShuttle,
    }));

    res.json({
      success: true,
      total: allDrivers.length,
      drivers: eligibilityReport,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ============================================
// ADMIN CONTROLLERS
// ============================================

/**
 * @desc    Get all shuttles
 * @route   GET /api/shuttles/admin/all
 * @access  Private/Admin
 */
const getAllShuttles = async (req, res) => {
  try {
    const {
      status,
      vehicleType,
      startDate,
      endDate,
      page = 1,
      limit = 20,
    } = req.query;

    const query = {};
    if (status) query.status = status;
    if (vehicleType) query.vehicleType = vehicleType;
    if (startDate || endDate) {
      query.scheduledTime = {};
      if (startDate) query.scheduledTime.$gte = new Date(startDate);
      if (endDate) query.scheduledTime.$lte = new Date(endDate);
    }

    const shuttles = await Shuttle.find(query)
      .populate("user", "name phone email")
      .populate({
        path: "driver",
        populate: {
          path: "user",
          select: "name phone",
        },
      })
      .sort({ scheduledTime: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Shuttle.countDocuments(query);

    res.status(200).json({
      success: true,
      count: shuttles.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: shuttles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching shuttles",
      error: error.message,
    });
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

function buildTimelineEntry(status, label, meta = {}) {
  return {
    status,
    label,
    at: new Date(),
    meta,
  };
}

async function notifyEligibleDrivers(shuttle) {
  try {
    const candidates = await findEligibleDrivers({
      vehicleType: shuttle.vehicleType,
      pickupCoordinates: shuttle.pickup?.coordinates,
    });

    if (!candidates.length) {
      console.log("⚠️ No eligible drivers found for shuttle", shuttle._id);
      return [];
    }

    const notifiedAt = new Date();
    shuttle.broadcastedDrivers = candidates.map(({ driver, distanceKm }) => ({
      driver: driver._id,
      notifiedAt,
      distanceKm,
    }));
    await shuttle.save();

    // *** FIX: Populate shuttle with complete data before emitting ***
    const populatedShuttle = await Shuttle.findById(shuttle._id)
      .populate("user", "name email phone")
      .populate({
        path: "booking",
        populate: {
          path: "bus",
          populate: { path: "route" },
        },
      })
      .lean(); // Use lean() for better performance

    console.log(
      `📢 Broadcasting shuttle ${shuttle._id} to ${candidates.length} drivers`
    );

    // Emit to each eligible driver with COMPLETE shuttle data
    candidates.forEach(({ driver, distanceKm }) => {
      console.log(
        `  → Notifying driver ${driver._id} (${
          distanceKm?.toFixed(1) || "N/A"
        } km away)`
      );

      // *** CRITICAL: Send the COMPLETE shuttle object, not just selected fields ***
      emitToDriver(driver._id, "incoming-shuttle-request", {
        // Include ALL shuttle fields that the frontend needs
        _id: populatedShuttle._id,
        user: populatedShuttle.user,
        booking: populatedShuttle.booking,
        vehicleType: populatedShuttle.vehicleType,
        pickup: populatedShuttle.pickup,
        dropoff: populatedShuttle.dropoff,
        scheduledTime: populatedShuttle.scheduledTime,
        passengers: populatedShuttle.passengers,
        specialRequests: populatedShuttle.specialRequests,
        distance: populatedShuttle.distance,
        estimatedDuration: populatedShuttle.estimatedDuration,
        fare: populatedShuttle.fare,
        status: populatedShuttle.status,
        createdAt: populatedShuttle.createdAt,
        updatedAt: populatedShuttle.updatedAt,
        // Additional info for driver
        distanceToPickup: distanceKm,
      });
    });

    return candidates;
  } catch (error) {
    console.error("❌ notifyEligibleDrivers error:", error);
    return [];
  }
}

async function findEligibleDrivers({ vehicleType, pickupCoordinates }) {
  console.log("🔍 Finding eligible drivers for:", {
    vehicleType,
    pickupCoordinates,
  });

  const query = {
    vehicleType,
    isActive: true,
    isOnline: true,
    isAvailable: true,
  };

  const drivers = await Driver.find(query)
    .populate("user", "name phone")
    .sort({ lastSeenAt: -1 })
    .limit(50);

  console.log(`📊 Found ${drivers.length} drivers matching query:`, query);

  if (drivers.length === 0) {
    // Check what drivers exist at all
    const allDrivers = await Driver.countDocuments();
    const activeDrivers = await Driver.countDocuments({ isActive: true });
    const onlineDrivers = await Driver.countDocuments({ isOnline: true });
    const availableDrivers = await Driver.countDocuments({ isAvailable: true });
    const vehicleTypeMatch = await Driver.countDocuments({ vehicleType });

    console.log("❌ NO ELIGIBLE DRIVERS - Breakdown:");
    console.log(`   Total drivers: ${allDrivers}`);
    console.log(`   Active: ${activeDrivers}`);
    console.log(`   Online: ${onlineDrivers}`);
    console.log(`   Available: ${availableDrivers}`);
    console.log(
      `   Matching vehicle type (${vehicleType}): ${vehicleTypeMatch}`
    );

    return [];
  }

  const hasPickupCoordinates =
    Array.isArray(pickupCoordinates) && pickupCoordinates.length === 2;

  // Calculate distance for all drivers (for information purposes)
  // But DO NOT filter by distance - broadcast to everyone
  const eligible = drivers
    .map((driver) => {
      const driverCoords = driver.currentLocation?.coordinates;
      const hasDriverCoords =
        Array.isArray(driverCoords) && driverCoords.length === 2;

      // Calculate distance if both coordinates are available
      const distanceKm =
        hasPickupCoordinates && hasDriverCoords
          ? calculateDistance(driverCoords, pickupCoordinates)
          : null;

      console.log(
        `   Driver ${driver.user?.name}: distance=${
          distanceKm ? distanceKm.toFixed(1) : "N/A"
        }km, coords=${hasDriverCoords}`
      );

      return {
        driver,
        distanceKm,
      };
    })
    // NO DISTANCE FILTERING - Include all drivers
    .slice(0, 50); // Keep up to 50 drivers (you can adjust this limit)

  console.log(
    `✅ Broadcasting to ALL ${eligible.length} eligible drivers (no distance filtering)`
  );

  return eligible;
}

function formatDriverPayload(driver) {
  if (!driver) return null;

  const driverUser = driver.user && driver.user.name ? driver.user : null;

  return {
    id: driver._id,
    name: driverUser?.name,
    phone: driverUser?.phone,
    vehicleType: driver.vehicleType,
    vehicleRegistrationNumber: driver.vehicleRegistrationNumber,
    vehicleColor: driver.vehicleColor,
    vehicleModel: driver.vehicleModel,
    stats: {
      totalRides: driver.totalRides,
      rating: driver.averageRating,
    },
  };
}

function calculateDistance(coords1, coords2) {
  if (
    !Array.isArray(coords1) ||
    coords1.length < 2 ||
    !Array.isArray(coords2) ||
    coords2.length < 2
  ) {
    console.log("⚠️ Invalid coordinates, returning default 5km");
    return 5;
  }

  // MongoDB stores coordinates as [longitude, latitude]
  const [lng1, lat1] = coords1;
  const [lng2, lat2] = coords2;

  console.log(
    `📏 Calculating distance: [${lng1}, ${lat1}] → [${lng2}, ${lat2}]`
  );

  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  const finalDistance = Math.round(distance * 10) / 10;
  console.log(`📏 Distance calculated: ${finalDistance} km`);

  return finalDistance;
}

function toRad(degrees) {
  return degrees * (Math.PI / 180);
}

function calculateFare(vehicleType, distance) {
  const rates = {
    Bike: { base: 30, perKm: 15 },
    Car: { base: 50, perKm: 25 },
    Microbus: { base: 100, perKm: 40 },
  };

  const rate = rates[vehicleType] || rates.Car;
  const baseFare = rate.base;
  const distanceFare = distance * rate.perKm;
  const total = baseFare + distanceFare;

  return {
    baseFare,
    distanceFare: Math.round(distanceFare),
    total: Math.round(total),
  };
}
function emitToDriverWithRetry(driverId, event, payload, retries = 2) {
  const { getOnlineDrivers } = require("../socket");
  const onlineDrivers = getOnlineDrivers();

  const presence = onlineDrivers.get(driverId?.toString());
  if (!presence) {
    console.warn(`⚠️ Driver ${driverId} is not online, cannot emit ${event}`);
    return false;
  }

  try {
    emitToDriver(driverId, event, payload);
    console.log(`✅ Emitted ${event} to driver ${driverId}`);
    return true;
  } catch (error) {
    console.error(`❌ Error emitting ${event} to driver ${driverId}:`, error);
    if (retries > 0) {
      console.log(`🔄 Retrying... (${retries} attempts left)`);
      setTimeout(
        () => emitToDriverWithRetry(driverId, event, payload, retries - 1),
        1000
      );
    }
    return false;
  }
}
module.exports = {
  createShuttleRequest,
  getUserShuttles,
  getShuttleById,
  getShuttleMessages,
  cancelShuttle,
  getAvailableShuttles,
  getDriverShuttles,
  acceptShuttle,
  updateShuttleStatus,
  getAllShuttles,
  checkDriverEligibility,
};
