const Review = require("../models/Review");
const Shuttle = require("../models/Shuttle");
const Driver = require("../models/Driver");

/**
 * @desc    Create a review for a shuttle ride
 * @route   POST /api/reviews
 * @access  Private
 */
const createReview = async (req, res) => {
  try {
    const { shuttleId, rating, comment } = req.body;

    if (!shuttleId || !rating || !rating.overall) {
      return res.status(400).json({
        success: false,
        message: "Shuttle ID and overall rating are required",
      });
    }

    // Validate rating
    if (rating.overall < 1 || rating.overall > 5) {
      return res.status(400).json({
        success: false,
        message: "Rating must be between 1 and 5",
      });
    }

    // Get shuttle and verify user has completed this ride
    const shuttle = await Shuttle.findById(shuttleId)
      .populate("driver")
      .populate("user", "_id");

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    // Verify user is the passenger
    if (shuttle.user._id.toString() !== req.user.id.toString()) {
      return res.status(403).json({
        success: false,
        message: "You can only review your own rides",
      });
    }

    // Check if shuttle is completed
    if (shuttle.status !== "completed") {
      return res.status(400).json({
        success: false,
        message: "You can only review completed rides",
      });
    }

    // Check if user already reviewed this shuttle
    const existingReview = await Review.findOne({
      user: req.user.id,
      trip: shuttleId,
      reviewType: "shuttle",
    });

    if (existingReview) {
      return res.status(400).json({
        success: false,
        message: "You have already reviewed this ride",
      });
    }

    // Create review
    const review = await Review.create({
      user: req.user.id,
      reviewType: "shuttle",
      trip: shuttleId,
      driver: shuttle.driver?._id || null,
      rating: {
        overall: rating.overall,
        cleanliness: rating.cleanliness || null,
        punctuality: rating.punctuality || null,
        comfort: rating.comfort || null,
        service: rating.service || null,
      },
      comment: comment || "",
    });

    // Update driver's average rating
    if (shuttle.driver) {
      const driverStats = await Review.calculateAverageRating(
        shuttle.driver._id,
        "driver"
      );
      
      const driver = await Driver.findById(shuttle.driver._id);
      if (driver) {
        driver.averageRating = driverStats.averageOverall || 0;
        driver.ratingCount = driverStats.count || 0;
        await driver.save();
      }
    }

    res.status(201).json({
      success: true,
      message: "Review submitted successfully",
      data: review,
    });
  } catch (error) {
    console.error("Error creating review:", error);
    res.status(500).json({
      success: false,
      message: "Error creating review",
      error: error.message,
    });
  }
};

/**
 * @desc    Get reviews for a driver
 * @route   GET /api/reviews/driver/:driverId
 * @access  Public
 */
const getDriverReviews = async (req, res) => {
  try {
    const { driverId } = req.params;
    const { limit = 10, page = 1 } = req.query;

    const reviews = await Review.find({
      driver: driverId,
      reviewType: "shuttle",
      status: "active",
    })
      .populate("user", "name")
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Review.countDocuments({
      driver: driverId,
      reviewType: "shuttle",
      status: "active",
    });

    res.status(200).json({
      success: true,
      count: reviews.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: reviews,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching reviews",
      error: error.message,
    });
  }
};

/**
 * @desc    Get user's reviews
 * @route   GET /api/reviews/my
 * @access  Private
 */
const getMyReviews = async (req, res) => {
  try {
    const reviews = await Review.find({
      user: req.user.id,
    })
      .populate("driver", "user")
      .populate("trip")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: reviews.length,
      data: reviews,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching reviews",
      error: error.message,
    });
  }
};

/**
 * @desc    Check if user can review a shuttle
 * @route   GET /api/reviews/check/:shuttleId
 * @access  Private
 */
const checkCanReview = async (req, res) => {
  try {
    const { shuttleId } = req.params;

    const shuttle = await Shuttle.findById(shuttleId)
      .populate("user", "_id");

    if (!shuttle) {
      return res.status(404).json({
        success: false,
        message: "Shuttle not found",
      });
    }

    // Check if user is the passenger
    if (shuttle.user._id.toString() !== req.user.id.toString()) {
      return res.status(403).json({
        success: false,
        canReview: false,
        message: "You can only review your own rides",
      });
    }

    // Check if shuttle is completed
    if (shuttle.status !== "completed") {
      return res.status(200).json({
        success: true,
        canReview: false,
        message: "You can only review completed rides",
      });
    }

    // Check if already reviewed
    const existingReview = await Review.findOne({
      user: req.user.id,
      trip: shuttleId,
      reviewType: "shuttle",
    });

    if (existingReview) {
      return res.status(200).json({
        success: true,
        canReview: false,
        alreadyReviewed: true,
        message: "You have already reviewed this ride",
      });
    }

    return res.status(200).json({
      success: true,
      canReview: true,
      message: "You can review this ride",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error checking review eligibility",
      error: error.message,
    });
  }
};

module.exports = {
  createReview,
  getDriverReviews,
  getMyReviews,
  checkCanReview,
};








