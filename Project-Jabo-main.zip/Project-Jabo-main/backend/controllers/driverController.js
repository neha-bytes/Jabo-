const Driver = require("../models/Driver");
const Shuttle = require("../models/Shuttle");

const summarizeEarnings = (rides) =>
  rides.reduce((sum, ride) => sum + (ride.fare?.total || 0), 0);

exports.getDriverProfile = async (req, res) => {
  try {
    const driver = await Driver.findOne({ user: req.user.id }).populate(
      "user",
      "name email phone"
    );

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found",
      });
    }

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const todaysRides = await Shuttle.find({
      driver: driver._id,
      status: "completed",
      completedAt: { $gte: todayStart, $lte: todayEnd },
    }).select("fare completedAt distance passengers");

    const totalCompleted = await Shuttle.countDocuments({
      driver: driver._id,
      status: "completed",
    });

    const activeRide = await Shuttle.findOne({
      driver: driver._id,
      status: { $in: ["accepted", "on_the_way", "arrived", "started"] },
    }).select("_id status scheduledTime");

    res.status(200).json({
      success: true,
      data: {
        driver: driver.getPublicProfile ? driver.getPublicProfile() : driver,
        stats: {
          earningsToday: summarizeEarnings(todaysRides),
          ridesToday: todaysRides.length,
          totalCompleted,
          activeRideId: activeRide?._id || null,
          availability: {
            isAvailable: driver.isAvailable,
            isOnline: driver.isOnline,
          },
        },
      },
    });
  } catch (error) {
    console.error("Driver profile fetch error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch driver profile",
      error: error.message,
    });
  }
};



